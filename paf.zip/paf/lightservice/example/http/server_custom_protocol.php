<?php
error_reporting(E_ALL);
ini_set('display_errors', true);

require_once(__DIR__ . '/../../vendor/autoload.php');

use Paf\LightService\Server\Service;

require __DIR__ . '/CustomProtocol.php';

class UserModule
{
    public function login($user, $passwd)
    {
        if ($user != 'foo') {
            return 'illigal user';
        }

        if ($passwd != 'bar') {
            return 'wrong passwd, ' . $passwd;
        }

        return array('hello world!', 'pass');
    }
}

class HashitModule
{
    public function hash($data)
    {
        // if ($data == 'data2') {
            // header('HTTP/1.0 403 Forbidden');
            // exit();
        // }

        return array($data, md5($data));
    }
}

class FooModule
{
    public function bar()
    {
        return 'bar';
    }
}

class Foo2Module
{
    public function bar2()
    {
        return 'bar2';
    }
}

class Foo3Module
{

    public function bar3()
    {
        return 'bar3';
    }
}

class Foo4Module
{
    public function bar4()
    {
        return 'bar4';
    }
}

function myecho($msg) {
    return $msg;
}

class UriModule
{
  public function gotit($secret)
  {
    return array(
      'a' => 'b',
      'b' => 'a',
      'scret' => $secret
    );
  }
}

class EchoModule
{
    public function hi($sth)
    {
        return $sth;
    }
}

$s = Service::create(new \CustomProtocol(), function($module, $method, $params, $id) {
    error_log('id: ' . $id);
    error_log(print_r($params, true));
    error_log($method);

    if ('login.qlogin' == $method) {
        $method = 'login';
    }

    if (!isset($module) && function_exists($method)) {
        return $method;
    }

    if ('forbidden' === $method) {
        return Service::ret('Forbidden 403');
    }

    $class = $module . 'Module';

    if (class_exists($class)) {
        $callable = array(new $class, $method);
        return is_callable($callable) ? $callable : NULL;
    }
});

if (!isset($_GET['auth']) || $_GET['auth'] != 'iamauth') {
    echo $s->respondWith('Forbidden');
} else {
    $s->register('Echo.hi', function ($ret) {
        return $ret;
    });

    echo $s->respond(('GET' == $_SERVER['REQUEST_METHOD']) ? $_GET : file_get_contents('php://input'));
}
