<?php
require __DIR__ . '/../../vendor/autoload.php';

use Paf\LightService\Client\Service;
use Paf\LightService\Client\IdGen;

require __DIR__ . '/User.php';

putenv('X_REQUEST_ID=my_request_id');
putenv('X_REQUEST_TAG=my_request_tag');
var_dump(getenv('X_REQUEST_ID'));
var_dump(getenv('X_REQUEST_TAG'));

// custom id generator
IdGen::$generator = function () {
    $id = IdGen::defaultGenerator();
    return "id<{$id}>";
};

$reqests = array();

Service::on('request.start', function ($data) use (&$requests) {
    $requests[spl_object_hash($data['request'])] = microtime(true);
});

Service::on('request.end', function ($data) use (&$requests) {
    $req = $data['request'];
    $response = $data['response'];
    $hash = spl_object_hash($data['request']);

    if (isset($requests[$hash])) {
        $dt = date('[Y-m-d H:i:s]', $requests[$hash]);
        $delta = (microtime(true) - $requests[$hash]) * 1000;

        if (isset($data['error'])) {
            echo "\n{$dt}\t{$req->id}\t{$req->method}\t{$delta}ms\tfailed\t{$data['error']['code']}\t{$data['error']['message']}\n";
        } else {
            // $requests[$req->id] = microtime(true);
            echo "\n{$dt}\t{$req->id}\t{$req->method}\t{$delta}ms\n";
        }

        unset($requests[$hash]);
    }
});

// config
Service::importConf(
    array(
        'dev' => array(
            'type' => 'http',
            'protocol' => 'jsonrpc',
            'conf' => array(
                'url'  => 'http://sophon-3.net/code/lightservice/example/http/server.php?auth=iamauth',
                'with_header' => true,
                'header' => [
                    'header-you-like: value-you-mind'
                ],
                'digest' => function ($req) {
                    if (is_array($req)) {
                        return 'batch';
                    } else {
                        return 'single';
                    }
                }
            )
        ),
        'notoken' => array(
            'type' => 'http',
            'protocol' => 'jsonrpc',
            'header' => [
                'header-you-like: value-you-mind'
            ],
            'conf' => array(
                'url'  => 'http://sophon-3.net/code/lightservice/example/http/server.php'
            )
        )
    )
);

// get service
$s = Service::get('dev');

// get specified module
$user   = $s->module('user');
$hashit = $s->module('hashit');
$foo    = $s->module('foo');
$foo2   = $s->module('foo2');
$echo   = $s->module('Echo');

echo "\n-------------------------------------------------------------------------------------------\n";
echo "\nuser->login\n";

$rep = $user->login('foo', 'bar', file_get_contents(__DIR__ . '/gbk.txt'));

if (!$user->errno()) {
    echo 'rep : ';
    var_dump($rep);
} else {
    echo 'errno  : ', $user->errno(), "\n";
    echo 'errstr : ', $user->errstr(), "\n";
}

echo "\n-------------------------------------------------------------------------------------------\n";
echo "\nhashit->hash\n";

$rep = $hashit->hash('bala bala');

if (!$hashit->errno()) {
    echo 'rep : ';
    var_dump($rep);
} else {
    echo 'errno  : ', $hashit->errno(), "\n";
    echo 'errstr : ', $hashit->errstr(), "\n";
}

echo "\n-------------------------------------------------------------------------------------------\n";
echo "\nfoo->bar\n";

$rep = $foo->bar();

if (!$foo->errno()) {
    echo 'rep : ';
    var_dump($rep);
} else {
    echo 'errno  : ', $foo->errno(), "\n";
    echo 'errstr : ', $foo->errstr(), "\n";
}

echo "\n-------------------------------------------------------------------------------------------\n";
echo "\nfoo2->bar2\n";

$rep = $foo2->bar2();

if (!$foo2->errno()) {
    echo 'rep : ';
    var_dump($rep);
} else {
    echo 'errno  : ', $foo2->errno(), "\n";
    echo 'errstr : ', $foo2->errstr(), "\n";
}

echo "\n-------------------------------------------------------------------------------------------\n";
echo "\nfoo2->bar3\n";

$rep = $foo2->bar3();

if (!$foo2->errno()) {
    echo 'rep : ';
    var_dump($rep);
} else {
    echo 'errno  : ', $foo2->errno(), "\n";
    echo 'errstr : ', $foo2->errstr(), "\n";
}

echo "\n-------------------------------------------------------------------------------------------\n";
echo "\nEcho->hi\n";

$rep = $echo->hi('haode');

if (!$echo->errno()) {
    echo 'rep : ';
    var_dump($rep);
} else {
    echo 'errno  : ', $echo->errno(), "\n";
    echo 'errstr : ', $echo->errstr(), "\n";
}

echo "\n-------------------------------------------------------------------------------------------\n";

$s2 = Service::get('notoken');

$user2 = $s2->module('user');

echo "\n-------------------------------------------------------------------------------------------\n";
echo "\nuser2->login\n";

$rep = $user2->login('foo', 'bar');

if (!$user2->errno()) {
    echo 'rep : ';
    var_dump($rep);
} else {
    echo 'errno  : ', $user2->errno(), "\n";
    echo 'errstr : ', $user2->errstr(), "\n";
}

echo "\n-------------------------------------------------------------------------------------------\n";
echo "\nuser->forbidden\n";

$rep = $user->forbidden('balabala');

if (!$user->errno()) {
    echo 'rep : ';
    var_dump($rep);
} else {
    echo 'errno  : ', $user->errno(), "\n";
    echo 'errstr : ', $user->errstr(), "\n";
}

echo "\n-------------------------------------------------------------------------------------------\n";
echo "\ncall\n";

$rep = Service::call('dev::hashit.hash', array('data'), $err);

if (!$err) {
    echo 'reps : ';
    var_dump($rep);
} else {
    echo 'err  : ', $err, "\n";
}

echo "\n-------------------------------------------------------------------------------------------\n";
echo "\nmultiCall\n";

// $err = null;
// Service::batchBegin();
// Service::call('dev::hashit.hash', array('data1'));
// Service::call('dev::hashit.hash', array('data2'));
// Service::call('dev::hashit.hash', array('data3'));
// Service::call('dev::hashit.hash', array('data4'));
// Service::call('dev::hashit.hash', array('data5'));
// $reps = Service::batchCommit($err);
$err = null;

$reps = lightservice_batch_call(
    array(
        array('dev::hashit.hash', array('data1')),
        array('dev::hashit.hash', array(file_get_contents(__DIR__ . '/gbk.txt'))),
        array('dev::hashit.hash', array('data3')),
        array('dev::hashit.hash', array('data4')),
        array('dev::hashit.hash', array('data5')),
        array('dev::hashit.hash', array('data6')),
        array('dev::hashit.hash', array(file_get_contents(__DIR__ . '/gbk.txt')))
    ),
    $err
);

echo 'reps : ';
var_dump($reps);
echo "\n";
echo 'err : ';
var_dump($err);
echo "\n";

echo "\n-------------------------------------------------------------------------------------------\n";

echo "\nuser.login.qlogin\n";

$err = null;
$rep = lightservice_call('dev::user.login.qlogin', array('foo', 'bar'), $err);

if (!$err) {
    echo 'rep : ';
    var_dump($rep);
} else {
    echo 'errstr : ', $err, "\n";
}

echo "\n-------------------------------------------------------------------------------------------\n";

echo "\nuser.__explore\n";

$err = null;
$rep = lightservice_explore('dev::user', $err);

if (!$err) {
    echo 'rep : ';
    var_dump($rep);
} else {
    echo 'errstr : ', $err, "\n";
}

echo "\n-------------------------------------------------------------------------------------------\n";
echo "\nuser->login\n";

$user = new User;

$err = null;
$rep = $user->login('foo', 'bar');

if (!$user->errno()) {
    echo 'rep : ';
    var_dump($rep);
} else {
    echo 'errno  : ', $user->errno(), "\n";
    echo 'errstr : ', $user->errstr(), "\n";
}

echo "\n-------------------------------------------------------------------------------------------\n";
echo "\nuser->loginWithException\n";

$user = new User;

$err = null;
$rep = $user->loginWithException();

if (!$user->errno()) {
    echo 'rep : ';
    var_dump($rep);
} else {
    echo 'errno  : ', $user->errno(), "\n";
    echo 'errstr : ', $user->errstr(), "\n";
}

echo "\n-------------------------------------------------------------------------------------------\n";
echo "\nbatchCall\n";
echo "datacenter->getCityList(1)\n";
echo "datacenter->getUserList(2)\n";
echo "datacenter->getNoneList(3)\n";
echo "datacenter->getIpList(4)\n";
echo "datacenter->getAnyThingWithError(5)\n";

$err = null;
$rep = $s->batchCall([
    ['DataCenter.getCityList', [1]],
    ['DataCenter.getUserList', [2]],
    ['DataCenter.getNoneList', [3]],
    ['DataCenter.getIpList',   [4]],
    ['DataCenter.getAnyThingWithError', [5]]
], $err);

if (!$err) {
    echo 'rep : ';
    var_dump($rep);
    echo 'err : ';
    var_dump($err);
} else {
    echo 'err : ';
    var_dump($err);
}

echo "\n-------------------------------------------------------------------------------------------\n";
echo "\nlocal\n";
echo "any->any()\n";

$err = null;
$rep = $s->call('local.any');

if (!$s->errno()) {
    echo 'rep : ';
    var_dump($rep);
} else {
    echo 'err : ';
    var_dump($s->errstr());
}
