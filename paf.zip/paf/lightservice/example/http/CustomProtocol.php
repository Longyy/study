<?php
require_once(__DIR__ . '/../../vendor/autoload.php');

use Paf\LightService\Core\Message\Protocol;

class CustomProtocol extends Protocol\JsonRpc
{
    public function encodeRequest($req)
    {
        $msg = parent::encodeRequest($req);
        return md5($msg) . $msg;
    }

    public function decodeRequest($req)
    {
        $md5 = substr($req, 0, 32);
        $msg = substr($req, 32);

        if ($md5 !== md5($msg)) {
            return false;
        }

        return parent::decodeRequest($msg);
    }

    public function encodeResponse($rep)
    {
        $msg = parent::encodeResponse($rep);
        return md5($msg) . $msg;
    }

    public function decodeResponse($rep)
    {
        $md5 = substr($rep, 0, 32);
        $msg = substr($rep, 32);

        if ($md5 !== md5($msg)) {
            return false;
        }

        return parent::decodeResponse($msg);
    }
}
