<?php
error_reporting(E_ALL);
ini_set('display_errors', true);

// if (!isset($_GET['auth']) || $_GET['auth'] != 'iamauth') {
    // // http_response_code(403);
    // header('HTTP/1.0 403 Forbidden');
    // exit();
// }

require __DIR__ . '/../../vendor/autoload.php';

use Paf\LightService\Server\Service;
use Paf\LightService\Client\Service as ClientService;

error_log('----------------------------');
error_log(print_r($_SERVER, true));
error_log('----------------------------');

class UserModule
{
    use \Paf\LightService\Util\Explorable;

    public function login($user, $passwd)
    {
        if ($user != 'foo') {
            return 'illigal user';
        }

        if ($passwd != 'bar') {
            return 'wrong passwd, ' . $passwd;
        }

        return array('hello world!', 'pass');
    }

    public function loginWithException()
    {
        throw new \Exception('login with exception!');
    }
}

class HashitModule
{
    public function hash($data)
    {
        // if ($data == 'data2') {
            // header('HTTP/1.0 403 Forbidden');
            // exit();
        // }

        return array($data, md5($data));
    }
}

class FooModule
{
    public function bar()
    {
        return 'bar';
    }
}

class Foo2Module
{
    public function bar2()
    {
        return 'bar2';
    }
}

class Foo3Module
{

    public function bar3()
    {
        return 'bar3';
    }
}

class Foo4Module
{
    public function bar4()
    {
        return 'bar4';
    }
}

function myecho($msg) {
    return $msg;
}

class UriModule
{
  public function gotit($secret)
  {
    return array(
      'a' => 'b',
      'b' => 'a',
      'scret' => $secret
    );
  }
}

class EchoModule
{
    public function hi($sth)
    {
        return $sth;
    }
}

class DataCenterModule
{
    public function getCityList($id)
    {
        return [
            '上海',
            '北京',
            '广州'
        ];
    }

    public function getUserList($id)
    {
        return [
            '小红',
            '小黄',
            '小绿'
        ];
    }

    public function getNoneList($id)
    {
        return null;
    }

    public function getIpList($id)
    {
        return [
            '192.168.1.1',
            '192.168.1.2',
            '192.168.1.3'
        ];
    }
}

ClientService::importConf(
    array(
        'dev' => array(
            'type' => 'local',
            'conf' => array(
                'service' => Service::create('local', function ($module, $method, $params, $id) {
                    return Service::ret('local ret');
                })
            )
        )
    )
);

$s = Service::create('jsonrpc', function($module, $method, $params, $id) {
    error_log('id: ' . $id);
    error_log(print_r($params, true));
    error_log($method);

    if ('login.qlogin' == $method) {
        $method = 'login';
    }

    if (!isset($module) && function_exists($method)) {
        return $method;
    }

    if ('forbidden' === $method) {
        return Service::ret('Forbidden 403');
    }

    if ('local' === $module) {
        return Service::ret(ClientService::get('dev')->call('any.any'));
    }

    $class = $module . 'Module';

    if (class_exists($class)) {
        $callable = array(new $class, $method);
        return is_callable($callable) ? $callable : null;
    }
}, function ($e, &$reply, &$force_success) {
    error_log(sprintf('message from exception_handler: %s', $e->getMessage()));
    $reply->error->message = 'error message';
    // $force_success = true;

    return 'force_success';
});

$requests = array();

Service::on('request.start', function ($data) use (&$requests) {
    $requests[$data['request']->id] = microtime(true);
});

Service::on('request.end', function ($data) use (&$requests) {
    $req = $data['request'];

    if (isset($requests[$req->id])) {
        $dt = date('[Y-m-d H:i:s]', $requests[$req->id]);
        $delta = (microtime(true) - $requests[$req->id]) * 1000;

        if (isset($data['error'])) {
            error_log("{$req->id}\t{$req->method}\t{$delta}ms\tfailed\t{$data['error']['code']}\t{$data['error']['message']}");
        } else {
            error_log("{$req->id}\t{$req->method}\t{$delta}ms");
        }

        unset($requests[$req->id]);
    }

});

if (!isset($_GET['auth']) || $_GET['auth'] != 'iamauth') {
    echo $s->respondWith('Forbidden');
} else {
    $s->register('Echo.hi', function ($ret) {
        return $ret;
    });

    unset($_GET['auth']);
    echo $s->respond(('GET' == $_SERVER['REQUEST_METHOD']) ? $_GET : file_get_contents('php://input'));
}
