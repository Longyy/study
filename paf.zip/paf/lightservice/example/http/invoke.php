<?php
error_reporting(E_ALL);
ini_set('display_errors', true);

require __DIR__ . '/../../vendor/autoload.php';

use Paf\LightService\Server\Service;

class EchoModule
{
    public function hi($sth)
    {
        return $sth;
    }
}

$s = Service::create('jsonrpc', function ($module, $method, $params, $id) {
    error_log('id: ' . $id);
    error_log(print_r($params, true));
    error_log($method);

    if ('login.qlogin' == $method) {
        $method = 'login';
    }

    if (!isset($module) && function_exists($method)) {
        return $method;
    }

    if ('forbidden' === $method) {
        return Service::ret('Forbidden 403');
    }

    $class = $module . 'Module';

    if (class_exists($class)) {
        $callable = array(new $class, $method);
        return is_callable($callable) ? $callable : null;
    }
}, function ($e, &$reply, &$force_success) {
    error_log(sprintf('message from exception_handler: %s', $e->getMessage()));
    $reply->error->message = 'error message';
    // $force_success = true;

    return 'force_success';
});

$s->invoke('Echo', 'hi', ['haode'], '"i am id"');
$s->invokeMethod('Echo.hi', ['haode'], '"i am id"');
