<?php

class User extends Paf\LightService\Client\Facade
{
    public $service = 'dev';
    public $module  = 'user';
}
