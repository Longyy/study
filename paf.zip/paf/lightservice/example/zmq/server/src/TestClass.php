<?php
/**
 * a simple example for serverbench server app with lightservice
 *
 * @author Yang Yang
 * @copyright Yang Yang, 2014.11.07
 */

require dirname(dirname(__DIR__)) . '/lightservice.phar';

use LightService\Server;
use ServerBench\Logger\Logger;

class UserModule
{
    public function login($user, $passwd)
    {
        if ($user != "foo") {
            return 'illegal user';
        }

        if ($passwd != 'bar') {
            return 'wrong passwd, ' . $passwd;
        }

        return array('hello world!', 'pass');
    }
}

class HashitModule
{
    public function hash($data)
    {
        return array($data, md5($data));
    }
}

class FooModule
{
    public function bar()
    {
        return 'bar';
    }
}

class Foo2Module
{
    public function bar2()
    {
        return 'bar2';
    }
}

class Foo3Module
{
    public function bar3()
    {
        return 'bar3';
    }
}

class Foo4Module
{
    public function bar4()
    {
        return 'bar4';
    }
}

class TestClass
{
    private $service_ = NULL;

    public function handleInit()
    {
        Logger::debug("handleInit");

        $this->service_ = Server\Service::create('jsonrpc', function($module, $method) {
            if (!isset($module) && function_exists($method)) {
                return $method;
            }

            $class = $module . "Module";

            if (class_exists($class)) {
                // error_log($class);
                $callable = array(new $class, $method);
                return is_callable($callable) ? $callable : NULL;
            }

        });
    }

    public function handleFini()
    {
        Logger::debug("handleFini");
    }

    public function handleProcess($message)
    {
        Logger::debug("handleProcess");
        return $this->service_->respond($message);
    }
}
