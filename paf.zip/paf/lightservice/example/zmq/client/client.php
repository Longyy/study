<?php
require dirname(__DIR__) . '/lightservice.phar';

use LightService\Client\Service;

// config
Service::importConf(
    array(
        'dev' => array(
            'type' => 'zmq',
            'protocol' => 'jsonrpc',
            'conf' => array(
                'addr'  => 'tcp://127.0.0.1:24816',
                'send_timeout' => '10',
                'recv_timeout' => '10'
            )
        )
    )
);

// get service
$s = Service::get('dev');

// get specified module
$user   = $s->module('user');
$hashit = $s->module('hashit');
$foo    = $s->module('foo');
$foo2   = $s->module('foo2');

echo "\n----------\n";
echo "\nuser->login\n";

$rep = $user->login('foo', 'bar');

if (!$user->errno()) {
    echo 'rep : ', var_dump($rep);
} else {
    echo 'errno  : ', $user->errno(), "\n";
    echo 'errstr : ', $user->errstr(), "\n";
}

echo "\n----------\n";
echo "\nhashit->hash\n";

$rep = $hashit->hash('bala bala');

if (!$hashit->errno()) {
    echo 'rep : ', var_dump($rep);
} else {
    echo 'errno  : ', $hashit->errno(), "\n";
    echo 'errstr : ', $hashit->errstr(), "\n";
}

echo "\n----------\n";
echo "\nfoo->bar\n";

$rep = $foo->bar();

if (!$foo->errno()) {
    echo 'rep : ', var_dump($rep);
} else {
    echo 'errno  : ', $foo->errno(), "\n";
    echo 'errstr : ', $foo->errstr(), "\n";
}

echo "\n----------\n";
echo "\nfoo2->bar2\n";

$rep = $foo2->bar2();

if (!$foo2->errno()) {
    echo 'rep : ', var_dump($rep);
} else {
    echo 'errno  : ', $foo2->errno(), "\n";
    echo 'errstr : ', $foo2->errstr(), "\n";
}

echo "\n----------\n";
echo "\nfoo2->bar3\n";

$rep = $foo2->bar3();

if (!$foo2->errno()) {
    echo 'rep : ', var_dump($rep);
} else {
    echo 'errno  : ', $foo2->errno(), "\n";
    echo 'errstr : ', $foo2->errstr(), "\n";
}

echo "\n----------\n";
