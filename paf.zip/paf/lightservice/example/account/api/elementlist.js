
var ApiGen = ApiGen || {};
ApiGen.elements = [["c","Account"],["m","Account::login()"],["m","Account::welcome()"],["c","Captcha"],["m","Captcha::deprecatedMethod()"],["m","Captcha::generate()"]];
