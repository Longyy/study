<?php
$phar = new Phar('lightservice.phar');
$phar->startBuffering();
$phar->buildFromDirectory(__DIR__, '$(src|vendor)/.*\.php$');
$phar->setStub($phar->createDefaultStub('./vendor/autoload.php'));
$phar->stopBuffering();
