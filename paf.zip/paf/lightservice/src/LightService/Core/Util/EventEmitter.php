<?php

namespace Paf\LightService\Core\Util;

class EventEmitter
{
    use Singleton;

    protected $container_ = [];

    public function emit($event)
    {
        $args = array_slice(func_get_args(), 1);

        if (isset($this->container_[$event])) {
            foreach ($this->container_[$event] as $handler) {
                call_user_func_array($handler, $args);
            }
        }
    }

    public function on($event, $handler)
    {
        if (!isset($this->container_[$event])) {
            $this->container_[$event] = [];
        }

        $this->container_[$event][] = $handler;
    }

    public function off($event = null, $handler = null)
    {
        if ($event) {
            if ($handler) {
                if (isset($this->container_[$event])) {
                    foreach (array_keys($this->container_[$event], $handler, true) as $key) {
                        unset($this->container_[$key]);
                    }
                }
            } else {
                unset($this->container_[$event]);
            }
        } else {
            $this->container_ = [];
        }
    }
}
