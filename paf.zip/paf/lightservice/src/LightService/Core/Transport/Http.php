<?php
/**
 * Http transport's implementation of LightService
 *
 * @author Yuan B.J.
 * @copyright Yuan B.J., 2014.09.17
 */

namespace Paf\LightService\Core\Transport;

class Http extends Transport
{
    private $url_ = null;
    private $ch_  = null;

    public function init($conf)
    {
        if (!isset($conf['url'])) {
            return false;
        }

        $ch = curl_init($conf['url']);

        if (!$ch) {
            return false;
        }

        curl_setopt($ch, CURLOPT_POST, 1);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        // for request error info, e.g. 404, 403, 500 ...
        curl_setopt($ch, CURLOPT_FAILONERROR, 1);

        $this->ch_  = $ch;
        $this->url_ = $conf['url'];

        foreach ($conf as $k => $v) {
            $this->config($k, $v);
        }

        return true;
    }

    public function config($k, $v)
    {
        $ret = false;

        switch ($k) {
            case 'exec_timeout':
                $ret = curl_setopt($this->ch_, CURLOPT_TIMEOUT_MS, $v);
                break;
            case 'dns_timeout':
                $ret = curl_setopt($this->ch_, CURLOPT_DNS_CACHE_TIMEOUT, $v);
                break;
            case 'connect_timeout':
                $ret = curl_setopt($this->ch_, CURLOPT_CONNECTTIMEOUT_MS, $v);
                break;
            case 'header':
                $ret = curl_setopt($this->ch_, CURLOPT_HTTPHEADER, $v);
                break;
            case 'ssl_verifypeer':
                $ret = curl_setopt($this->ch_, CURLOPT_SSL_VERIFYPEER, $v);
                break;
            case 'ssl_verifyhost':
                $ret = curl_setopt($this->ch_, CURLOPT_SSL_VERIFYHOST, $v);
                break;
        }

        return $ret;
    }

    public function send($message, $query = '')
    {
        curl_setopt($this->ch_, CURLOPT_URL, empty($query) ? $this->url_ : $this->url_ . (false === strrpos($this->url_, '?') ? '?' : '&') . $query);
        curl_setopt($this->ch_, CURLOPT_POSTFIELDS, $message);
        $reply = curl_exec($this->ch_);

        if (false === $reply) {
            $this->setErr(curl_errno($this->ch_), curl_error($this->ch_));
        }

        return $reply;
    }

    public function preSend($message, $query = '')
    {
        curl_setopt($this->ch_, CURLOPT_URL, empty($query) ? $this->url_ : $this->url_ . (false === strrpos($this->url_, '?') ? '?' : '&') . $query);
        return curl_setopt($this->ch_, CURLOPT_POSTFIELDS, $message);
    }

    static public function wait($transports, &$err)
    {
        $mh = curl_multi_init();

        foreach ($transports as $transport) {
            curl_multi_add_handle($mh, $transport->ch_);
        }

        do {
            $rc = curl_multi_exec($mh, $still_running);
        } while (CURLM_CALL_MULTI_PERFORM === $rc);

        while ($still_running && CURLM_OK === $rc) {
            if (curl_multi_select($mh) < 0) {
                usleep(1);
            }

            do {
                $rc = curl_multi_exec($mh, $still_running);
            } while (CURLM_CALL_MULTI_PERFORM === $rc);
        }

        $ret = false;

        if (CURLM_OK === $rc) {
            $ret = array();

            foreach ($transports as $i => $transport) {
                $errstr = curl_error($transport->ch_);

                if ($errstr) {
                    $transport->setErr(-1, $errstr);
                    $ret[] = false;
                } else {
                    $ret[] = curl_multi_getcontent($transport->ch_);
                }
            }
        } else {
            switch ($rc) {
                case CURLM_BAD_HANDLE:
                    $err = 'curlm bad handle';
                    break;
                case CURLM_BAD_EASY_HANDLE:
                    $err = 'curlm bad easy handle';
                    break;
                case CURLM_OUT_OF_MEMORY:
                    $err = 'curlm out of memory';
                    break;
                case CURLM_INTERNAL_ERROR:
                    $err = 'curlm internal error';
                    break;
                default:
                    $err = 'curlm unknown internal error';
            }
        }

        foreach ($transports as $transport) {
            curl_multi_remove_handle($mh, $transport->ch_);
        }

        curl_multi_close($mh);
        return $ret;
    }
}
