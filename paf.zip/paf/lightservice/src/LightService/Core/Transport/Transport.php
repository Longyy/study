<?php
/**
 * transport's interface of LightService
 *
 * @author Yuan B.J.
 * @copyright Yuan B.J., 2014.09.17
 */

namespace Paf\LightService\Core\Transport;

use Paf\LightService\Core\Util\Errorable;

abstract class Transport extends Errorable
{
    abstract public function send($message);
}
