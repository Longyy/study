<?php
/**
 * ZMQ transport's implementation of LightService
 *
 * @author Yang Yang
 * @copyright Yang Yang, 2014.11.7
 */

namespace Paf\LightService\Core\Transport;

use Paf\LightService\Client\Service;
use ZMQContext;
use ZMQSocket;
use ZMQSocketException;
use ZMQContextException;

class Zmq extends Transport
{
    private $zctx_   = null;
    private $client_ = null;
    private $addr_   = null;

    public function __construct()
    {
        $this->zctx_ = new ZMQContext();
    }

    public function init($conf)
    {
        $ret = true;
        $this->client_ = $this->zctx_->getSocket(\ZMQ::SOCKET_DEALER);

        if (!isset($conf['addr'])) {
            return false;
        }

        $addr = $conf['addr'];

        try {
            $this->client_->connect($addr);
        } catch (ZMQSocketException $e) {
            $this->setErr($e->getCode(), $e->getMessage());
            $ret = false;
        }

        foreach ($conf as $k => $v) {
            $this->config($k, $v);
        }

        return $ret;
    }


    public function config($k, $v)
    {
        $ret = false;

        try {
            switch ($k) {
                case 'send_timeout':
                    $ret = $this->client_->setSockOpt(\ZMQ::SOCKOPT_SNDTIMEO, $v);
                    break;
                case 'recv_timeout':
                    $ret = $this->client_->setSockOpt(\ZMQ::SOCKOPT_RCVTIMEO, $v);
                    break;
            }
        } catch (ZMQSocketException $e) {
            $this->setErr($e->getCode(), $e->getMessage());
        }

        return $ret;
    }

    public function send($message)
    {
        $ret = false;

        try {
            $this->client_->sendmulti(array('', $message));
            $empty = $this->client_->recv();
            assert(empty($empty));
            $ret = $this->client_->recv();
        } catch (ZMQSocketException $e) {
            $this->setErr($e->getCode(), $e->getMessage());
        }

        return $ret;
    }
}
