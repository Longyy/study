<?php

/**
 * Queue transport's implementation of LightService
 *
 * @author Cao yi
 * @copyright Cao yi, 2015.10.23
 */

namespace Paf\LightService\Core\Transport;

class Queue extends Transport
{
    private $push_;

    public function init($conf)
    {
        $ret = false;

        if ($conf['push']) {
            $this->push_ = $conf['push'];
            $ret = true;
        }

        return $ret;
    }

    public function send($message)
    {
        return call_user_func($this->push_, $message);
    }
}