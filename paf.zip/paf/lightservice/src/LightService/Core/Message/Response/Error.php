<?php
/**
 * Error's response structure of LightService
 *
 * @author Yuan B.J.
 * @copyright Yuan B.J., 2014.09.17
 */

namespace Paf\LightService\Core\Message\Response;

class Error
{
    public $error;

    public function __construct()
    {
        $this->error          = new \stdClass;
        $this->error->code    = null;
        $this->error->message = null;
        // This may be omitted.
        // $this->error->data    = null;
    }
}
