<?php
/**
 * Response of LightService
 *
 * @author Yuan B.J.
 * @copyright Yuan B.J., 2014.09.17
 */

namespace Paf\LightService\Core\Message\Response;

class Response
{
    public static function success($result, $id = null)
    {
        $rep         = new Success;
        $rep->result = $result;

        if (func_num_args() > 1) {
            $rep->id = $id;
        }

        return $rep;
    }

    public static function error($error, $id = null)
    {
        $rep = new Error;

        if (is_array($error)) {
            $rep->error->code = $error['code'];

            if (array_key_exists('message', $error)) {
                $rep->error->message = $error['message'];
            }

            if (array_key_exists('data', $error)) {
                $rep->error->data = $error['data'];
            }
        } else {
            $rep->error->code = $error;
        }

        if (func_num_args() > 1) {
            $rep->id = $id;
        }

        return $rep;
    }
}
