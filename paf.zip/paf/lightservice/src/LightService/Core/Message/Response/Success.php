<?php
/**
 * Success's response structure of LightService
 *
 * @author Yuan B.J.
 * @copyright Yuan B.J., 2014.09.17
 */

namespace Paf\LightService\Core\Message\Response;

class Success
{
    public $id;
    public $result;
}
