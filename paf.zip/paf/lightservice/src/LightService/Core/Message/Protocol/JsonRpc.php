<?php
/**
 * jsonrpc protocol's implementation for message
 *
 * @author Yuan B.J.
 * @copyright Yuan B.J., 2014.09.17
 */

namespace Paf\LightService\Core\Message\Protocol;

use Paf\LightService\Core\Message\Request\Request;
use Paf\LightService\Core\Message\Response\Response;
use Paf\LightService\Core\Message\Response\Success;
use Paf\LightService\Core\Message\Response\Error;

class JsonRpc implements Protocol
{
    private function packRequest_($req)
    {
        $ret = array('jsonrpc' => '2.0', 'method' => $req->method);

        if (property_exists($req, 'params')) {
            $ret['params'] = $req->params;
        }

        if (property_exists($req, 'id')) {
            $ret['id'] = $req->id;
        }

        return $ret;
    }

    public function encodeRequest($req)
    {
        $ret = null;

        if (is_array($req)) {
            $ret = [];

            foreach ($req as $item) {
                $ret[] = $this->packRequest_($item);
            }
        } else {
            $ret = $this->packRequest_($req);
        }

        return json_encode($ret);
    }

    private function unpackRequest_($raw)
    {
        $ret = false;

        do {
            if (!is_array($raw)) {
                break;
            }

            // strict check
            // if (!isset($raw['jsonrpc']) || $raw['jsonrpc'] != '2.0') {
                // break;
            // }

            if (isset($raw['method'])) {
                $ret = Request::create($raw['method']);
            } else {
                break;
            }

            if (array_key_exists('id', $raw)) {
                $ret->id = $raw['id'];
            }

            if (array_key_exists('params', $raw)) {
                $ret->params = $raw['params'];
            }
        } while (0);

        return $ret;
    }

    public function decodeRequest($str)
    {
        $ret = false;
        $data = json_decode($str, true);

        do {
            if (!is_array($data)) {
                break;
            }

            if (isset($data['method'])) {
                $ret = $this->unpackRequest_($data);
            } else {
                // may be batch
                $ret = [];

                foreach ($data as $raw) {
                    $ret[] = $this->unpackRequest_($raw);
                }
            }
        } while (0);

        return $ret;
    }

    private function packResponse_($rep)
    {
        $ret = array('jsonrpc' => '2.0');

        if ($rep instanceof Success) {
            $ret['result'] = $rep->result;
        } else {
            $ret['error'] = array('code' => $rep->error->code);

            if (property_exists($rep->error, 'message')) {
                $ret['error']['message'] = $rep->error->message;
            }

            if (property_exists($rep->error, 'data')) {
                $ret['error']['data'] = $rep->error->data;
            }
        }

        if (property_exists($rep, 'id')) {
            $ret['id'] = $rep->id;
        }

        return $ret;
    }

    public function encodeResponse($rep)
    {
        $data = null;

        if (is_array($rep)) {
            $data = [];

            foreach ($rep as $item) {
                $data[] = $this->packResponse_($item);
            }
        } else {
            $data = $this->packResponse_($rep);
        }

        return json_encode($data);
    }

    private function unpackResponse_($raw)
    {
        $ret = false;

        do {
            if (!is_array($raw)) {
                break;
            }

            // strict check
            // if (!isset($raw['jsonrpc']) || $raw['jsonrpc'] != '2.0') {
                // break;
            // }

            if (array_key_exists('error', $raw)) {
                $ret = Response::error($raw['error']);
            } elseif (array_key_exists('result', $raw)) {
                $ret = Response::success($raw['result']);
            } else {
                break;
            }

            if (array_key_exists('id', $raw)) {
                $ret->id = $raw['id'];
            }
        } while (0);

        return $ret;
    }

    public function decodeResponse($str)
    {
        $ret = false;
        $data = json_decode($str, true);

        do {
            if (!is_array($data)) {
                break;
            }

            if (isset($data['result']) || isset($data['error'])) {
                $ret = $this->unpackResponse_($data);
            } else {
                // may be batch
                $ret = [];

                foreach ($data as $raw) {
                    $ret[] = $this->unpackResponse_($raw);
                }
            }
        } while (0);

        return $ret;
    }
}
