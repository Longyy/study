<?php
/**
 * protocol interface for message
 *
 * @author Yuan B.J.
 * @copyright Yuan B.J., 2014.09.17
 */

namespace Paf\LightService\Core\Message\Protocol;

interface Protocol
{
    public function encodeRequest($req);
    public function decodeRequest($req);
    public function encodeResponse($rep);
    public function decodeResponse($rep);
}
