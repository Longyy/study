<?php
/**
 * Request structure of LightService
 *
 * @author Yuan B.J.
 * @copyright Yuan B.J., 2014.09.17
 */

namespace Paf\LightService\Core\Message\Request;

class Request
{
    // If it is not included it is assumed to be a notification.
    // public $id;
    // This member MAY be omitted.
    // public $params;
    public $method;

    public static function create($method, $params = null, $id = null)
    {
        $req         = new static;
        $req->method = $method;

        $num_args = func_num_args();

        if ($num_args > 1) {
            $req->params = $params;
        }

        if ($num_args > 2) {
            $req->id = $id;
        }

        return $req;
    }
}
