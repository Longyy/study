<?php
/**
 * the carrier of lightservice's response
 *
 * @author Yuan B.J.
 * @copyright Yuan B.J., 2015.03.11
 */

namespace Paf\LightService\Server;

class Response
{
    public $reply;

    public function __construct($reply)
    {
        $this->reply = $reply;
    }
}
