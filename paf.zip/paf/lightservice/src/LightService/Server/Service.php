<?php
/**
 * rpc service factory
 *
 * @author Yuan B.J.
 * @copyright Yuan B.J., 2014.10.23
 */

namespace Paf\LightService\Server;

use Paf\LightService\Core\Constant\Status;
use Paf\LightService\Core\Message\Protocol;
use Paf\LightService\Core\Message\Response\Response;
use Paf\LightService\Core\Util\Errorable;
use Paf\LightService\Core\Util\EventEmitter;

class Service extends Errorable
{
    private $lookup_   = null;
    private $protocol_ = null;
    private $module_   = array();
    private $method_   = array();
    private $exception_handler_ = null;

    public static function create($protocol, $lookup = null, $exception_handler = null)
    {
        $service = new static;

        if (is_object($protocol) && $protocol instanceof Protocol\Protocol) {
            $service->protocol_ = $protocol;
        } else {
            switch ($protocol) {
                case 'jsonrpc':
                    $service->protocol_ = new Protocol\JsonRpc;
                    break;
                case 'local':
                    break;
                default:
                    return false;
            }
        }

        $service->lookup_ = $lookup;

        if (isset($exception_handler)) {
            $service->exception_handler_ = function ($e, &$reply) use ($exception_handler) {
                try {
                    $result = call_user_func_array($exception_handler, array($e, &$reply, &$force_success));

                    if ($force_success) {
                        $reply = Response::success($result);
                    }
                } catch (\Exception $e) {
                    throw $e;
                }
            };
        }

        return $service;
    }

    public static function ret($reply)
    {
        return new \Paf\LightService\Server\Response($reply);
    }

    public function registerModule($name, $class)
    {
        $this->module_[$name] = $class;
        return $this;
    }

    /**
     * register method for rpc
     * @param $name method name
     *
     * @return $this
     */
    public function register($name, $fn)
    {
        $this->method_[$name] = $fn;
        return $this;
    }

    public function lookupInternal_($module, $method, $params, $id = null)
    {
        $ret = false;

        do {
            if (isset($this->method_[$method])) {
                $ret = $this->method_[$method];
                break;
            }

            if (isset($this->module_[$module])) {
                $module = $this->module_[$module];
                $m = null;

                if (is_object($module)) {
                    $m = $module;
                } elseif (is_callable($module)) {
                    $m = $module();
                } else {
                    $m = new $module;
                }

                if (!method_exists($m, $method)) {
                    $ret = false;
                    break;
                }

                $ret = array($m, $method);
            }
        } while (0);

        if (false === $ret && $this->lookup_) {
            $ret = call_user_func($this->lookup_, $module, $method, $params, $id);
        }

        return $ret;
    }

    public function invoke($module, $method, $params, $id = null)
    {
        $ret = null;
        $callable = $this->lookupInternal_($module, $method, $params, $id);

        if (is_callable($callable)) {
            $ret = call_user_func_array($callable, $params);
        } elseif ($callable instanceof \Paf\LightService\Server\Response) {
            $ret = $callable->reply;
        } else {
            throw new \BadMethodCallException();
        }

        return $ret;
    }

    public function invokeMethod($method, $params, $id = null)
    {
        $rc = preg_match(
            '#(?:(?P<module>[\w|\\\\|:]+)\.)?(?P<method>.+)#',
            $method,
            $match
        );

        if ($rc <= 0) {
            throw new \BadMethodCallException();
        }

        $method = null;

        if (isset($match['method']) && !empty($match['method'])) {
            $method = $match['method'];
        } else {
            throw new BadMethodCallException();
        }

        $module = null;

        if (isset($match['module']) && !empty($match['module'])) {
            $module = $match['module'];
        }

        return $this->invoke($module, $method, $params, $id);
    }

    public function dispatch($req)
    {
        $reply = null;
        self::emit('request.start', array('request' => $req));

        do {
            $rc = preg_match(
                '#(?:(?P<module>[\w|\\\\|:]+)\.)?(?P<method>.+)#',
                $req->method,
                $match
            );

            if ($rc <= 0) {
                $reply = Response::error(Status::INVALID_REQUEST);

                if (property_exists($req, 'id')) {
                    $reply->id = $req->id;
                }

                self::emit('request.end', array('request' => $req, 'response' => $reply));
                break;
            }

            $method = null;

            if (isset($match['method']) && !empty($match['method'])) {
                $method = $match['method'];
            } else {
                $reply = Response::error(Status::INVALID_REQUEST);

                if (property_exists($req, 'id')) {
                    $reply->id = $req->id;
                }

                self::emit('request.end', array(
                    'request' => $req,
                    'error' => array(
                        'code' => Status::INVALID_REQUEST,
                        'message' => ''
                    )
                ));

                break;
            }

            $module = null;

            if (isset($match['module']) && !empty($match['module'])) {
                $module = $match['module'];
            }

            $params = property_exists($req, 'params') ? (array)$req->params : array();
            $callable = null;

            try {
                $result = null;

                if (property_exists($req, 'id')) {
                    $result = $this->invoke($module, $method, $params, $req->id);
                    // $callable = $this->lookupInternal_($module, $method, $params, $req->id);
                } else {
                    $result = $this->invoke($module, $method, $params);
                    // $callable = $this->lookupInternal_($module, $method, $params);
                }

                $reply = Response::success($result);
                self::emit('request.end', array('request' => $req, 'response' => $reply));
            } catch (\BadMethodCallException $e) {
                $this->setErr(Status::METHOD_NOT_EXISTS, Status::desc(Status::METHOD_NOT_EXISTS));
                $reply = Response::error(array(
                    'code'    => Status::METHOD_NOT_EXISTS,
                    'message' => Status::desc(Status::METHOD_NOT_EXISTS)
                ));

                if ($this->exception_handler_) {
                    $result = call_user_func_array($this->exception_handler_, array($e, &$reply));
                }

                self::emit('request.end', array(
                    'request' => $req,
                    'error' => array(
                        'code' => $reply->error->code,
                        'message' => $reply->error->message
                    )
                ));
            } catch (\InvalidArgumentException $e) {
                $this->setErr(Status::INVALID_PARAMS, (string)$e);
                $reply = Response::error(array(
                    'code'    => Status::INVALID_PARAMS,
                    'message' => $e->getMessage()
                ));

                if ($this->exception_handler_) {
                    $result = call_user_func_array($this->exception_handler_, array($e, &$reply));
                }

                self::emit('request.end', array(
                    'request' => $req,
                    'error' => array(
                        'code' => $reply->error->code,
                        'message' => $reply->error->message
                    )
                ));
            } catch (\Exception $e) {
                $this->setErr(Status::INTERNAL_ERROR, (string)$e);
                $reply = Response::error(array(
                    'code'    => Status::INTERNAL_ERROR,
                    'message' => $e->getMessage()
                ));

                if ($this->exception_handler_) {
                    $result = call_user_func_array($this->exception_handler_, array($e, &$reply));
                }

                self::emit('request.end', array(
                    'request' => $req,
                    'error' => array(
                        'code' => $reply->error->code,
                        'message' => $reply->error->message
                    )
                ));
            }

            if (property_exists($req, 'id')) {
                $reply->id = $req->id;
            }
        } while (0);

        return $reply;
    }

    public function respond($msg)
    {
        $this->clearErr();
        $reply = null;

        do {
            $req = $this->protocol_->decodeRequest($msg);
            // print_r($req);

            if (false === $req) {
                $reply = Response::error(Status::INVALID_REQUEST);
                break;
            }

            if (is_array($req)) {
                $reply = [];

                foreach ($req as $item) {
                    $reply[] = $this->dispatch($item);
                }
            } else {
                $reply = $this->dispatch($req);
            }
        } while (0);

        return $this->protocol_->encodeResponse($reply);
    }

    public function respondWith($reply, $id = null)
    {
        return $this->protocol_->encodeResponse(Response::success($reply, $id));
    }

    public static function on($event, $handler)
    {
        return EventEmitter::getInstance()->on($event, $handler);
    }

    public static function off($event = null, $handler = null)
    {
        return EventEmitter::getInstance()->off($event, $handler);
    }

    public static function emit()
    {
        return call_user_func_array(array(EventEmitter::getInstance(), 'emit'), func_get_args());
    }
}
