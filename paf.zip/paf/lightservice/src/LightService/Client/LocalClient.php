<?php
/**
 * real client for local invoker
 *
 * @author Yuan B.J.
 */

namespace Paf\LightService\Client;

use Paf\LightService\Core\Util\Errorable;

class LocalClient extends Errorable
{
    private $service_ = null;

    public function __construct($service)
    {
        $this->service_ = $service;
    }

    public function module($name)
    {
        return new Ghost($this, $name);
    }

    public function call($method, $params = null)
    {
        $this->clearErr();
        $ret = false;

        try {
            $ret = $this->service_->invokeMethod($method, $params);
        } catch (\Exception $e) {
            $this->setErr($e->getCode(), $e->getMessage());
        }

        return $ret;
    }
}
