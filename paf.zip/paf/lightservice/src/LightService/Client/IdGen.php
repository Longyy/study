<?php
/**
 * id generator of client's message
 * you could override the default generator by assign $generator
 *
 * @author Yuan B.J.
 * @copyright Yuan B.J., 2015.06.10
 */

namespace Paf\LightService\Client;

use Paf\LightService\Util\ObjectId;

class IdGen
{
    public static $generator = null;

    public static function defaultGenerator()
    {
        return ObjectId::generate();
    }

    public static function nextId()
    {
        return self::$generator ? call_user_func(self::$generator) : self::defaultGenerator();
    }
}
