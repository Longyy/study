<?php
/**
 * Global service locator
 *
 * @author Yuan B.J.
 * @copyright Yuan B.J., 2014.09.17
 */

namespace Paf\LightService\Client;

use Paf\LightService\Core\Message\Protocol;
use Paf\LightService\Core\Transport;
use Paf\LightService\Core\Util\EventEmitter;

class Service
{
    static private $shared_  = array();
    static private $conf_   = array();

    public static function importConf($conf)
    {
        self::$conf_ = array_merge(self::$conf_, $conf);
        return true;
    }

    public static function createLocalService($name)
    {
        return new LocalClient(self::$conf_[$name]['conf']['service']);
    }

    public static function createService($name)
    {
        $ret = false;
        $options = array();

        if (isset(self::$conf_[$name])) {
            switch (self::$conf_[$name]['type']) {
                case 'http':
                    $transport = new Transport\Http;
                    $conf = self::$conf_[$name]['conf'];
                    $header = (isset($conf['header']) && is_array($conf['header'])) ?  $conf['header'] : [];

                    // patch for paf environment, with X-Request-Id, X-Request-Tag

                    if ($request_id = getenv('X_REQUEST_ID')) {
                        $header[] = sprintf('X-Request-Id: %s', $request_id);
                    } elseif (isset($_SERVER['HTTP_X_REQUEST_ID'])) {
                        $header[] = sprintf('X-Request-Id: %s', $_SERVER['HTTP_X_REQUEST_ID']);
                    } else {
                        // ...
                    }

                    if ($request_tag = getenv('X_REQUEST_TAG')) {
                        $header[] = sprintf('X-Request-Tag: %s', $request_tag);
                    } elseif (isset($_SERVER['HTTP_X_REQUEST_TAG'])) {
                        $header[] = sprintf('X-Request-Tag: %s', $_SERVER['HTTP_X_REQUEST_TAG']);
                    } else {
                        // ...
                    }

                    if (array_key_exists('with_header', self::$conf_[$name]['conf']) &&
                        self::$conf_[$name]['conf']['with_header'] &&
                        'jsonrpc' === self::$conf_[$name]['protocol']
                    ) {
                        $header[] = 'Content-Type: application/json';
                    }

                    if (!empty($header)) {
                        $conf['header'] = $header;
                    }

                    $rc = $transport->init($conf);

                    if ($rc === false) {
                        return false;
                    }

                    if (array_key_exists('digest', self::$conf_[$name]['conf'])) {
                        if (false === self::$conf_[$name]['conf']['digest']) {
                            break;
                        } elseif (self::$conf_[$name]['conf']['digest'] !== true) {
                            $options['digest'] = self::$conf_[$name]['conf']['digest'];
                            break;
                        } else {
                            // ...
                        }
                    } else {
                        // default - enable
                    }

                    $options['digest'] = function($req) {
                        $digest = [];

                        if (!is_array($req)) {
                            $req = array($req);
                        }

                        foreach ($req as $item) {
                            $digest[] = sprintf('%s[%s]', $item->method, $item->id);
                        }

                        return sprintf('__digest=%s', implode(',', $digest));
                    };

                    break;

                case 'zmq':
                    $transport = new Transport\Zmq;
                    $rc = $transport->init(self::$conf_[$name]['conf']);

                    if ($rc === false) {
                        return false;
                    }

                    break;

                case 'queue':
                    $transport = new Transport\Queue;
                    $rc = $transport->init(self::$conf_[$name]['conf']);

                    if ($rc === false) {
                        return false;
                    }

                    break;

                case 'local':
                    return self::createLocalService($name);
            }

            switch (self::$conf_[$name]['protocol']) {
                case 'jsonrpc':
                    $protocol = new Protocol\JsonRpc;
                    break;
                default:
                    $protocol = self::$conf_[$name]['protocol'];

                    if (!is_object($protocol) ||
                        !($protocol instanceof Protocol\Protocol)
                    ) {
                        return false;
                    }
            }

            $ret = new Client($transport, $protocol, $options);
        }

        return $ret;
    }

    public static function get($name, $shared = false)
    {
        if ($shared && isset(self::$shared_[$name])) {
            return self::$shared_[$name];
        }

        $service = self::createService($name);

        if ($shared && $service) {
            self::$shared_[$name] = $service;
        }

        return $service;
    }

    private static $batch_state_ = array(
        'started' => false,
        'calls'   => array()
    );

    public static function batchBegin()
    {
        self::$batch_state_['started'] = true;
    }

    public static function batchClear()
    {
        self::$batch_state_['started'] = false;
        self::$batch_state_['calls']   = array();
    }

    public static function batchCommit(&$err = null)
    {
        $reps = Client::multiCall(self::$batch_state_['calls'], $err);
        self::batchClear();
        return $reps;
    }

    public static function call($call, $params, &$err = null)
    {
        $ret = false;
        $rc = preg_match('/((?:[\w|\-])+)::(.+)/', $call, $matches);

        if ($rc) {
            $ns     = $matches[1];
            $method = $matches[2];
            $client = self::get($ns);

            if (self::$batch_state_['started']) {
                self::$batch_state_['calls'][] = array($client, $method, $params);
                $ret = true;
            } else {
                $ret = $client->call($method, $params);

                if ($client->errno()) {
                    $err = $client->errstr();
                }
            }
        }

        return $ret;
    }

    public static function batchCall($calls, &$err)
    {
        self::batchBegin();

        foreach ($calls as $call) {
            if (isset($call[1])) {
                self::call($call[0], $call[1]);
            } else {
                self::call($call[0]);
            }
        }

        return self::batchCommit($err);
    }

    public static function on($event, $handler)
    {
        return EventEmitter::getInstance()->on($event, $handler);
    }

    public static function off($event = null, $handler = null)
    {
        return EventEmitter::getInstance()->off($event, $handler);
    }

    public static function emit()
    {
        return call_user_func_array(array(EventEmitter::getInstance(), 'emit'), func_get_args());
    }
}
