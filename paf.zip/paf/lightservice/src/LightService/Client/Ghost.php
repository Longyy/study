<?php
/**
 * common proxy for module call
 *
 * @author Yuan B.J.
 * @copyright Yuan B.J., 2014.09.17
 */

namespace Paf\LightService\Client;

use Paf\LightService\Core\Util\Errorable;

class Ghost extends Errorable
{
    private $client_ = null;
    private $module_ = null;

    public function __construct($client, $module)
    {
        $this->client_ = $client;
        $this->module_ = $module;
    }

    public function __call($method, $params)
    {
        $this->clearErr();
        $ret = $this->client_->call($this->module_ . '.' . $method, $params);

        if ($this->client_->errno()) {
            $this->setErr($this->client_->errno(), $this->client_->errstr());
        }

        return $ret;
    }
}
