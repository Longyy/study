<?php
/**
 * real client for rpc
 *
 * @author Yuan B.J.
 */

namespace Paf\LightService\Client;

use Paf\LightService\Core\Constant\Status;
use Paf\LightService\Core\Message\Request\Request;
use Paf\LightService\Core\Message\Response\Response;
use Paf\LightService\Core\Util\Errorable;

class Client extends Errorable
{
    private $transport_ = null;
    private $protocol_  = null;
    private $digest_    = null;

    public function __construct($transport, $protocol, $options = array())
    {
        $this->transport_ = $transport;
        $this->protocol_  = $protocol;

        if (isset($options['digest'])) {
            $this->digest_ = $options['digest'];
        }
    }

    public function module($name)
    {
        return new Ghost($this, $name);
    }

    public function batchCall($calls, &$err = null)
    {
        $this->clearErr();
        $ret = false;
        $reqs = array();

        foreach ($calls as $call) {
            $reqs[] = Request::create($call[0], isset($call[1]) ? $call[1] : null, IdGen::nextId());
        }

        try {
            $msg = $this->protocol_->encodeRequest($reqs);
        } catch (\Exception $e) {
            $msg = false;
        }

        foreach ($reqs as $req) {
            Service::emit('request.start', array('request' => $req));
        }

        if (false === $msg) {
            $this->setErr(
                Status::INVALID_REQUEST,
                sprintf(
                    '%s. failed to encode reqs: "%s".',
                    Status::desc(Status::INVALID_REQUEST),
                    print_r($reqs, true)
                )
            );

            foreach ($reqs as $req) {
                Service::emit(
                    'request.end',
                    array(
                        'request' => $req,
                        'error' => array('code' => $this->errno(), 'message' => $this->errstr())
                    )
                );
            }

            $err = $this->errstr();
            return false;
        }

        if (isset($this->digest_)) {
            $reply = $this->transport_->send($msg, call_user_func($this->digest_, $reqs));
        } else {
            $reply = $this->transport_->send($msg);
        }

        if (true === $reply) {
            $ret = true;

            foreach ($reqs as $req) {
                Service::emit('request.end', array('request' => $req, 'response' => true));
            }
        } elseif (false === $reply) {
            $this->setErr(
                Status::TRANSPORT_ERROR,
                sprintf(
                    '%s. failed to transport: "%s"',
                    Status::desc(Status::TRANSPORT_ERROR),
                    $this->transport_->errstr()
                )
            );

            foreach ($reqs as $req) {
                Service::emit(
                    'request.end',
                    array(
                        'request' => $req,
                        'error' => array('code' => $this->errno(), 'message' => $this->errstr())
                    )
                );
            }
        } else {
            $rep = $this->protocol_->decodeResponse($reply);

            if (is_array($rep)) {
                $ret = array();
                $error = array();
                $has_error = false;

                foreach ($rep as $i => $item) {
                    if (isset($item->error)) {
                        $ret[]   = null;
                        $errstr  = sprintf(
                            '#%d %s',
                            $i,
                            $item->error->message ? $item->error->message : Status::desc($item->error->code)
                        );
                        $error[] = $errstr;

                        Service::emit(
                            'request.end',
                            array(
                                'request' => $req,
                                'error' => array('code' => $item->error->code, 'message' => $errstr)
                            )
                        );
                    } else {
                        $ret[]   = $item->result;
                        $error[] = null;

                        Service::emit(
                            'request.end',
                            array(
                                'request' => $reqs[$i],
                                'response' => $item
                            )
                        );
                    }
                }

                if ($has_error) {
                    $err = $error;
                }
            } else {
                if (false === $rep) {
                    $this->setErr(
                        Status::INTERNAL_ERROR,
                        sprintf(
                            '%s. failed to decode rep: "%s". (req: "%s")',
                            Status::desc(Status::INTERNAL_ERROR),
                            $reply,
                            $msg
                        )
                    );
                } elseif (isset($rep->error)) {
                    $this->setErr(
                        Status::INTERNAL_ERROR,
                        $rep->error->message ? $rep->error->message : Status::desc($rep->error->code)
                    );
                } else {
                    $this->setErr(
                        Status::INTERNAL_ERROR,
                        sprintf(
                            '%s. failed to decode batch rep: "%s". (req: "%s")',
                            Status::desc(Status::INTERNAL_ERROR),
                            $reply,
                            $msg
                        )
                    );
                }

                $err = $this->errstr();

                Service::emit(
                    'request.end',
                    array(
                        'request' => $req,
                        'error' => array('code' => $this->errno(), 'message' => $this->errstr())
                    )
                );
            }
        }

        return $ret;
    }

    public function call($method, $params = null)
    {
        $this->clearErr();
        $ret = false;

        $req = Request::create($method, $params, IdGen::nextId());
        Service::emit('request.start', array('request' => $req));

        try {
            $msg = $this->protocol_->encodeRequest($req);
        } catch (\Exception $e) {
            $msg = false;
        }

        if (false === $msg) {
            $this->setErr(
                Status::UNSUPPORTED_ENCODING,
                sprintf(
                    '%s. failed to encode req: "%s"',
                    Status::desc(Status::UNSUPPORTED_ENCODING),
                    print_r($req, true)
                )
            );

            Service::emit(
                'request.end',
                array(
                    'request' => $req,
                    'error' => array('code' => $this->errno(), 'message' => $this->errstr())
                )
            );

            return false;
        }

        $reply = null;

        if (isset($this->digest_)) {
            $reply = $this->transport_->send($msg, call_user_func($this->digest_, $req));
        } else {
            $reply = $this->transport_->send($msg);
        }

        if (true === $reply) {
            Service::emit('request.end', array('request' => $req, 'response' => true));
            $ret = true;
        } elseif (false === $reply) {
            $this->setErr(
                Status::TRANSPORT_ERROR,
                sprintf(
                    '%s. failed to transport: "%s"',
                    Status::desc(Status::TRANSPORT_ERROR),
                    $this->transport_->errstr()
                )
            );

            Service::emit(
                'request.end',
                array(
                    'request' => $req,
                    'error' => array('code' => $this->errno(), 'message' => $this->errstr())
                )
            );
        } else {
            $rep = $this->protocol_->decodeResponse($reply);

            if (!$rep) {
                $this->setErr(
                    Status::INTERNAL_ERROR,
                    sprintf(
                        '%s. failed to decode rep: "%s". (req: "%s")',
                        Status::desc(Status::INTERNAL_ERROR),
                        $reply,
                        $msg
                    )
                );

                Service::emit(
                    'request.end',
                    array(
                        'request' => $req,
                        'error' => array('code' => $this->errno(), 'message' => $this->errstr())
                    )
                );
            } elseif (isset($rep->error)) {
                $this->setErr(
                    $rep->error->code,
                    $rep->error->message ? $rep->error->message : Status::desc($rep->error->code)
                );

                Service::emit(
                    'request.end',
                    array(
                        'request' => $req,
                        'error' => array('code' => $this->errno(), 'message' => $this->errstr())
                    )
                );
            } else {
                $ret = $rep->result;
                Service::emit('request.end', array('request' => $req, 'response' => $rep));
            }
        }

        return $ret;
    }

    public function preCall_($req)
    {
        $ret = false;
        $this->clearErr();

        try {
            $msg = $this->protocol_->encodeRequest($req);
        } catch (\Exception $e) {
            $msg = false;
        }

        if (false === $msg) {
            $this->setErr(
                Status::UNSUPPORTED_ENCODING,
                sprintf(
                    '%s. failed to encode req: "%s".',
                    Status::desc(Status::UNSUPPORTED_ENCODING),
                    print_r($req, true)
                )
            );
        } else {
            if (isset($this->digest_)) {
                $ret = $this->transport_->preSend($msg, call_user_func($this->digest_, $req));
            } else {
                $ret = $this->transport_->preSend($msg);
            }
        }

        return $ret;
    }

    public function postCall_($reply)
    {
        $ret = false;

        if (false === $reply) {
            $this->setErr(
                Status::TRANSPORT_ERROR,
                sprintf(
                    '%s. failed to transport: "%s"',
                    Status::desc(Status::TRANSPORT_ERROR),
                    $this->transport_->errstr()
                )
            );
        } else {
            $rep = $this->protocol_->decodeResponse($reply);

            if (!$rep) {
                $this->setErr(
                    Status::INTERNAL_ERROR,
                    sprintf(
                        '%s. failed to decode rep: "%s".',
                        Status::desc(Status::INTERNAL_ERROR),
                        $reply
                    )
                );
            } elseif (isset($rep->error)) {
                $this->setErr(
                    $rep->error->code,
                    $rep->error->message ? $rep->error->message : Status::desc($rep->error->code)
                );
            } else {
                $ret = $rep->result;
            }
        }

        return $ret;
    }

    static public function multiCall($calls, &$err = null)
    {
        $ret = false;
        $transports = array();
        $clients = array();
        $failed = array();
        $requests = array();

        foreach ($calls as $call) {
            $client = $call[0];
            $method = $call[1];
            $params = isset($call[2]) ? $call[2] : null;
            $req = Request::create($method, $params, IdGen::nextId());
            Service::emit('request.start', array('request' => $req));
            $success = $client->preCall_($req);

            if ($success) {
                $transports[] = $client->transport_;
                $failed[] = false;
            } else {
                $failed[] = true;
            }

            $clients[] = $client;
            $requests[] = $req;
        }

        // batchCall should be all the same type(zmq/http)
        $class = get_class($transports[0]);
        $wait_err = null;
        $msgs = $class::wait($transports, $err);

        if ($wait_err) {
            $err = $wait_err;

            foreach ($requests as $req) {
                Service::emit(
                    'request.end',
                    array(
                        'request' => $req,
                        'error' => array('code' => Status::TRANSPORT_ERROR, 'message' => $err)
                    )
                );
            }
        } else {
            $ret       = array();
            $error     = array();
            $has_error = false;

            foreach ($clients as $i => $client) {
                $req = $requests[$i];

                if ($failed[$i]) {
                    $error[]   = sprintf('#%d %s', $i, $client->errstr());
                    $ret[]     = null;
                    $has_error = true;

                    Service::emit(
                        'request.end',
                        array(
                            'request' => $req,
                            'error' => array('code' => $client->errno(), 'message' => $client->errstr())
                        )
                    );
                } else {
                    $rep = $client->postCall_(array_shift($msgs));

                    if ($client->errno()) {
                        $error[]   = sprintf('#%d %s', $i, $client->errstr());
                        $ret[]     = null;
                        $has_error = true;

                        Service::emit(
                            'request.end',
                            array(
                                'request' => $req,
                                'error' => array('code' => $client->errno(), 'message' => $client->errstr())
                            )
                        );
                    } else {
                        $error[] = null;
                        $ret[]   = $rep;
                        Service::emit('request.end', array('request' => $req, 'response' => $rep));
                    }
                }
            }

            if ($has_error) {
                $err = $error;
            }
        }

        return $ret;
    }
}
