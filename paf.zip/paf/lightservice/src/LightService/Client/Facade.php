<?php
/**
 * module client's facade
 *
 * @author Yuan B.J.
 * @copyright Yuan B.J., 2015.10.19
 */

namespace Paf\LightService\Client;

class Facade
{
    public $service = null;
    public $module  = null;

    private $service_ = null;

    public function __construct()
    {
        $this->service_ = Service::get($this->service)->module($this->module);
    }

    public function __call($method, $args)
    {
        return call_user_func_array(array($this->service_, $method), $args);
    }
}
