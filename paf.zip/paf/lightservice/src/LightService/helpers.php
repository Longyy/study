<?php
/**
 * helper api of lightservice
 *
 * @author Yuan B.J.
 * @copyright Yuan B.J., 2015.03.19
 */

use Paf\LightService\Client\Service;

function lightservice_init($conf)
{
    Service::importConf($conf);
}

function lightservice_call($method, $params, &$err = null)
{
    return Service::call($method, $params, $err);
}

function lightservice_batch_call($calls, &$err = null)
{
    return Service::batchCall($calls, $err);
}

function lightservice_explore($module, &$err = null) {
    return Service::call($module . '.__explore', [], $err);
}
