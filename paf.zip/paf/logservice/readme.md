## logservice✨

[老框架日志服务接入](http://git.ipo.com/hf-estate-specialist/journal-client/tree/old-frame)

## laravel日志服务接入

### 引入服务

composer追加

```
"repositories": [
    {"type": "vcs", "url": "git@git.ipo.com:hf-estate-specialist/journal-client.git"}
],
"require": {
    "paf/logservice": "~1.0"
},
```

执行 `composer install`

## 配置

config/services 追加

```
'log'      => [
    'enable'   => true, // 是否启用
    'from'     => 'overseas-service', // 当前仓库名
    'level'    => \Monolog\Logger::DEBUG, // 日志记录级别(≥)
    // DEBUG     = 100
    // INFO      = 200
    // NOTICE    = 250
    // WARNING   = 300
    // ERROR     = 400
    // CRITICAL  = 500
    // ALERT     = 550
    // EMERGENCY = 600

    'driver'   => 'curl',
    // curl
    // redis
    // rabbitmq

    'curl' => [
        'url' => 'journal.polaris.s.dev.anhouse.com.cn/2.0/journal', // 日志服务地址
    ],

    'redis' => [
        'host'     => '10.59.72.31',
        'port'     => 6379,
        'database' => 15,
        // https://github.com/nrk/predis/wiki/Connection-Parameters
    ],

    'rabbitmq' => [
        'host'     => '10.59.72.51',
        'port'     => 5672,
        'vhost'    => '/logs/',
        'user'     => 'admin',
        'password' => 'admin',
        // https://github.com/videlalvaro/php-amqplib/blob/v2.5.2/PhpAmqpLib/Connection/AMQPStreamConnection.php
    ],
],
```

config/app 追加

```
'providers' => [
    'Paf\LogService\Providers\LogServiceProvider',
]
```

## 使用

[http://laravel.com/docs/5.1/errors#logging](http://laravel.com/docs/5.1/errors#logging)
