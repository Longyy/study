<?php
namespace Paf\LogService;

use Monolog\Handler\BufferHandler;
use Monolog\Logger;
use Paf\LightService\Client\Service;
use Paf\LogService\AMQPStreamConnection;
use Paf\LogService\Configuration;
use Paf\LogService\Formatters\LogServiceFormatter;
use Paf\LogService\Handlers\LogServiceHandler;
use Paf\LogService\Monolog;
use Paf\LogService\Request;
use PhpAmqpLib\Message\AMQPMessage;

class Bootstrap
{
    public static function boot()
    {
        if (Configuration::get('enable', false)) {
            static::registerSender(Configuration::get('driver', 'curl'));
            $logServiceHandler   = new LogServiceHandler(Configuration::get('level', Logger::DEBUG));
            $logServiceFormatter = static::getFormatter();
            $logServiceHandler->setFormatter($logServiceFormatter);

            if (Configuration::get('buffer', true)) {
                $bufferedLogServiceHandler = new BufferHandler($logServiceHandler, Configuration::get('size', 500), Configuration::get('level', Logger::DEBUG), true, true);
                Monolog::get()->pushHandler($bufferedLogServiceHandler);
            } else {
                Monolog::get()->pushHandler($logServiceHandler);
            }
        }
    }

    protected static function registerSender($name)
    {
        static::{'set' . ucfirst($name) . 'Sender'}();
    }

    protected static function setRedisSender()
    {
        LogServiceHandler::setSender(function ($messages) {
            // config
            Service::importConf(
                [
                    'logservice' => [
                        'type'     => 'queue',
                        'protocol' => 'jsonrpc',
                        'conf'     => [
                            'push' => function ($message) {
                                $client = new \Predis\Client(Configuration::get('redis'));
                                $client->rpush('log-service-queue', $message);
                                $client->disconnect();
                                return true;
                            },
                        ],
                    ],
                ]
            );

            // get service
            $s = Service::get('logservice');

            // get specified module
            $queue = $s->module('QueueHandler');

            // 过滤非utf8字符
            $messages = json_decode(@json_encode($messages), true);
            $queue->handle($messages);

            if ($queue->errno()) {
                error_log('[' . $queue->errno() . '] ' . $queue->errstr());
            }
        });
    }

    protected static function setCurlSender()
    {
        LogServiceHandler::setSender(function ($messages) {
            $curl = curl_init();

            curl_setopt_array($curl, [
                CURLOPT_URL            => Configuration::get('curl.url', Configuration::get('url', '')),
                CURLOPT_RETURNTRANSFER => true,
                CURLOPT_TIMEOUT        => Configuration::get('curl.timeout', 10),
                CURLOPT_POST           => true,
                CURLOPT_HTTPHEADER     => ['Content-type: application/json'],
                CURLOPT_POSTFIELDS     => @json_encode($messages),
            ]);

            curl_exec($curl);
            $err = curl_error($curl);

            curl_close($curl);

            if ($err) {
                error_log($err);
            }
        });
    }

    protected static function setRabbitmqSender()
    {
        LogServiceHandler::setSender(function ($messages) {
            // config
            Service::importConf(
                [
                    'logservice' => [
                        'type'     => 'queue',
                        'protocol' => 'jsonrpc',
                        'conf'     => [
                            'push' => function ($messages) {
                                $connection = AMQPStreamConnection::get(Configuration::get('rabbitmq'));
                                $channel    = $connection->channel();

                                $channel->exchange_declare('log-service-exchange', 'direct', false, true, false);
                                $channel->queue_declare('log-service-queue', false, false, false, false);
                                $channel->queue_bind('log-service-queue', 'log-service-exchange');

                                $msg = new AMQPMessage($messages);

                                $channel->basic_publish($msg, 'log-service-exchange');

                                $channel->close();
                                $connection->close();
                                return true;
                            },
                        ],
                    ],
                ]
            );

            // get service
            $s = Service::get('logservice');

            // get specified module
            $queue = $s->module('QueueHandler');

            // 过滤非utf8字符
            $messages = json_decode(@json_encode($messages), true);
            $queue->handle($messages);

            if ($queue->errno()) {
                error_log('[' . $queue->errno() . '] ' . $queue->errstr());
            }
        });
    }

    protected static function getFormatter()
    {
        LogServiceFormatter::setGuidResolver(function () {
            return Request::guid();
        });
        return new LogServiceFormatter(
            Configuration::get('from', 'unknow'),
            Request::ip(),
            Request::serverIp(),
            Request::url(),
            Request::method()
        );
    }
}
