<?php
namespace Paf\LogService;

class Request
{
    public static function guid()
    {
        if (!($guid = app('request')->cookie('guid', null))) {
            $guid = app('request')->header('GUID', null);
        }
        return $guid;
    }

    public static function ip()
    {
        return app('request')->ip();
    }

    public static function url()
    {
        return app('request')->url();
    }

    public static function method()
    {
        return app('request')->method();
    }

    public static function serverIp()
    {
        return app('request')->server('SERVER_ADDR');
    }
}
