<?php
namespace Paf\LogService;

class Monolog
{
    public static function get()
    {
        return app('log')->getMonolog();
    }
}
