<?php

namespace Paf\LogService\Handlers;

use Closure;
use Monolog\Handler\AbstractHandler;
use Paf\LogService\Formatters\LogServiceFormatter;

class LogServiceHandler extends AbstractHandler
{
    protected static $sender;

    public function __construct($level = Logger::DEBUG, $bubble = true)
    {
        $this->bubble  = $bubble;
        $this->setLevel($level);
    }

    public function handle(array $record)
    {
        $this->handleBatch([$record]);
        return false === $this->bubble;
    }

    public function handleBatch(array $records)
    {
        $messages = [];

        foreach ($records as $record) {
            if ($record['level'] < $this->level) {
                continue;
            }
            $messages[] = $this->processRecord($record);
        }

        if (!empty($messages)) {
            $messages = $this->getFormatter()->formatBatch($messages);

            $this->send($messages);
        }
    }

    protected function getDefaultFormatter()
    {
        return new LogServiceFormatter();
    }

    protected function processRecord(array $record)
    {
        if ($this->processors) {
            foreach ($this->processors as $processor) {
                $record = call_user_func($processor, $record);
            }
        }

        return $record;
    }

    public static function setSender(Closure $sender)
    {
        static::$sender = $sender;
    }

    protected function send(array $messages)
    {
        if (static::$sender) {
            static::$sender->__invoke($messages);
        } else {
            error_log(json_encode($messages));
        }
    }
}
