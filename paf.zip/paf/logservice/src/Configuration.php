<?php
namespace Paf\LogService;

class Configuration
{
    public static function get($key, $default = null)
    {
        return app('config')->get("services.log.{$key}", $default);
    }
}
