<?php

namespace Paf\LogService\Formatters;

use Closure;
use Monolog\Formatter\FormatterInterface;

class LogServiceFormatter implements FormatterInterface
{
    protected static $trackIDResolver;
    protected static $guidResolver;
    protected $from;
    protected $ip;
    protected $serverIp;
    protected $url;
    protected $method;

    public function __construct($from = 'unknow', $ip = '127.0.0.1', $serverIp = '127.0.0.1', $url = 'localhost', $method = 'GET')
    {
        $this->from     = $from;
        $this->ip       = $ip;
        $this->serverIp = $serverIp;
        $this->url      = $url;
        $this->method   = $method;
    }

    public function format(array $record)
    {
        return $this->formatBatch([$record]);
    }

    public function formatBatch(array $records)
    {
        $messages = [
            'id'        => static::getTrackID(),
            'from'      => $this->from,
            'env'       => reset($records)['channel'],
            'ip'        => $this->ip,
            'server_ip' => $this->serverIp,
            'url'       => $this->url,
            'method'    => $this->method,
            'guid'      => static::getGuid(),
            'logs'      => [],
        ];

        foreach ($records as $record) {
            $messages['logs'][] = [
                'level'   => $record['level_name'],
                'time'    => $record['datetime']->format('U.u'),
                'message' => $record['message'],
                'context' => $record['context'],
                'extra'   => $record['extra'],
            ];
        }

        return $messages;
    }

    public static function setTrackIDResolver(Closure $trackIDResolver)
    {
        static::$trackIDResolver = $trackIDResolver;
    }

    public static function getTrackID()
    {
        if (static::$trackIDResolver) {
            return (string) static::$trackIDResolver->__invoke();
        }

        return strtoupper(preg_replace(
            '~^(.{8})(.{4})(.{4})(.{4})(.{12})$~',
            '\1-\2-\3-\4-\5',
            md5(uniqid('', true))
        ));
    }

    public static function setGuidResolver(Closure $guidResolver)
    {
        static::$guidResolver = $guidResolver;
    }

    public static function getGuid()
    {
        if (static::$guidResolver) {
            return (string) static::$guidResolver->__invoke();
        }

        return '';
    }
}
