<?php

namespace Paf\LogService\Providers;

use Illuminate\Support\ServiceProvider;
use Paf\LogService\Bootstrap;

class LogServiceProvider extends ServiceProvider
{
    public function boot()
    {
        Bootstrap::boot();
    }

    public function register()
    {
    }
}
