<?php
namespace Paf\LogService;

use ReflectionClass;

class AMQPStreamConnection
{
    public static function get(array $argument)
    {
        $params = [
            'host'               => $argument['host'],
            'port'               => $argument['port'],
            'user'               => $argument['user'],
            'password'           => $argument['password'],
            'vhost'              => isset($argument['vhost']) ? $argument['vhost'] : '/',
            'insist'             => isset($argument['insist']) ? $argument['insist'] : false,
            'login_method'       => isset($argument['login_method']) ? $argument['login_method'] : 'AMQPLAIN',
            'login_response'     => isset($argument['login_response']) ? $argument['login_response'] : null,
            'locale'             => isset($argument['locale']) ? $argument['locale'] : 'en_US',
            'connection_timeout' => isset($argument['connection_timeout']) ? $argument['connection_timeout'] : 3,
            'read_write_timeout' => isset($argument['read_write_timeout']) ? $argument['read_write_timeout'] : 3,
            'context'            => isset($argument['context']) ? $argument['context'] : null,
            'keepalive'          => isset($argument['keepalive']) ? $argument['keepalive'] : false,
            'heartbeat'          => isset($argument['heartbeat']) ? $argument['heartbeat'] : 0,
        ];
        $ref = new ReflectionClass('\PhpAmqpLib\Connection\AMQPStreamConnection');
        return $ref->newInstanceArgs(array_values($params));
    }
}
