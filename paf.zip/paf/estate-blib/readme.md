## 通用token验证代码
通用验证token是否在用户中心有效的代码

### 配置说明
* 需要在项目配置中加入用户中心域名，如：DOMAIN_MEMBER_SERVICE=service-member.wuxiaofei.dev.anhouse.com.cn
* 需要在项目配置中加入用户中心分配的登陆类型参数，例如HFT为3，则配置如下：LOGIN_TOKEN_TYPE=3
* 配置和用户中心通信密钥，如：MEMBER_SERVICE_ACCESS_TOKEN=?access_token=9353739da906ddd9d9b93d80217f2043