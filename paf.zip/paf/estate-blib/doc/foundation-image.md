## 图片地址生成

### 介绍

生成图片地址

### 基本用法

```php
use Paf\EstateBLib\Foundation\Image;

// 生成图片的例子
Image::url('house', '943191e1e9b9bacf4bd169bc08c8cb8f25ec8e22', 'jpg', 260, 195);
// http://file.anhouse.com/view/house/943191e1e9b9bacf4bd169bc08c8cb8f25ec8e22/260x195.jpg

// 当key或ext不存在时生成默认图
Image::url('house', null, 'jpg', 260, 195);
// http://static.anhouse.cn/img/common/album/album_default_grey_16_9_640_360.png
```

> 当key或ext不存在时会尝试找出尺寸相近的默认图, 找不到时选择640x360
