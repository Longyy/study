## url生成

### 介绍

生成url

### 基本用法

```php
use Paf\EstateBLib\Foundation\Url;

Url::staticUrl();
// http://static.anhouse.cn
Url::www('path', ['arg1' => 'a']);
// http://www.test.dev.anhouse.com.cn/path?arg1=a
```
