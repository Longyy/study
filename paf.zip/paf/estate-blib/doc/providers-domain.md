## 域名配置服务

### 介绍

域名自动配置, 解决env中大量domain配置的问题

### 基本用法

在 `config/app.php` 的 `providers` 数组中新增 `Paf\EstateBLib\Providers\DomainServiceProvider`

> 你也可以使用 `Paf\EstateBLib\Providers\ConfigServiceProvider` 自动载入所有相关配置

```php
'providers' => [
	/*
	 * Laravel Framework Service Providers...
	 */
	...
	...
	...

	'Estate\Providers\CommonServiceProvider',

	// 此位置增加该行
	'Paf\EstateBLib\Providers\DomainServiceProvider',

	/*
	 * Application Service Providers...
	 */
	'App\Providers\AppServiceProvider',
	'App\Providers\BusServiceProvider',
	'App\Providers\ConfigServiceProvider',
	'App\Providers\EventServiceProvider',
	'App\Providers\RouteServiceProvider',
	...
	...
	...
],
```

在env中新增3条基本域名

```
DOMAIN_BASE=dev.anhouse.com.cn 		# 线上环境对应 pinganfang.com
DOMAIN_MISC=anhouse.com 			# 线上环境对应 anhouse.com
DOMAIN_INTERNAL=dev.anhouse.com.cn 	# 线上环境对应 d.pa.com
```

---

默认情况下, 所有域名都指向 `CLOUD_NAME`
以www为例
`http://www.CLOUD_NAME.dev.anhouse.com.cn`

你可以通过在env中新增以 `DOMAIN_` 开头的配置来覆盖默认的url **!!不要用于生产环境**

### 注意

**在 `config/domain.php` 中配置的域名会覆盖自动生成的域名配置**

**你可以选择整个删除 `config/domain.php` 来使得DomainServiceProvider完全地自动接管域名配置**
**但请务必注意domain.php中原有的key是否和自动生成的相同, 否则原有域名将无法使用, 重构时请务必注意**

### 目前可用域名配置

```php
[
    'DOMAIN_ROOT'             => 'dev.anhouse.com.cn',
    'DOMAIN_COOKIE_BASE'      => 'dev.anhouse.com.cn',
    'DOMAIN_WWW'              => 'www.CLOUD_NAME.dev.anhouse.com.cn',
    'DOMAIN_UPLOAD'           => 'upd.CLOUD_NAME.dev.anhouse.com.cn',
    'DOMAIN_MEMBER'           => 'member.CLOUD_NAME.dev.anhouse.com.cn',
    'DOMAIN_HFB'              => 'hfb.CLOUD_NAME.dev.anhouse.com.cn',
    'DOMAIN_HFD'              => 'hfd.CLOUD_NAME.dev.anhouse.com.cn',
    'DOMAIN_HFT'              => 'hft.CLOUD_NAME.dev.anhouse.com.cn',
    'DOMAIN_ABOUT'            => 'about.CLOUD_NAME.dev.anhouse.com.cn',
    'DOMAIN_HTML'             => 'html.CLOUD_NAME.dev.anhouse.com.cn',
    'DOMAIN_OVERSEAS'         => 'overseas.CLOUD_NAME.dev.anhouse.com.cn',
    'DOMAIN_XF'               => 'xf.CLOUD_NAME.dev.anhouse.com.cn',
    'DOMAIN_ESF'              => 'esf.CLOUD_NAME.dev.anhouse.com.cn',
    'DOMAIN_ZF'               => 'zf.CLOUD_NAME.dev.anhouse.com.cn',
    'DOMAIN_GOLD'             => 'gold.CLOUD_NAME.dev.anhouse.com.cn',
    'DOMAIN_ZC'               => 'zc.CLOUD_NAME.dev.anhouse.com.cn',
    'DOMAIN_XQ'               => 'xq.CLOUD_NAME.dev.anhouse.com.cn',
    'DOMAIN_VERIFY'           => 'verify.CLOUD_NAME.dev.anhouse.com.cn',
    'DOMAIN_NEWS'             => 'news.CLOUD_NAME.dev.anhouse.com.cn',
    'DOMAIN_EVENT'            => 'event.CLOUD_NAME.dev.anhouse.com.cn',
    'DOMAIN_MANAGE'           => 'manage.CLOUD_NAME.dev.anhouse.com.cn',
    'DOMAIN_PERMISSION'       => 'permission.CLOUD_NAME.dev.anhouse.com.cn',
    'DOMAIN_PAY'              => 'pay.CLOUD_NAME.dev.anhouse.com.cn',
    'DOMAIN_FIN'              => 'fin.CLOUD_NAME.dev.anhouse.com.cn',
    'DOMAIN_BIS'              => 'bis.CLOUD_NAME.dev.anhouse.com.cn',
    'DOMAIN_DOWNLOAD'         => 'download.CLOUD_NAME.dev.anhouse.com.cn',
    'DOMAIN_ANANZU_MOBILE'    => 'ananzu.m.CLOUD_NAME.dev.anhouse.com.cn',
    'DOMAIN_MOBILE'           => 'm.CLOUD_NAME.dev.anhouse.com.cn',
    'DOMAIN_OVERSEAS_MOBILE'  => 'overseas.m.CLOUD_NAME.dev.anhouse.com.cn',
    'DOMAIN_WWW_MOBILE'       => 'www.m.CLOUD_NAME.dev.anhouse.com.cn',
    'DOMAIN_SERVICE_SMS'      => 'service-sms.CLOUD_NAME.dev.anhouse.com.cn',
    'DOMAIN_ABOUT_SERVICE'    => 'about.CLOUD_NAME.s.dev.anhouse.com.cn',
    'DOMAIN_ANANZU_SERVICE'   => 'ananzu.CLOUD_NAME.s.dev.anhouse.com.cn',
    'DOMAIN_API_SERVICE'      => 'api.CLOUD_NAME.s.dev.anhouse.com.cn',
    'DOMAIN_COMMON_SERVICE'   => 'common.CLOUD_NAME.s.dev.anhouse.com.cn',
    'DOMAIN_DFS_SERVICE'      => 'dfs.CLOUD_NAME.s.dev.anhouse.com.cn',
    'DOMAIN_DOWNLOAD_SERVICE' => 'download.CLOUD_NAME.s.dev.anhouse.com.cn',
    'DOMAIN_ESF_SERVICE'      => 'esf.CLOUD_NAME.s.dev.anhouse.com.cn',
    'DOMAIN_HFT_SERVICE'      => 'hft.CLOUD_NAME.s.dev.anhouse.com.cn',
    'DOMAIN_HOUSING_SERVICE'  => 'housing.CLOUD_NAME.s.dev.anhouse.com.cn',
    'DOMAIN_LOUPAN_SERVICE'   => 'loupan.CLOUD_NAME.s.dev.anhouse.com.cn',
    'DOMAIN_MESSAGE_SERVICE'  => 'message.CLOUD_NAME.s.dev.anhouse.com.cn',
    'DOMAIN_NEWS_SERVICE'     => 'news.CLOUD_NAME.s.dev.anhouse.com.cn',
    'DOMAIN_OVERSEAS_SERVICE' => 'overseas.CLOUD_NAME.s.dev.anhouse.com.cn',
    'DOMAIN_PROXY_SERVICE'    => 'proxy.CLOUD_NAME.s.dev.anhouse.com.cn',
    'DOMAIN_SEARCH_SERVICE'   => 'search.CLOUD_NAME.s.dev.anhouse.com.cn',
    'DOMAIN_SHORTURL_SERVICE' => 'shorturl.CLOUD_NAME.s.dev.anhouse.com.cn',
    'DOMAIN_VERIFY_SERVICE'   => 'verify.CLOUD_NAME.s.dev.anhouse.com.cn',
    'DOMAIN_XF_SERVICE'       => 'xf.CLOUD_NAME.s.dev.anhouse.com.cn',
    'DOMAIN_XQ_SERVICE'       => 'xq.CLOUD_NAME.s.dev.anhouse.com.cn',
    'DOMAIN_ZF_SERVICE'       => 'zf.CLOUD_NAME.s.dev.anhouse.com.cn',
    'DOMAIN_WWW_SERVICE'      => 'www.CLOUD_NAME.s.dev.anhouse.com.cn',
    'DOMAIN_MEMBER_SERVICE'   => 'member.CLOUD_NAME.s.dev.anhouse.com.cn',
    'DOMAIN_FILE'             => 'file.anhouse.com',
    'DOMAIN_STATIC'           => 'static.anhouse.cn',
    'DOMAIN_SHORT'            => 'shorturl.CLOUD_NAME.dev.anhouse.com.cn',
]
