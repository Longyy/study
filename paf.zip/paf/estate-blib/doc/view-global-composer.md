## 模板公共头尾数据

### 介绍

输出模板页所需的头尾数据
如果区分城市, 需要注册 `Paf\EstateBLib\Providers\CityServiceProvider`

### 基本用法

```php
use View;

// 引入web头
\Paf\EstateBLib\Http\ViewComposers\Web\GlobalComposer::Iam('www'); // 设定当前仓库名, 用以生成统计id
// 或者引入h5页面头
// \Paf\EstateBLib\Http\ViewComposers\Mobile\GlobalComposer::Iam('www'); // 设定当前仓库名, 用以生成统计id
// 或者引入manage页面头
// \Paf\EstateBLib\Http\ViewComposers\Manage\GlobalComposer::Iam('www-manage'); // 设定当前仓库名, 用以生成统计id

// 绑定公共头数据到所有视图
View::composer('*', 'Paf\EstateBLib\Http\ViewComposers\Web\GlobalComposer');
// 或者绑定h5页面头
// View::composer('*', 'Paf\EstateBLib\Http\ViewComposers\Mobile\GlobalComposer');
// 或者绑定manage页面头
// View::composer('*', 'Paf\EstateBLib\Http\ViewComposers\Manage\GlobalComposer');

// 注入菜单到manage公共头
\Paf\EstateBLib\Http\ViewComposers\Manage\GlobalComposer::menuResolver(function () {
    return [
        [
            'bActive' => Route::is('house.*', 'housePic.*', 'country.*'),
            'sName'   => '海外项目管理',
            'sUrl'    => route('house.index'),
        ],
        [
            'bActive' => Route::is('recommend.*'),
            'sName'   => '前台推荐管理',
            'aMenus'  => [ // 二级菜单
                [
                    'bActive' => Route::is('recommend.nav.*'),
                    'sName'   => '分类导航',
                    'sUrl'    => route('recommend.nav.index'),
                ],
                [
                    'bActive' => Route::is('recommend.focusPic.*'),
                    'sName'   => '顶部焦点图',
                    'sUrl'    => route('recommend.focusPic.index'),
                ],
            ],
        ],
    ];
});
```
