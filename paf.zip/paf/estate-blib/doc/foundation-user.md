## 用户信息

### 介绍

获取用户信息

### 依赖

需要开启授权验证中间件 `Paf\EstateBLib\Http\Middleware\Manage\Authenticate`

### 基本用法

```php
use Paf\EstateBLib\Foundation\User;

User::id();
User::name();
```
