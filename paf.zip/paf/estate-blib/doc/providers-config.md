## 自动配置服务

### 介绍

自动载入配置, 作用相当于所有配置服务的合集
使用该服务等效于单独载入合集内的所有服务

包括

* Paf\EstateBLib\Providers\DomainServiceProvider
* Paf\EstateBLib\Providers\SwitchboardServiceProvider

### 基本用法

在 `config/app.php` 的 `providers` 数组中新增 `Paf\EstateBLib\Providers\ConfigServiceProvider`


```php
'providers' => [
	/*
	 * Laravel Framework Service Providers...
	 */
	...
	...
	...

	'Estate\Providers\CommonServiceProvider',


	// 此位置增加该行, 等效于增加以下被注释掉的服务
	'Paf\EstateBLib\Providers\ConfigServiceProvider',
    // 'Paf\EstateBLib\Providers\DomainServiceProvider',
    // 'Paf\EstateBLib\Providers\SwitchboardServiceProvider',


	/*
	 * Application Service Providers...
	 */
	'App\Providers\AppServiceProvider',
	'App\Providers\BusServiceProvider',
	'App\Providers\ConfigServiceProvider',
	'App\Providers\EventServiceProvider',
	'App\Providers\RouteServiceProvider',
	...
	...
	...
],
```
