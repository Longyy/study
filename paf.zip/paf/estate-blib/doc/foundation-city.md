## 城市信息

### 介绍

获取城市信息

### 依赖

需要开启授权验证中间件 `Paf\EstateBLib\Http\Middleware\City`

> Manage使用 `Paf\EstateBLib\Http\Middleware\Manage\City`

需要注册 `Paf\EstateBLib\Providers\CityServiceProvider`

### 基本用法

```php
use Paf\EstateBLib\Foundation\City;

// 获取当前城市ID
City::getCurrentCity('iID');

// 获取当前城市名
City::getCurrentCity('sName');

// 获取当前城市拼音
City::getCurrentCity('sPinyin');

// 判断城市是否已开放
\Paf\EstateBLib\Service\City::iAm('xf'); // 传入当前仓库名用以判断城市是否开放, 该行可以放到任意ServiceProvider中来实现随启动载入
City::isOpened($iCityID);
// City::isOpened($iCityID, 'xf'); // 如果没有调用iAm方法则第二个参数不可省略
```
