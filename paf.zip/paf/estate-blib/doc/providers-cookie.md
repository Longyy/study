## Cookie服务

### 介绍

设置cookie domain

### 基本用法

在 `config/app.php` 的 `providers` 数组中新增 `Paf\EstateBLib\Providers\CookieServiceProvider`

```php
'providers' => [
	/*
	 * Laravel Framework Service Providers...
	 */
	...
	...
	...

	'Estate\Providers\CommonServiceProvider',

	// 此位置增加该行
	'Paf\EstateBLib\Providers\CookieServiceProvider',

	/*
	 * Application Service Providers...
	 */
	'App\Providers\AppServiceProvider',
	'App\Providers\BusServiceProvider',
	'App\Providers\ConfigServiceProvider',
	'App\Providers\EventServiceProvider',
	'App\Providers\RouteServiceProvider',
	...
	...
	...
],
```
