## 电话配置服务

### 介绍

自动载入总线电话配置

### 基本用法

在 `config/app.php` 的 `providers` 数组中新增 `Paf\EstateBLib\Providers\SwitchboardServiceProvider`

> 你也可以使用 `Paf\EstateBLib\Providers\ConfigServiceProvider` 自动载入所有相关配置

```php
'providers' => [
	/*
	 * Laravel Framework Service Providers...
	 */
	...
	...
	...

	'Estate\Providers\CommonServiceProvider',

	// 此位置增加该行
	'Paf\EstateBLib\Providers\SwitchboardServiceProvider',

	/*
	 * Application Service Providers...
	 */
	'App\Providers\AppServiceProvider',
	'App\Providers\BusServiceProvider',
	'App\Providers\ConfigServiceProvider',
	'App\Providers\EventServiceProvider',
	'App\Providers\RouteServiceProvider',
	...
	...
	...
],
```
