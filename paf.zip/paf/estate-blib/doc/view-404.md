## 404页面数据

### 介绍

输出404模板页所需数据

### 基本用法

```php
use View;

// 绑定到404页面
View::composer('page.common.404', 'Paf\EstateBLib\Http\ViewComposers\PageNotFoundComposer');
```
