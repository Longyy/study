## SEO

### 介绍

附加seo信息到模板

### 基本用法

```php
use Paf\EstateBLib\Foundation\Seo;

Seo::setTitle('上海新房，上海二手房，上海租房，好房宝【平安好房】');
Seo::setDesc('平安好房网(Pinganfang.com) 是中国平安集团下的专业房地产平台');
Seo::setKeywords('上海好房');
```
