## 面包屑数据

### 介绍

输出面包屑数据

### 基本用法

```php
use View;

// 按需要绑定面包屑数据到对应视图
View::composer('*', 'Paf\EstateBLib\Http\ViewComposers\BreadCrumbsComposer');
```
