## 登陆认证中间件

### 介绍

验证manage登陆权限

### 基本用法

将 `Paf\EstateBLib\Http\Middleware\Manage\Authenticate` 添加为全局中间件
然后就可以通过 User 来取得当前用户信息

```php
use Paf\EstateBLib\Foundation\User;

// 取得用户id
User::id();
// 取得用户名
User::name();
```
