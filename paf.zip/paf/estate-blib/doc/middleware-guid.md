## GUID中间件

### 介绍

生成GUID

### 基本用法

按路由需要将 `Paf\EstateBLib\Http\Middleware\Guid` 添加为中间件
