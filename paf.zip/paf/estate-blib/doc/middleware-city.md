## 城市获取中间件

### 介绍

规则:

```flow
request=>start: Request
has_segment=>condition: url中带城市
has_cityID=>condition: cookie中带城市
show_404=>end: 404
goto_cityEnter=>end: 城市选择页
get_city=>condition: 城市是否存在
response=>end: Response

request->has_segment->has_cityID->
has_segment(yes)->get_city
has_segment(no)->has_cityID
has_cityID(yes)->get_city
has_cityID(no)->goto_cityEnter
get_city(yes)->response
get_city(no)->show_404
```

> 在经过中间件过滤之后, 可以通过 `\Paf\EstateBLib\Foundation\City::getCurrentCity()` 获取当前城市信息

### 依赖

需要注册 `Paf\EstateBLib\Providers\CityServiceProvider`

### 基本用法

按路由需要将 `Paf\EstateBLib\Http\Middleware\City` 添加为中间件

> Manage使用 `Paf\EstateBLib\Http\Middleware\Manage\City`

### TODO

当url和cookie中都无法取得城市信息时, 根据ip定位城市, 如果ip定位城市失败, 302到城市列表选择页
