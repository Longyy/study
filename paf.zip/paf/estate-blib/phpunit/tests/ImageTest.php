<?php

use Paf\EstateBLib\Foundation\Image;

class ImageTest extends TestCase
{
    public function setUp()
    {
        parent::setUp();
        app()->register('Paf\EstateBLib\Providers\DomainServiceProvider');
    }

    public function testUrl()
    {
        $this->assertEquals(
            Image::url('house', '943191e1e9b9bacf4bd169bc08c8cb8f25ec8e22', 'jpg', 260, 195, 'option'),
            'http://file.anhouse.com/view/house/943191e1e9b9bacf4bd169bc08c8cb8f25ec8e22/260x195_option.jpg'
        );
        $this->assertEquals(
            Image::url('house', '943191e1e9b9bacf4bd169bc08c8cb8f25ec8e22', 'jpg', 260, 195),
            'http://file.anhouse.com/view/house/943191e1e9b9bacf4bd169bc08c8cb8f25ec8e22/260x195.jpg'
        );
        $this->assertEquals(
            Image::url('house', '943191e1e9b9bacf4bd169bc08c8cb8f25ec8e22', 'jpg'),
            'http://file.anhouse.com/view/house/943191e1e9b9bacf4bd169bc08c8cb8f25ec8e22.jpg'
        );
    }

    public function testDefaultUrl()
    {
        $this->assertEquals(
            Image::url('house', null, null),
            'http://static.anhouse.cn/img/common/album/album_default_grey_16_9_640_360.png'
        );
        $this->assertEquals(
            Image::url('house', null, 'jpg', 220, 160),
            'http://static.anhouse.cn/img/common/album/album_default_grey_4_3_220_165.png'
        );
    }
}
