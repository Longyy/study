<?php

use Paf\EstateBLib\Foundation\Url;

class UrlTest extends TestCase
{
    public function setUp()
    {
        parent::setUp();
        app()->register('Paf\EstateBLib\Providers\DomainServiceProvider');
    }

    public function testUrl()
    {
        $this->assertEquals(Url::www('path', ['arg1' => 'a']), 'http://www.test.dev.anhouse.com.cn/path?arg1=a');
        $this->assertEquals(Url::staticUrl(), 'http://static.anhouse.cn');

        foreach (config('domain') as $sName => $sDomain) {
            $this->assertEquals(Url::{$sName . 'Url'}('path', ['arg1' => 'a']), hf_url($sName, 'path', ['arg1' => 'a']));
        }

        $this->assertEquals(Url::asdfasdf(), 'http://asdfasdf.test.dev.anhouse.com.cn');
    }
}
