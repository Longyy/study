<?php

use Paf\EstateBLib\Foundation\Seo;

class SeoTest extends TestCase
{
    public function testTitle()
    {
        $sTitle = '上海新房，上海二手房，上海租房，好房宝【平安好房】';

        $this->assertEquals($sTitle, Seo::getTitle($sTitle));

        Seo::setTitle($sTitle);
        $this->assertEquals($sTitle, Seo::getTitle());
    }

    public function testDesc()
    {
        $sDesc = '平安好房网(Pinganfang.com) 是中国平安集团下的专业房地产平台';

        $this->assertEquals($sDesc, Seo::getDesc($sDesc));

        Seo::setDesc($sDesc);
        $this->assertEquals($sDesc, Seo::getDesc());
    }

    public function testKeywords()
    {
        $sKeywords = '上海好房';

        $this->assertEquals($sKeywords, Seo::getKeywords($sKeywords));

        Seo::setKeywords($sKeywords);
        $this->assertEquals($sKeywords, Seo::getKeywords());
    }
}
