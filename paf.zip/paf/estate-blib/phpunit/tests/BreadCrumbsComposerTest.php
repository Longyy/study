<?php

use Paf\EstateBLib\Http\ViewComposers\BreadCrumbsComposer;

class BreadCrumbsComposerTest extends TestCase
{
    public function testBreadCrumbsComposer()
    {
        $aBreadCrumbs = [
            ['sTitle' => 'A', 'sUrl' => ''],
            ['sTitle' => 'title', 'sUrl' => 'url'],
        ];

        BreadCrumbsComposer::push('A');
        BreadCrumbsComposer::push($aBreadCrumbs[1]);

        $this->assertEquals($aBreadCrumbs, BreadCrumbsComposer::get());

        $this->assertEquals(array_pop($aBreadCrumbs), BreadCrumbsComposer::pop());
        $this->assertEquals($aBreadCrumbs, BreadCrumbsComposer::get());
    }
}
