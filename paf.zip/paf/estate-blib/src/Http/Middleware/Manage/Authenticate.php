<?php
namespace Paf\EstateBLib\Http\Middleware\Manage;

use Cache;
use Closure;
use Cookie;
use Paf\EstateBLib\Foundation\User;

class Authenticate
{
    // manage用户gid
    const MANAGE_GID_KEY = 'permission_manage_gid';
    // 登陆有效时间有效时间
    const MAX_ALIVE_TIME = 30; // 30分

    /**
     * Handle an incoming request.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \Closure  $next
     * @return mixed
     */
    public function handle($oRequest, Closure $oNext)
    {
        // 获取用户guid
        if (!($sManageCode = $oRequest->cookie('per_' . md5(self::MANAGE_GID_KEY)))) {
            // 没有的话生成一个
            $sManageCode = md5(uniqid(str_random(), true));
            \Cookie::queue('per_' . md5(self::MANAGE_GID_KEY), $sManageCode, 864000);
        }
        $sKey = "AUTH:{$sManageCode}";

        // 新用户登陆
        if ($sGID = $oRequest->input('gid')) {
            $sPermissionData = self::decrypt($oRequest->input('gid'), env('MANAGE_AUTH_KEY', 'www.ipo.com'));
            if (preg_match('~(?P<id>\d+)----(?P<name>[^-]+)~', $sPermissionData, $aMatches)) {
                User::load(['id' => $aMatches['id'], 'name' => $aMatches['name']]);
                Cache::put($sKey, User::toArray(), self::MAX_ALIVE_TIME);
                $sQuery = http_build_query($oRequest->except('gid'));
                return redirect($sQuery ? $oRequest->url() . '?' . $sQuery : $oRequest->url());
            }
        }

        // 已登陆用户重新访问续期
        if ($aUser = Cache::get($sKey)) {
            User::load($aUser);
            Cache::put($sKey, User::toArray(), self::MAX_ALIVE_TIME);
        }

        // 未登陆, 引导登陆
        if (!User::id()) {
            if ($oRequest->ajax()) {
                return response('Unauthorized.', 401);
            } else {
                return redirect(hf_url('permission', 'site/login.html?referer=' . base64_encode($oRequest->url() . '?' . http_build_query(array_merge(['from_mo_type' => 'publish'], $oRequest->query())))));
            }
        }

        return $oNext($oRequest);
    }

    protected static function encrypt($p_sValue, $p_sKey)
    {
        return self::_code($p_sValue, 'ENCODE', $p_sKey);
    }

    /**
     * 解密函数
     * @param string $p_sValue
     * @param string $p_sKey
     * @return string
     */
    protected static function decrypt($p_sValue, $p_sKey)
    {
        return self::_code($p_sValue, 'DECODE', $p_sKey);
    }

    /**
     * 编码函数
     * @param string $p_sValue
     * @param string $p_sOperation
     * @param string $p_sKey
     * @return string
     */
    protected static function _code($p_sValue, $p_sOperation, $p_sKey)
    {
        $p_sKey          = md5($p_sKey);
        $p_sKey_length   = strlen($p_sKey);
        $p_sValue        = $p_sOperation == 'DECODE' ? base64_decode($p_sValue) : substr(md5($p_sValue . $p_sKey), 0, 8) . $p_sValue;
        $p_sValue_length = strlen($p_sValue);

        $rndkey = $box = array();
        $result = '';
        for ($i = 0; $i <= 255; $i++) {
            $rndkey[$i] = ord($p_sKey[$i % $p_sKey_length]);
            $box[$i]    = $i;
        }

        for ($j = $i = 0; $i < 256; $i++) {
            $j       = ($j + $box[$i] + $rndkey[$i]) % 256;
            $tmp     = $box[$i];
            $box[$i] = $box[$j];
            $box[$j] = $tmp;
        }

        for ($a = $j = $i = 0; $i < $p_sValue_length; $i++) {
            $a       = ($a + 1) % 256;
            $j       = ($j + $box[$a]) % 256;
            $tmp     = $box[$a];
            $box[$a] = $box[$j];
            $box[$j] = $tmp;
            $result .= chr(ord($p_sValue[$i]) ^ ($box[($box[$a] + $box[$j]) % 256]));
        }

        if ($p_sOperation == 'DECODE') {
            if (substr($result, 0, 8) == substr(md5(substr($result, 8) . $p_sKey), 0, 8)) {
                return substr($result, 8);
            } else {
                return '';
            }
        } else {
            return str_replace('=', '', base64_encode($result));
        }
    }

}
