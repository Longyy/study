<?php
namespace Paf\EstateBLib\Http\Middleware\Manage;

use Closure;

/**
 * 城市中间件
 */
class City
{
    /**
     * 城市ID处理器
     * @var mixed
     */
    protected static $mCityIDResolver;

    /**
     * 设置城市ID
     *
     * @author Sinute
     * @date   2016-05-13
     * @param  mixed     $mCityIDResolver 城市ID处理器
     */
    public static function setCityIDResolver($mCityIDResolver)
    {
        static::$mCityIDResolver = $mCityIDResolver;
    }

    /**
     * 获取城市ID处理器
     *
     * @author Sinute
     * @date   2016-05-13
     * @return mixed     城市ID处理器
     */
    public static function getCityIDResolver()
    {
        return static::$mCityIDResolver ?: function () {
            return \Request::input('city_id');
        };
    }

    public function handle($oRequest, Closure $oNext)
    {
        if (!app()->bound('service.city')) {
            throw new \OutOfBoundsException('Paf\EstateBLib\Providers\CityServiceProvider not load');
        }
        // 获取城市
        $iCityID = intval(call_user_func(static::getCityIDResolver()));
        if ($iCityID) {
            // 如果城市不存在, 返回404 (暂定)
            if (!($aCity = app('service.city')->get($iCityID)) || !app('service.city')->isOpened($aCity['iID'])) {
                abort(404);
            }
            $iCityID = $aCity['iID'];

            // 保存当前城市信息
            app('service.city')->setCurrentCity($aCity);

            if (!$oRequest->ajax() && $oRequest->cookie('hfcityid') != $iCityID) {
                app('cookie')->queue('cityid', $iCityID, 365 * 24 * 60, null, null, false, false);
                app('cookie')->queue('hfcityid', $iCityID, 365 * 24 * 60, null, null, false, false);
            }
        }
        return $oNext($oRequest);
    }
}
