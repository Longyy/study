<?php
namespace Paf\EstateBLib\Http\Middleware;

use Closure;
use Paf\EstateBLib\Foundation\Url;

/**
 * 城市中间件
 */
class City
{
    public function handle($oRequest, Closure $oNext)
    {
        if (!app()->bound('service.city')) {
            throw new \OutOfBoundsException('Paf\EstateBLib\Providers\CityServiceProvider not load');
        }
        // 获取城市
        $sCityPy = $oRequest->segment(1); // 城市参数为url中第一个segment
        $sCityPy = mb_convert_encoding($sCityPy, 'utf8', mb_detect_encoding($sCityPy, ['ASCII', 'UTF-8', 'GBK'], false));
        $iCityID = intval($oRequest->cookie('hfcityid')); // 也可能在cookie中有城市ID
        // 如果url和cookie中都无法找到城市信息, 尝试从ip推断
        if (!$sCityPy && !$iCityID) {
            // 根据ip定位城市
            return redirect(Url::www('checkcity', ['url' => $oRequest->fullUrl()]));
        } else {
            // 检查外部传入的城市是否有效
            // 如果城市不存在, 返回404
            if (!$aCity = app('service.city')->get(['sPinyin' => $sCityPy, 'iID' => $iCityID])) {
                abort(404);
            }
        }
        // 跳转至对应城市页
        if (!$sCityPy) {
            return redirect(
                ($aCity['sAbbreviate'] ?: $aCity['sPinyin']) . ($oRequest->getQueryString() ? '?' . $oRequest->getQueryString() : '')
            );
        }
        // 保存当前城市信息
        // 发现有js写死sh进行请求的情况, 如果是ajax请求不切换城市
        app('service.city')->setCurrentCity($aCity);
        if (!$oRequest->ajax() && $iCityID != $aCity['iID']) {
            // 设置cookie
            app('cookie')->queue('cityid', $aCity['iID'], 365 * 24 * 60, null, null, false, false);
            app('cookie')->queue('hfcityid', $aCity['iID'], 365 * 24 * 60, null, null, false, false);
        }

        return $oNext($oRequest);
    }
}
