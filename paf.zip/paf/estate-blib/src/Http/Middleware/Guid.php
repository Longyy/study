<?php
namespace Paf\EstateBLib\Http\Middleware;

use Closure;

/**
 * 设置guid
 */
class Guid
{
    public function handle($oRequest, Closure $oNext)
    {
        $sGUID = $oRequest->cookie('guid', false);
        if (!$sGUID || !is_string($sGUID)) {
            $iLength = 16;
            $sRandom = substr(str_shuffle(str_repeat('0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ', $iLength)), 0, $iLength);
            app('cookie')->queue('guid', md5(uniqid($sRandom, true)), 365 * 24 * 60, null, null, false, false);
        } elseif (time() < strtotime('2017-08-01')) {
            // 1年期, 用于刷掉已设置httponly的用户cookie
            app('cookie')->queue('guid', $sGUID, 365 * 24 * 60, null, null, false, false);
        }
        return $oNext($oRequest);
    }
}
