<?php
namespace Paf\EstateBLib\Http\ViewComposers;

use Illuminate\Contracts\View\View;
use Paf\EstateBLib\Foundation\Url;

/**
 * 404页面数据
 */
class PageNotFoundComposer
{
    public function compose(View $oView)
    {
        $oView->with('aUrl', [
            'sWWWDomain'    => Url::www(), // 主页
            'sXFDomain'     => Url::xf(), // 新房
            'sRXLouPan'     => Url::xf('sh/list/ct1') . '/', // 热销楼盘
            'sHFDLouPan'    => Url::xf('sh/list/sd1') . '/', // 好房贷楼盘
            'sGoldDomain'   => Url::gold('home'), // 好房金融
            'sHFBLouPan'    => Url::xf('sh/list/sb1') . '/', // 好房宝楼盘
            'sHFTDomain'    => Url::hft(), // 好房拓
            'sESFDomain'    => Url::esf(), // 二手房
            'sXQDomain'     => Url::xq(), // 小区
            'sDuJiaFang'    => Url::esf('sh/list/id1') . '/', // 独家房源
            'sEFQDomain'    => Url::gold('efq/home/index.html'), // e房钱
            'sAPPDomain'    => Url::about('app') . '/', // 手机找好房
            'sZFDomain'     => Url::zf(), // 租房
            'sZJDDomain'    => Url::gold('zjd/home/index.html'), // 租金贷
            'sMemberDomain' => Url::member(), // 用户中心
            'sRegUrl'       => Url::member('v2/web/user/register'), // 注册
            'sLoginUrl'     => Url::member('v2/web/user/login'), // 登录
            'sHWDomain'     => Url::overseas(), // 海外
            'sHWListUrl'    => Url::overseas('list') . '/', // 海外项目
            'sHWArticleUrl' => Url::overseas('article') . '/', // 海外资讯
            'sFankuiUrl'    => Url::about('survey/xf/v3') . '/', // 意见反馈
            'sHFBDomain'    => Url::gold('hfbweb/info/active.html'), // 好房宝
            'sHFDDomain'    => Url::gold('hfd/apply/home.html'), // 好房贷
            'sNewsDomain'   => Url::news(), // 好房资讯
        ]);
    }
}
