<?php
namespace Paf\EstateBLib\Http\ViewComposers;

use Illuminate\Contracts\View\View;

/**
 * 面包屑数据
 */
class BreadCrumbsComposer
{
    /**
     * 面包屑数组
     * @var array
     */
    protected static $aBreadCrumbs = [];

    public function compose(View $oView)
    {
        $oView->with('aBreadCrumbs', static::get());
    }

    /**
     * 新增一条路径
     *
     * @author Sinute
     * @date   2015-12-12
     * @param  mixed     $mBreadCrumb    面包屑
     */
    public static function push($mBreadCrumb)
    {
        if (is_string($mBreadCrumb)) {
            $sTitle = $mBreadCrumb;
            $sUrl   = '';
        } else {
            $sTitle = array_get($mBreadCrumb, 'sTitle');
            $sUrl   = array_get($mBreadCrumb, 'sUrl');
        }
        static::$aBreadCrumbs[] = compact('sTitle', 'sUrl');
    }

    /**
     * 弹出最后一条路径
     *
     * @author Sinute
     * @date   2015-12-12
     * @return array     最后一条路径
     */
    public static function pop()
    {
        return array_pop(static::$aBreadCrumbs);
    }

    /**
     * 获取所有面包屑
     *
     * @author Sinute
     * @date   2015-12-12
     * @return array     面包屑数组
     */
    public static function get()
    {
        return static::$aBreadCrumbs;
    }
}
