<?php
namespace Paf\EstateBLib\Http\ViewComposers\Manage;

use Closure;
use Paf\EstateBLib\Foundation\Url;
use Paf\EstateBLib\Foundation\User;
use Paf\EstateBLib\Http\ViewComposers\GlobalComposer as BaseGlobalComposer;

/**
 * manage公共头尾数据
 * 保留字段:
 *     sTitle   用于设置标题
 */
class GlobalComposer extends BaseGlobalComposer
{
    /**
     * 导航
     * @var \Closure
     */
    protected static $oNavResolver;

    /**
     * 菜单
     * @var \Closure
     */
    protected static $oMenuResolver;

    /**
     * 通用数据
     *
     * @author Sinute
     * @date   2015-12-02
     * @return array
     */
    protected function getGlobalData()
    {
        $this->oView->with('sTitle', '平安好房管理系统-' . array_get($this->oView, 'sTitle', "(●'◡'●)ﾉ♥"));
        return [
            'sUserName'       => User::name(),
            'aCurrentCity'    => [
                'iCityID' => array_get($this->aCurrentCity, 'iID', ''),
                'sPinyin' => array_get($this->aCurrentCity, 'sPinyin', ''),
                'sName'   => array_get($this->aCurrentCity, 'sName', ''),
            ],
            'aCityList'       => $this->getOpenedCities(),
            'sUserAccountUrl' => Url::manageUrl('account/account/edit.html'),
            'sLogoutUrl'      => Url::permissionUrl('site/logout.html'),
            'aNavs'           => static::resolveNavs(),
            'aMenus'          => static::resolveMenus(),
        ];
    }

    /**
     * 获取顶部导航
     *
     * @author Sinute
     * @date   2015-12-23
     * @return array
     */
    protected static function resolveNavs()
    {
        if (isset(static::$oNavResolver)) {
            return call_user_func(static::$oNavResolver);
        }

        return [];
    }

    /**
     * 获取侧边菜单
     *
     * @author Sinute
     * @date   2015-12-23
     * @return array
     */
    protected static function resolveMenus()
    {
        if (isset(static::$oMenuResolver)) {
            return call_user_func(static::$oMenuResolver);
        }

        return [];
    }

    /**
     * 设置顶部导航处理器
     *
     * @author Sinute
     * @date   2015-12-23
     * @param  \Closure    $oNavResolver 顶部导航处理器
     */
    public static function navResolver(Closure $oNavResolver)
    {
        static::$oNavResolver = $oNavResolver;
    }

    /**
     * 设置侧边菜单处理器
     *
     * @author Sinute
     * @date   2015-12-23
     * @param  \Closure    $oMenuResolver 侧边菜单处理器
     */
    public static function menuResolver(Closure $oMenuResolver)
    {
        static::$oMenuResolver = $oMenuResolver;
    }

    /**
     * 获取头数据
     *
     * @author Sinute
     * @date   2015-12-23
     * @return array
     */
    protected function getHeaderData()
    {
        return [];
    }

    /**
     * 获取尾数据
     *
     * @author Sinute
     * @date   2015-12-23
     * @return array
     */
    protected function getFooterData()
    {
        return [];
    }
}
