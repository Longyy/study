<?php
namespace Paf\EstateBLib\Http\ViewComposers;

use Illuminate\Contracts\View\View;

class StructDumpperComposer
{
    public function compose(View $oView)
    {
        $aData = $oView->getData();
        unset($aData['globalData'], $aData['headerData'], $aData['footerData']);
        dd($oView, json_encode($aData, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES));
    }
}
