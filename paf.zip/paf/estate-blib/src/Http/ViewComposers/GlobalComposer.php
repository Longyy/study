<?php
namespace Paf\EstateBLib\Http\ViewComposers;

use Illuminate\Contracts\View\View;
use Paf\EstateBLib\Foundation\Seo;
use Paf\EstateBLib\Foundation\Url;

/**
 * 公共头尾数据
 *
 * 保留字段:
 *     sPGID 用于设置piwik统计id
 */
abstract class GlobalComposer
{
    /**
     * 当前频道
     * @var string
     * www, xf, esf, zf, overseas, xq
     */
    protected static $sChannel;

    /**
     * 是否已初始化
     * @var boolean
     */
    protected static $bInit;

    /**
     * 当前城市
     * @var array
     */
    protected $aCurrentCity;

    /**
     * 已开放城市
     * @var array
     */
    protected $aOpenedCities;

    /**
     * 城市区域
     * @var array
     */
    protected $aRegionCities;

    /**
     * 总机
     * @var string
     */
    protected $sPhone;

    /**
     * 视图对象
     * @var object
     */
    protected $oView;

    public function compose(View $oView)
    {
        if (!static::$bInit) {
            $this->oView = $oView;

            $this->initCity();
            $this->initPhone();

            $oView->with('globalData', $this->getGlobalData());
            $oView->with('headerData', $this->getHeaderData());
            $oView->with('footerData', $this->getFooterData());

            static::$bInit = true;
        }
    }

    /**
     * 通用数据
     *
     * @author Sinute
     * @date   2015-12-09
     * @return array
     */
    protected function getGlobalData()
    {
        $sCityPy = array_get($this->aCurrentCity, 'sPinyin', 'sh');

        return [
            'sPGID'               => md5(sprintf('%s:%s', env('APP_NAME'), $this->oView->name())), // piwikID
            'iPrsTime'            => intval(microtime(true) * 1000), // piwik时间
            'bAllowSwitchVersion' => false, //是否允许切换Beta
            'sDFSUpd'             => Url::upload('/upload'),
            'sStaticDomain'       => Url::staticUrl('', [], app('request')->secure()),
            'sDFSViewDomain'      => Url::file(),
            'sMemberDomain'       => Url::member(),
            'sDFSRootDomain'      => Url::root('', [], ''),
            'sUserCollect'        => Url::member('/user/collect/home.html'),
            'aCurrentVersion'     => [
                'type' => 'ga',
            ],
            'sStaticRoot'         => Url::staticUrl(env('CURRENT_VERSION')),
            'aUserInfo'           => [],

            'aUrl'                => [
                'sHome'            => Url::www(), // 首页
                'sXF'              => Url::xf($sCityPy) . '/', // 新房
                'sESF'             => Url::esf($sCityPy), // 二手房
                'sRent'            => Url::ananzu('', ['from' => Url::root('', [], '')]), // 安安租
                'sGold'            => Url::gold('home'), // 好房金融
                'sHFB'             => Url::gold('hfbweb/info/active.html'), // 好房宝
                'sHFD'             => Url::gold('hfd/apply/home.html'), // 好房贷
                'sAJD'             => Url::gold('ajd/home'), // 按揭贷
                'sEFQ'             => Url::gold('efq/home/index.html'), // E房钱
                'sHFT'             => Url::hft(), // 好房拓
                'sCrowd'           => Url::zc('home'), // 众筹首页
                'sOverseas'        => Url::overseas(), // 海外首页
                'sOverseasArticle' => Url::overseas('article'), // 海外资讯列表
                'sOverseasList'    => Url::overseas('list'), // 海外楼盘列表
                'sTouch'           => Url::mobile($sCityPy) . '/', // 手机版首页地址
                'sApp'             => Url::about('app/index.html'), // APP下载地址
                'sLoginURL'        => Url::member('v2/web/user/login', [], true), // 登录
                'sRegisterURL'     => Url::member('v2/web/user/register', [], true), // 注册
                "sAboutURL"        => Url::about('public/aboutus') . '/', // 关于我们
                "sRecruitURL"      => Url::about('public/recruit') . '/', // 人才招聘,
                "sContactURL"      => Url::about('public/contact') . '/', // 联系我们
                "sProtocolURL"     => Url::about('public/agreement') . '/', // 用户协议
                "sSiteMapURL"      => Url::about("sitemap/{$sCityPy}.html"), // 网站地图
                "sYQLinksURL"      => Url::html('link.html'), // 友情链接
                "sFDCalcURL"       => Url::www('tools/fangdai.html'), // 房贷计算器
                "sSurveyURL"       => Url::about('survey/xf/v3') . '/', // 问卷
                'sMyMessage'       => Url::member('/v2/web/user/letter/list', [], true), // 站内信
                'sNews'            => Url::news(), // 资讯
                'sKFT'             => Url::xf("{$sCityPy}/kft") . '/', // 看房团
                'sCityEnterUrl'    => Url::www('home/cityenter.html'), // 所有城市
                'sKycUrl'          => Url::member('v2/web/kyc/index', [], true), // KYC个人DNA
            ],
        ];
    }

    /**
     * 获取头数据
     *
     * @author Sinute
     * @date   2015-12-09
     * @return array
     */
    abstract protected function getHeaderData();

    /**
     * 获取尾数据
     *
     * @author Sinute
     * @date   2015-12-09
     * @return array
     */
    abstract protected function getFooterData();

    /**
     * 初始化城市数据
     *
     * @author Sinute
     * @date   2015-12-02
     */
    protected function initCity()
    {
        if (!static::hasCity()) {
            $this->aCurrentCity  = [];
            $this->aOpenedCities = [];
            $this->aRegionCities = [];
        } else {
            $this->aCurrentCity = static::getCity()->getCurrentCity();
            if ($sAbbreviate = array_get($this->aCurrentCity, 'sAbbreviate')) {
                $this->aCurrentCity['sPinyin'] = $sAbbreviate;
            }
            $aOpenedCities = static::getCity()->getOpenedCities(static::whoAmI());
            array_walk($aOpenedCities, function (&$aOpenedCity, $iCityID) {
                $sPinyin     = array_get($aOpenedCity, 'sPinyin');
                $aOpenedCity = [
                    'iCityID'   => $iCityID,
                    'sPinyin'   => $sPinyin,
                    'sName'     => array_get($aOpenedCity, 'sName'),
                    'sURL'      => in_array(static::whoAmI(), ['xf', 'esf']) ? Url::{static::whoAmI()}($sPinyin) . '/' : Url::www($sPinyin),
                    'sTouchUrl' => in_array(static::whoAmI(), ['xf', 'esf']) ? Url::{static::whoAmI() . 'Mobile'}($sPinyin) . '/' : Url::wwwMobile($sPinyin),
                ];
            });
            // 当前频道已开放城市
            $this->aOpenedCities = $aOpenedCities;
            $aRegionCities       = static::getCity()->getRegionCity();
            $this->aRegionCities = [];
            // 已开放的区域城市
            foreach ($aRegionCities as $sRegion => $aCities) {
                $aRegionCity = array_intersect_key($aCities, $this->aOpenedCities);
                if ($aRegionCity) {
                    $this->aRegionCities[$sRegion] = $aRegionCity;
                }
            }
        }
    }

    /**
     * 是否区分城市
     *
     * @author Sinute
     * @date   2015-12-23
     * @return boolean
     */
    protected static function hasCity()
    {
        return app()->bound('service.city');
    }

    /**
     * 获取城市
     *
     * @author Sinute
     * @date   2015-12-23
     * @return object
     */
    protected static function getCity()
    {
        return app('service.city');
    }

    /**
     * 初始化电话数据
     *
     * @author Sinute
     * @date   2015-12-10
     */
    protected function initPhone()
    {
        $this->sPhone = config('400.sSwitchboard', '400-868-1111');
    }

    /**
     * 设定当前频道
     *
     * @author Sinute
     * @date   2015-12-02
     * @param  string     $sWho 当前频道
     */
    public static function iAm($sWho)
    {
        static::$sChannel = $sWho;
        if (static::hasCity()) {
            static::getCity()->iAm($sWho);
        }
    }

    /**
     * 获取当前频道
     *
     * @author Sinute
     * @date   2015-12-08
     * @return string
     */
    public static function whoAmI()
    {
        if (static::$sChannel) {
            return static::$sChannel;
        } else {
            return strtolower(str_replace('-web', '', env('APP_NAME')));
        }
    }

    /**
     * 获取seo数据
     *
     * @author Sinute
     * @date   2015-12-02
     * @return array
     */
    protected function getSeoData()
    {
        $sCityName = array_get($this->aCurrentCity, 'sName', '');
        return [
            'sTitle'    => Seo::getTitle('平安好房'),
            'sKeyWords' => Seo::getKeywords("{$sCityName}好房"),
            'sDesc'     => Seo::getDesc("平安好房网(Pinganfang.com) 是中国平安集团下的专业房地产平台，专业提供{$sCityName}新房、{$sCityName}二手房、{$sCityName}租房、海外房产等服务，并有在线购房、在线租房、在线竞价、在线支付等多项全新的服务功能，满足您的不同需求"),
        ];
    }

    /**
     * 获取已开放城市
     *
     * @author Sinute
     * @date   2015-12-02
     * @return array
     */
    protected function getOpenedCities()
    {
        return $this->aOpenedCities;
    }

    /**
     * 获取区域城市
     *
     * @author Sinute
     * @date   2015-12-02
     * @return array
     */
    protected function getRegionCity()
    {
        $aResult = [];
        foreach ($this->aRegionCities as $sRegionName => $aCities) {
            $aResult[] = [
                'sName' => $sRegionName,
                'aIds'  => array_keys($aCities),
            ];
        }
        return $aResult;
    }
}
