<?php
namespace Paf\EstateBLib\Http\ViewComposers\Mobile;

use Paf\EstateBLib\Foundation\Url;
use Paf\EstateBLib\Http\ViewComposers\GlobalComposer as BaseGlobalComposer;

/**
 * 公共头尾数据
 * 保留字段:
 *     sTitle   用于设置顶栏标题
 *     sBackUrl 用于设置顶栏返回地址
 */
class GlobalComposer extends BaseGlobalComposer
{
    /**
     * 获取头数据
     *
     * @author Sinute
     * @date   2015-12-02
     * @return array
     */
    protected function getHeaderData()
    {
        $sTitle   = $this->oView->sTitle;
        $sBackUrl = $this->getBackUrl($this->oView->sBackUrl);
        unset($this->oView['sTitle'], $this->oView['sBackUrl']);

        return array_merge(
            $this->getSeoData(),
            [
                'sWebCharset'      => 'utf-8',
                'aCityList'        => $this->getOpenedCities(),
                'sCurrentCityName' => array_get($this->aCurrentCity, 'sName', ''),
                'iCurrentCityID'   => array_get($this->aCurrentCity, 'iID', 0),
                'aCityGroup'       => $this->getRegionCity(),
                'sLoginURL'        => Url::member('v2/web/user/login', [], true),
                'sRegisterURL'     => Url::member('v2/web/user/register', [], true),
                'sHomeUrl'         => Url::mobile(),
                'sGuideUrl'        => Url::mobile('guide') . '/',
                'sCityUrl'         => Url::mobile('citylist') . '/',
                'sBackUrl'         => $sBackUrl,
                'sTopText'         => $sTitle,
            ]
        );
    }

    /**
     * 获取尾数据
     *
     * @author Sinute
     * @date   2015-12-02
     * @return array
     */
    protected function getFooterData()
    {
        return [
            'sPhone'       => $this->sPhone, //联系电话
            'sWWWUrl'      => Url::www('', ['touchweb' => 1]),
            'sWWWTouchUrl' => Url::mobile(),
        ];
    }

    /**
     * 获取上一级链接
     *
     * @author Sinute
     * @date   2015-12-09
     * @param  string     $sBackUrl 上一级链接
     * @return string
     */
    protected function getBackUrl($sBackUrl)
    {
        if ($sBackUrl) {
            return $sBackUrl;
        }
        $sReferHost = parse_url(\Request::header('referer'), PHP_URL_HOST);
        $sHost      = parse_url(Url::mobile(), PHP_URL_HOST);
        if ($sHost === substr($sReferHost, -strlen($sHost))) {
            return \Request::header('referer');
        }
        return Url::mobile();
    }
}
