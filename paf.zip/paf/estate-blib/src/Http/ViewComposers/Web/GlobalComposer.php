<?php
namespace Paf\EstateBLib\Http\ViewComposers\Web;

use Paf\EstateBLib\Foundation\Url;
use Paf\EstateBLib\Http\ViewComposers\GlobalComposer as BaseGlobalComposer;
use Paf\EstateBLib\Services\CommonService;

/**
 * 公共头尾数据
 */
class GlobalComposer extends BaseGlobalComposer
{
    /**
     * 获取头数据
     *
     * @author Sinute
     * @date   2015-12-02
     * @return array
     */
    protected function getHeaderData()
    {
        $aNotice = CommonService::notice();
        return array_merge(
            $this->getSeoData(),
            [
                'sWebCharset'        => 'utf-8',
                'aCityList'          => $this->getOpenedCities(),
                'sCurrentCityName'   => array_get($this->aCurrentCity, 'sName', ''),
                'iCurrentCityID'     => array_get($this->aCurrentCity, 'iID', 0),
                'iCurrentCityPinyin' => array_get($this->aCurrentCity, 'sPinyin', 'sh'),
                'sCurrentCityPinyin' => array_get($this->aCurrentCity, 'sPinyin', 'sh'),
                'aCityGroup'         => $this->getRegionCity(),
                'iCommNoticeStatus'  => array_get($aNotice, 'iStatus', 0),
                'sCommNoticeContent' => array_get($aNotice, 'sContent', ''),
                'sLoginURL'          => Url::member('v2/web/user/login', [], true),
                'sRegisterURL'       => Url::member('v2/web/user/register', [], true),
                'sActiveMenu'        => $this->getActiveMenu(),
                'bWX'                => $this->hideTopBanner(),
                'bAPP'               => $this->isApp(),
            ]
        );
    }

    /**
     * 获取尾数据
     *
     * @author Sinute
     * @date   2015-12-02
     * @return array
     */
    protected function getFooterData()
    {
        return [
            'sPhone' => $this->sPhone, //联系电话
        ];
    }

    /**
     * 获取激活的菜单
     *
     * @author Sinute
     * @date   2015-12-02
     * @return string
     */
    protected function getActiveMenu()
    {
        return array_get(
            [
                'www'      => 'index', // 首页
                'xf'       => 'xf', // 新房
                'esf'      => 'esf', // 二手房
                'zf'       => 'zf', // 租房
                'overseas' => 'abroad', // 海外
                // 'finace'   => 'finace', // 金融
                // 'crowd'    => 'crowd', // 众筹
                'xq'       => 'xq', // 小区
                'news'     => 'news', // 资讯
            ],
            static::whoAmI()
        );
    }

    /**
     * 是否隐藏顶栏
     *
     * @author Sinute
     * @date   2015-12-02
     * @return boolean
     */
    protected function hideTopBanner()
    {
        if (empty($_SERVER['HTTP_USER_AGENT'])) {
            return false;
        }
        $userAgent = addslashes($_SERVER['HTTP_USER_AGENT']);
        return (
            strpos($userAgent, 'MicroMessenger') === false &&
            strpos($userAgent, 'Windows Phone') === false &&
            strpos($userAgent, 'haofang') === false
        ) ? false : true;
    }

    /**
     * 是否为app
     *
     * @author Sinute
     * @date   2015-12-02
     * @return boolean
     */
    protected function isApp()
    {
        if (empty($_SERVER['HTTP_USER_AGENT'])) {
            return false;
        }
        $userAgent = addslashes($_SERVER['HTTP_USER_AGENT']);
        return (strpos($userAgent, 'haofang') === false) ? false : true;
    }
}
