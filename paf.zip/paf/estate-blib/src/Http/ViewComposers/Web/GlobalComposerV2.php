<?php
namespace Paf\EstateBLib\Http\ViewComposers\Web;

use Paf\EstateBLib\Foundation\Url;
use Paf\EstateBLib\Http\ViewComposers\GlobalComposerV2 as BaseGlobalComposer;
use Paf\EstateBLib\Services\CommonService;

/**
 * 公共头尾数据
 */
class GlobalComposerV2 extends BaseGlobalComposer
{
    /**
     * 获取头数据
     *
     * @author Sinute
     * @date   2015-12-02
     * @return array
     */
    protected function getHeaderData()
    {
        $aNotice = CommonService::notice();
        return $this->resolveHeaderData([
            'iCommNoticeStatus'  => array_get($aNotice, 'iStatus', 0),
            'sCommNoticeContent' => array_get($aNotice, 'sContent', ''),
            'sActiveMenu'        => $this->getActiveMenu(),
        ]);
    }

    /**
     * 获取尾数据
     *
     * @author Sinute
     * @date   2015-12-02
     * @return array
     */
    protected function getFooterData()
    {
        return $this->resolveFooterData([]);
    }

    /**
     * 获取激活的菜单
     *
     * @author Sinute
     * @date   2015-12-02
     * @return string
     */
    protected function getActiveMenu()
    {
        return array_get(
            [
                'www'      => 'index', // 首页
                'xf'       => 'xf', // 新房
                'esf'      => 'esf', // 二手房
                'zf'       => 'zf', // 租房
                'overseas' => 'abroad', // 海外
                // 'finace'   => 'finace', // 金融
                // 'crowd'    => 'crowd', // 众筹
                'xq'       => 'xq', // 小区
                'news'     => 'news', // 资讯
            ],
            static::whoAmI()
        );
    }
}
