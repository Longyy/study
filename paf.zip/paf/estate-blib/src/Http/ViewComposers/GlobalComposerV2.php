<?php
namespace Paf\EstateBLib\Http\ViewComposers;

use Closure;
use Illuminate\Contracts\View\View;
use Paf\EstateBLib\Foundation\Seo;
use Paf\EstateBLib\Foundation\Url;

/**
 * 公共头尾数据
 *
 * 保留字段:
 *     sPGID 用于设置piwik统计id
 */
abstract class GlobalComposerV2
{
    /**
     * 当前频道
     * @var string
     * www, xf, esf, zf, overseas, xq
     */
    protected static $sChannel;

    /**
     * 是否已初始化
     * @var boolean
     */
    protected static $bInit;

    /**
     * 当前城市
     * @var array
     */
    protected $aCurrentCity;

    /**
     * 已开放城市
     * @var array
     */
    protected $aOpenedCities;

    /**
     * 城市区域
     * @var array
     */
    protected $aRegionCities;

    /**
     * 总机
     * @var string
     */
    protected $sPhone;

    /**
     * 头数据
     * @var \Closure
     */
    protected static $oHeaderDataResolver;

    /**
     * 尾数据
     * @var \Closure
     */
    protected static $oFooterDataResolver;

    /**
     * 通用数据
     * @var \Closure
     */
    protected static $oGlobalDataResolver;

    /**
     * 视图对象
     * @var object
     */
    protected $oView;

    public function compose(View $oView)
    {
        if (!static::$bInit) {
            $this->oView = $oView;

            $this->initCity();
            $this->initPhone();

            $oView->with('globalData', $this->getGlobalData());
            $oView->with('headerData', $this->getHeaderData());
            $oView->with('footerData', $this->getFooterData());

            static::$bInit = true;
        }
    }

    /**
     * 通用数据
     *
     * @author Sinute
     * @date   2015-12-09
     * @return array
     */
    protected function getGlobalData()
    {
        $sCityPy = array_get($this->aCurrentCity, 'sPinyin', 'sh');

        return $this->resolveGlobalData([
            'sPGID'       => md5(sprintf('%s:%s', env('APP_NAME'), $this->oView->name())), // piwikID
            'iPrsTime'    => intval(microtime(true) * 1000), // piwik时间

            'sWebCharset' => 'utf-8',
            'aCityList'   => $this->getOpenedCities(),
            'aCityGroup'  => $this->getRegionCity(),
            'aCity'       => [
                'sName'   => array_get($this->aCurrentCity, 'sName', '上海'),
                'iID'     => array_get($this->aCurrentCity, 'iID', 1),
                'sPinyin' => array_get($this->aCurrentCity, 'sPinyin', 'sh'),
            ],
            'aUrl'        => [
                'base'      => Url::base('', [], ''),
                'anhouse'   => Url::anhouse('', [], ''),
                'internal'  => Url::internal('', [], ''),
                'sInternal' => Url::sInternal('', [], ''),
                'static'    => Url::staticUrl(),
            ],
            'aSeo'        => $this->getSeoData(),

            'bAPP'        => $this->isApp(),
            'bWX'         => $this->hideTopBanner(),
            'sPhone'      => $this->sPhone,
        ]);
    }

    /**
     * 是否为app
     *
     * @author Sinute
     * @date   2015-12-02
     * @return boolean
     */
    protected function isApp()
    {
        if (empty($_SERVER['HTTP_USER_AGENT'])) {
            return false;
        }
        $userAgent = addslashes($_SERVER['HTTP_USER_AGENT']);
        return (strpos($userAgent, 'haofang') === false) ? false : true;
    }

    /**
     * 是否隐藏顶栏
     *
     * @author Sinute
     * @date   2015-12-02
     * @return boolean
     */
    protected function hideTopBanner()
    {
        if (empty($_SERVER['HTTP_USER_AGENT'])) {
            return false;
        }
        $userAgent = addslashes($_SERVER['HTTP_USER_AGENT']);
        return (
            strpos($userAgent, 'MicroMessenger') === false &&
            strpos($userAgent, 'Windows Phone') === false &&
            strpos($userAgent, 'haofang') === false
        ) ? false : true;
    }

    /**
     * 获取头数据
     *
     * @author Sinute
     * @date   2015-12-09
     * @return array
     */
    abstract protected function getHeaderData();

    /**
     * 获取尾数据
     *
     * @author Sinute
     * @date   2015-12-09
     * @return array
     */
    abstract protected function getFooterData();

    /**
     * 初始化城市数据
     *
     * @author Sinute
     * @date   2015-12-02
     */
    protected function initCity()
    {
        if (!static::hasCity()) {
            $this->aCurrentCity  = [];
            $this->aOpenedCities = [];
            $this->aRegionCities = [];
        } else {
            $this->aCurrentCity = static::getCity()->getCurrentCity();
            if ($sAbbreviate = array_get($this->aCurrentCity, 'sAbbreviate')) {
                $this->aCurrentCity['sPinyin'] = $sAbbreviate;
            }
            $aOpenedCities = static::getCity()->getOpenedCities(static::whoAmI());
            array_walk($aOpenedCities, function (&$aOpenedCity, $iCityID) {
                $sPinyin     = array_get($aOpenedCity, 'sPinyin');
                $aOpenedCity = [
                    'iCityID' => $iCityID,
                    'sPinyin' => $sPinyin,
                    'sName'   => array_get($aOpenedCity, 'sName'),
                ];
            });
            // 当前频道已开放城市
            $this->aOpenedCities = $aOpenedCities;
            $aRegionCities       = static::getCity()->getRegionCity();
            $this->aRegionCities = [];
            // 已开放的区域城市
            foreach ($aRegionCities as $sRegion => $aCities) {
                $aRegionCity = array_intersect_key($aCities, $this->aOpenedCities);
                if ($aRegionCity) {
                    $this->aRegionCities[] = [
                        'sName' => $sRegion,
                        'aIds'  => array_keys($aRegionCity),
                    ];
                }
            }
        }
    }

    /**
     * 是否区分城市
     *
     * @author Sinute
     * @date   2015-12-23
     * @return boolean
     */
    protected static function hasCity()
    {
        return app()->bound('service.city');
    }

    /**
     * 获取城市
     *
     * @author Sinute
     * @date   2015-12-23
     * @return object
     */
    protected static function getCity()
    {
        return app('service.city');
    }

    /**
     * 初始化电话数据
     *
     * @author Sinute
     * @date   2015-12-10
     */
    protected function initPhone()
    {
        $this->sPhone = config('400.sSwitchboard', '400-868-1111');
    }

    /**
     * 设定当前频道
     *
     * @author Sinute
     * @date   2015-12-02
     * @param  string     $sWho 当前频道
     */
    public static function iAm($sWho)
    {
        static::$sChannel = $sWho;
        if (static::hasCity()) {
            static::getCity()->iAm($sWho);
        }
    }

    /**
     * 获取当前频道
     *
     * @author Sinute
     * @date   2015-12-08
     * @return string
     */
    public static function whoAmI()
    {
        if (static::$sChannel) {
            return static::$sChannel;
        } else {
            return strtolower(str_replace('-web', '', env('APP_NAME')));
        }
    }

    /**
     * 获取seo数据
     *
     * @author Sinute
     * @date   2015-12-02
     * @return array
     */
    protected function getSeoData()
    {
        $sCityName = array_get($this->aCurrentCity, 'sName', '');
        return [
            'sTitle'    => Seo::getTitle('平安好房'),
            'sKeyWords' => Seo::getKeywords("{$sCityName}好房"),
            'sDesc'     => Seo::getDesc("平安好房网(Pinganfang.com) 是中国平安集团下的专业房地产平台，专业提供{$sCityName}新房、{$sCityName}二手房、{$sCityName}租房、海外房产等服务，并有在线购房、在线租房、在线竞价、在线支付等多项全新的服务功能，满足您的不同需求"),
        ];
    }

    /**
     * 获取已开放城市
     *
     * @author Sinute
     * @date   2015-12-02
     * @return array
     */
    protected function getOpenedCities()
    {
        return $this->aOpenedCities;
    }

    /**
     * 获取区域城市
     *
     * @author Sinute
     * @date   2015-12-02
     * @return array
     */
    protected function getRegionCity()
    {
        return $this->aRegionCities;
    }

    /**
     * 通用数据处理器
     *
     * @author Sinute
     * @date   2016-07-01
     * @param  \Closure    $oGlobalDataResolver 通用数据处理器
     */
    public static function globalDataResolver(Closure $oGlobalDataResolver)
    {
        static::$oGlobalDataResolver = $oGlobalDataResolver;
    }

    /**
     * 处理通用数据
     *
     * @author Sinute
     * @date   2016-07-01
     * @return array
     */
    protected function resolveGlobalData(array $aGlobalData)
    {
        if (isset(static::$oGlobalDataResolver)) {
            return call_user_func(static::$oGlobalDataResolver->bindTo($this), $aGlobalData);
        }

        return $aGlobalData;
    }

    /**
     * 头数据处理器
     *
     * @author Sinute
     * @date   2016-07-01
     * @param  \Closure    $oHeaderDataResolver 头数据处理器
     */
    public static function headerDataResolver(Closure $oHeaderDataResolver)
    {
        static::$oHeaderDataResolver = $oHeaderDataResolver;
    }

    /**
     * 处理头数据
     *
     * @author Sinute
     * @date   2016-07-01
     * @return array
     */
    protected function resolveHeaderData(array $aHeaderData)
    {
        if (isset(static::$oHeaderDataResolver)) {
            return call_user_func(static::$oHeaderDataResolver->bindTo($this), $aHeaderData);
        }

        return $aHeaderData;
    }

    /**
     * 尾数据处理器
     *
     * @author Sinute
     * @date   2016-07-01
     * @param  \Closure    $oFooterDataResolver 尾数据处理器
     */
    public static function footerDataResolver(Closure $oFooterDataResolver)
    {
        static::$oFooterDataResolver = $oFooterDataResolver;
    }

    /**
     * 处理尾数据
     *
     * @author Sinute
     * @date   2016-07-01
     * @return array
     */
    protected function resolveFooterData(array $aFooterData)
    {
        if (isset(static::$oFooterDataResolver)) {
            return call_user_func(static::$oFooterDataResolver->bindTo($this), $aFooterData);
        }

        return $aFooterData;
    }
}
