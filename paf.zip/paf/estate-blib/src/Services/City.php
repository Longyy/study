<?php
namespace Paf\EstateBLib\Services;

/**
 * 城市信息
 */
class City
{
    protected $aOpenedCities; // 已开通的城市
    protected $aCurrentCity; // 当前城市
    protected $aRegionCities; // 区域城市
    protected static $sChannel; // 当前频道, 用于关联已开放城市

    public function __construct()
    {
        $this->aOpenedCities = [];
        $this->aRegionCities = [];
    }

    /**
     * 缓存当前城市信息
     *
     * @author Sinute
     * @date   2015-12-02
     * @param  array     $aCity 城市信息
     */
    public function setCurrentCity($aCity)
    {
        $this->aCurrentCity = [
            'iID'         => array_get($aCity, 'iID', 0),
            'sName'       => array_get($aCity, 'sName', ''),
            'sPinyin'     => array_get($aCity, 'sPinyin', ''),
            'sAbbreviate' => array_get($aCity, 'sAbbreviate', ''),
        ];
        return $this;
    }

    /**
     * 获取区域数据
     *
     * @author Sinute
     * @date   2015-12-02
     * @return array     区域数据
     */
    public function getRegionCity()
    {
        if (!$this->aRegionCities) {
            $this->aRegionCities = CommonService::regionCities();
        }
        return $this->aRegionCities ?: [];
    }

    /**
     * 获取区域数据
     *
     * @author Sinute
     * @date   2016-04-25
     * @param  array      $aRegionCities 区域数据
     */
    public function setRegionCity(array $aRegionCities)
    {
        $this->aRegionCities = $aRegionCities;
    }

    /**
     * 获取当前城市信息
     *
     * @author Sinute
     * @date   2015-12-02
     * @param  string     $sField 城市字段
     * @return mix                城市信息
     */
    public function getCurrentCity($sField = null)
    {
        return $this->getField($this->aCurrentCity, $sField);
    }

    /**
     * 设置已开放城市
     *
     * @author Sinute
     * @date   2016-04-25
     * @param  array      $aOpenedCities 已开放的城市数据
     */
    public function setOpenedCities(array $aOpenedCities)
    {
        $this->aOpenedCities = array_merge($this->aOpenedCities, $aOpenedCities);
    }

    /**
     * 获取已开放的城市
     *
     * @author Sinute
     * @date   2015-12-02
     * @param  string     $sChannel 频道
     * @return array                已开放的城市数据
     */
    public function getOpenedCities($sChannel = null)
    {
        $sChannel = $sChannel ?: static::whoAmI();
        if (!isset($this->aOpenedCities[$sChannel])) {
            if ($sPath = realpath(dirname(__DIR__) . "/Config/OpenedCities/{$sChannel}.php")) {
                $this->aOpenedCities[$sChannel] = require $sPath;
            } else {
                $this->aOpenedCities[$sChannel] = [];
            }
        }
        return array_get($this->aOpenedCities, $sChannel, []);
    }

    /**
     * 判断该城市是否已经开放
     *
     * @author Sinute
     * @date   2015-12-08
     * @param  string      $sChannel   频道
     * @param  integer     $iCityID    城市ID
     * @return boolean
     */
    public function isOpened($iCityID, $sChannel = null)
    {
        return isset($this->getOpenedCities($sChannel)[$iCityID]);
    }

    /**
     * 获取城市
     *
     * @author Sinute
     * @date   2015-12-01
     * @param  mixed      $mCityIdentify 城市缩写/拼音
     * @return array                     城市信息
     */
    public function get($mCityIdentify, $sField = null)
    {
        return $this->getField(CommonService::city($mCityIdentify), $sField);
    }

    /**
     * 获取城市字段
     *
     * @author Sinute
     * @date   2015-12-08
     * @param  array      $aCity    城市信息
     * @param  string     $sField   字段名
     * @return
     */
    protected function getField($aCity, $sField = null)
    {
        if ($sField) {
            if ($sField == 'sPinyin') {
                ($sPinyin = array_get($aCity, 'sAbbreviate')) || ($sPinyin = array_get($aCity, 'sPinyin'));
                return $sPinyin;
            }
            return array_get($aCity, $sField);
        } else {
            return $aCity;
        }
    }

    /**
     * 设定当前频道
     *
     * @author Sinute
     * @date   2015-12-08
     * @param  string     $sWho 当前频道
     */
    public static function iAm($sWho)
    {
        static::$sChannel = $sWho;
    }

    /**
     * 获取当前频道
     *
     * @author Sinute
     * @date   2015-12-08
     * @return string
     */
    public static function whoAmI()
    {
        if (static::$sChannel) {
            return static::$sChannel;
        } else {
            return strtolower(str_replace('-web', '', env('APP_NAME')));
        }
    }
}
