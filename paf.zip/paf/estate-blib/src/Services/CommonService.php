<?php
namespace Paf\EstateBLib\Services;

use Carbon\Carbon;
use Log;
use Paf\EstateBLib\Foundation\Url;
use Paf\LightService\Client\Service;

/**
 * common-service
 */
class CommonService
{
    protected static $oCommonService; // 通用服务
    protected static $oWwwService; // www服务

    protected static function getCommonService()
    {
        if (isset(static::$oCommonService)) {
            return static::$oCommonService;
        }
        Service::importConf(
            [
                'blib-common-service' => [
                    'type'     => 'http',
                    'protocol' => 'jsonrpc',
                    'conf'     => [
                        'url'          => Url::commonService('/rpc', [], 'http://'),
                        'header'       => ['Content-Type: application/json'],
                        'exec_timeout' => 10000, // 10s
                    ],
                ],
            ]
        );
        static::$oCommonService = Service::get('blib-common-service');
        return static::$oCommonService;
    }

    protected static function getWwwService()
    {
        if (isset(static::$oWwwService)) {
            return static::$oWwwService;
        }
        Service::importConf(
            [
                'blib-www-service' => [
                    'type'     => 'http',
                    'protocol' => 'jsonrpc',
                    'conf'     => [
                        'url'          => Url::wwwService('/rpc', [], 'http://'),
                        'header'       => ['Content-Type: application/json'],
                        'exec_timeout' => 10000, // 10s
                    ],
                ],
            ]
        );
        static::$oWwwService = Service::get('blib-www-service');
        return static::$oWwwService;
    }

    /**
     * 缓存过期时间(下个时间点)
     *
     * @author Sinute
     * @date   2015-11-30
     * @param  [type]     $iMinute 15为每个整15分过期(0,15,30,45), 30为每个整30分过期(0,30)
     * @return \Carbon\Carbon
     */
    protected static function expireAtNext($iMinute)
    {
        $oExpireTime         = Carbon::now();
        $oExpireTime->second = 0;
        $oExpireTime->minute += (30 - $oExpireTime->minute % 30);
        return $oExpireTime;
    }

    /**
     * 获取区域城市(头部城市导航数据)
     *
     * @author Sinute
     * @date   2015-12-31
     * @return array
     */
    public static function regionCities()
    {
        if (!($sCommonServiceKey = app('auth.service.config')->get('common-service.key'))) {
            Log::notice('未找到common-service密钥, 获取区域城市信息失败');
            return [];
        }
        // 有缓存直接读取
        $sCacheKey = 'ESTATE_BLIB:COMMON_SERVICE:CHINA_CITY:REGION_CITIES';
        if ($aRegionCities = app('cache')->get($sCacheKey)) {
            return $aRegionCities;
        }

        $oModule      = static::getCommonService()->module('CityChannelController');
        $aParams      = [];
        $iRequestTime = time();
        $sToken       = app('auth.service.token')->generate($aParams, $iRequestTime, $sCommonServiceKey);
        $mResponse    = $oModule->regionCity(['version' => '1.0', 'from' => config('rpc.from'), 'requestTime' => $iRequestTime, 'token' => $sToken, 'trackId' => app('request.client')->getTrackID()], $aParams);
        if (array_get($mResponse, 'bSuccess')) {
            $aRegionCities = [];
            foreach (array_get($mResponse, 'aData') as $sRegionName => $aCities) {
                foreach ($aCities as $iCityID => $aCityInfo) {
                    $aRegionCities[$sRegionName][$iCityID] = [
                        'sPinyin' => $aCityInfo['sPinyin'],
                        'sName'   => $aCityInfo['sName'],
                    ];
                }

            }
            app('cache')->put($sCacheKey, $aRegionCities, static::expireAtNext(30));
            return $aRegionCities;
        } else {
            $sError = $oModule->errstr();
            Log::warning('RPC ERROR [common-service], 获取区域城市信息失败', compact('aParams', 'mResponse', 'sError'));
        }
        return [];
    }

    /**
     * 获取城市信息
     *
     * @author Sinute
     * @date   2015-12-01
     * @param  mixed      $mCityIdentify 城市缩写/拼音
     * @return array                     城市信息
     */
    public static function city($mCityIdentify)
    {
        if (!($sCommonServiceKey = app('auth.service.config')->get('common-service.key'))) {
            Log::notice('未找到common-service密钥, 获取城市信息失败');
            return [];
        }
        $sPinyin = null;
        $iID     = null;
        if (is_array($mCityIdentify)) {
            $sPinyin = strtolower(array_get($mCityIdentify, 'sPinyin'));
            $iID     = array_get($mCityIdentify, 'iID');
        } elseif (intval($mCityIdentify) > 0) {
            $iID = intval($mCityIdentify);
        } else {
            $sPinyin = strtolower((string) $mCityIdentify);
        }

        $sPinyinCacheKeyPrefix = 'ESTATE_BLIB:COMMON_SERVICE:REGION:CITY_DETAIL:PINYIN';
        $sIDCacheKeyPrefix     = 'ESTATE_BLIB:COMMON_SERVICE:REGION:CITY_DETAIL:ID';

        // 有缓存直接读取
        if ($sPinyin) {
            $sCacheKey = sprintf('%s:%s', $sPinyinCacheKeyPrefix, $sPinyin);
            $aParams   = [['sPinyin' => $sPinyin]];
        } elseif ($iID) {
            $sCacheKey = sprintf('%s:%s', $sIDCacheKeyPrefix, $iID);
            $aParams   = [['iAutoID' => $iID]];
        } else {
            return [];
        }
        if ($aCity = app('cache')->get($sCacheKey)) {
            return $aCity;
        }

        $oModule      = static::getCommonService()->module('RegionController');
        $iRequestTime = time();
        $sToken       = app('auth.service.token')->generate($aParams, $iRequestTime, $sCommonServiceKey);
        $mResponse    = $oModule->getCityDetail(['version' => '1.0', 'from' => config('rpc.from'), 'requestTime' => $iRequestTime, 'token' => $sToken, 'trackId' => app('request.client')->getTrackID()], $aParams);
        if (array_get($mResponse, 'bSuccess') && array_get($mResponse, 'aData.iAutoID')) {
            $oExpireTime = static::expireAtNext(30);
            $aCity       = [
                'iID'         => array_get($mResponse, 'aData.iAutoID'),
                'sName'       => array_get($mResponse, 'aData.sName'),
                'sPinyin'     => array_get($mResponse, 'aData.sPinyin'),
                'sAbbreviate' => array_get($mResponse, 'aData.sAbbreviate'),
            ];
            // 缓存数据
            app('cache')->put(sprintf('%s:%s', $sIDCacheKeyPrefix, $aCity['iID']), $aCity, $oExpireTime);
            if ($aCity['sAbbreviate']) {
                app('cache')->put(sprintf('%s:%s', $sPinyinCacheKeyPrefix, $aCity['sAbbreviate']), $aCity, $oExpireTime);
            }
            if ($aCity['sPinyin']) {
                app('cache')->put(sprintf('%s:%s', $sPinyinCacheKeyPrefix, $aCity['sPinyin']), $aCity, $oExpireTime);
            }
            return $aCity;
        } else {
            $sError = $oModule->errstr();
            Log::warning('RPC ERROR [common-service], 获取城市信息失败', compact('aParams', 'mResponse', 'sError'));
        }
        return [];
    }

    /**
     * 获取全站公告
     *
     * @author Sinute
     * @date   2015-12-31
     * @return array     公告信息
     */
    public static function notice()
    {
        if (!($sWwwServiceKey = app('auth.service.config')->get('www-service.key'))) {
            Log::notice('未找到www-service密钥, 获取全站公告失败');
            return [];
        }
        // 有缓存直接读取
        $sCacheKey = 'ESTATE_BLIB:WWW_SERVICE:RECOMMEND:INDEX:NOTICE';
        if ($aNotice = app('cache')->get($sCacheKey)) {
            return $aNotice;
        }

        $oModule      = static::getWwwService()->module('RecommendController');
        $aParams      = [['sKey' => 'notice_notice']];
        $iRequestTime = time();
        $sToken       = app('auth.service.token')->generate($aParams, $iRequestTime, $sWwwServiceKey);
        $mResponse    = $oModule->index([
            'version'     => '1.0',
            'from'        => config('rpc.from'),
            'requestTime' => $iRequestTime,
            'token'       => $sToken,
            'trackId'     => app('request.client')->getTrackID(),
        ], $aParams);
        if (array_get($mResponse, 'bSuccess')) {
            $mResponse = array_first(array_get($mResponse, 'aData.aList', []), function ($iIndex, $aData) {return array_get($aData, 'sKey') == 'notice_notice';}, []);
            $aContent = json_decode(array_get($mResponse, 'sPublishData'), true);
            $aContent = array_first(is_array($aContent) ? $aContent : [], function ($iIndex, $aData) {return array_get($aData, 'iEndTime', 0) > time();}, []);
            $aNotice['sContent'] = array_get($aContent, 'sTitle', '');
            $aNotice['iStatus']  = !!$aNotice['sContent'];
            // 公告每个10整分刷新一次
            app('cache')->put($sCacheKey, $aNotice, static::expireAtNext(10));
            return $aNotice;
        } else {
            $sError = $oModule->errstr();
            Log::warning('RPC ERROR [www-service], 获取全站公告失败', compact('aParams', 'mResponse', 'sError'));
        }
        return [];
    }
}
