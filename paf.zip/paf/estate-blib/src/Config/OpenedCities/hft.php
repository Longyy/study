<?php

return [
    1    => ['sPinyin' => 'sh', 'sName' => '上海'],
    1018 => ['sPinyin' => 'nj', 'sName' => '南京'],
    1337 => ['sPinyin' => 'hz', 'sName' => '杭州'],
    1506 => ['sPinyin' => 'suzhou', 'sName' => '苏州'],
    1725 => ['sPinyin' => 'cq', 'sName' => '重庆'],
    1916 => ['sPinyin' => 'tj', 'sName' => '天津'],
    2299 => ['sPinyin' => 'wuhan', 'sName' => '武汉'],
    239  => ['sPinyin' => 'gz', 'sName' => '广州'],
    2610 => ['sPinyin' => 'zhengzhou', 'sName' => '郑州'],
    2737 => ['sPinyin' => 'changsha', 'sName' => '长沙'],
    3227 => ['sPinyin' => 'xian', 'sName' => '西安'],
    3350 => ['sPinyin' => 'ningbo', 'sName' => '宁波'],
    3643 => ['sPinyin' => 'fuzhou', 'sName' => '福州'],
    365  => ['sPinyin' => 'sz', 'sName' => '深圳'],
    3943 => ['sPinyin' => 'sy', 'sName' => '沈阳'],
    4202 => ['sPinyin' => 'nc', 'sName' => '南昌'],
    4419 => ['sPinyin' => 'xm', 'sName' => '厦门'],
    478  => ['sPinyin' => 'bj', 'sName' => '北京'],
    816  => ['sPinyin' => 'chengdu', 'sName' => '成都'],
];
