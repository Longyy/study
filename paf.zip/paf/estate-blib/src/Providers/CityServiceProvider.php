<?php
namespace Paf\EstateBLib\Providers;

use Illuminate\Support\ServiceProvider;

/**
 * 获取城市信息
 *
 * @desc 获取城市导航以及当前频道已开通城市
 */
class CityServiceProvider extends ServiceProvider
{
    public function register()
    {
        $this->app->singleton('service.city', function ($oApp) {
            return new \Paf\EstateBLib\Services\City();
        });
    }
}
