<?php
namespace Paf\EstateBLib\Providers;

use Illuminate\Support\ServiceProvider;

/**
 * 域名自动配置
 *
 * 使用Paf\EstateBLib\Foundation\Url自动生成, 不再注册到config
 */
class DomainServiceProvider extends ServiceProvider
{
    public function register()
    {
        //
    }
}
