<?php
namespace Paf\EstateBLib\Providers;

use Illuminate\Support\ServiceProvider;

/**
 * 400电话自动配置
 *
 * @desc 自动注册400电话到config('400.*')
 */
class SwitchboardServiceProvider extends ServiceProvider
{
    public function register()
    {
        config(['400' => static::getSwitchboardConfig()]);
    }

    protected static function getSwitchboardConfig()
    {
        return array_merge(
            [
                'sSwitchboard'     => '400-868-1111',
                'sEsf'             => '1',
                'sAnanzu'          => '2',
                'sOverseas'        => '3',
                'sXf'              => '4',
                // 5 null
                'sZc'              => '6',
                'sHft'             => '7',
                'sHfb'             => '8',
                'sHfd'             => '9',
                'sCustomerService' => '0',
            ],
            config('400', [])
        );
    }
}
