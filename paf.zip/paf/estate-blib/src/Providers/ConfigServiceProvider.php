<?php
namespace Paf\EstateBLib\Providers;

use Illuminate\Support\AggregateServiceProvider;

class ConfigServiceProvider extends AggregateServiceProvider
{
    protected $providers = [
        'Paf\EstateBLib\Providers\SwitchboardServiceProvider',
    ];
}
