<?php
namespace Paf\EstateBLib\Providers;

use Illuminate\Support\ServiceProvider;
use Paf\EstateBLib\Foundation\Url;

/**
 * cookie配置 (依赖DomainServiceProvider提供cookie_domain)
 *
 * @desc 设置guid, cookie_domain
 */
class CookieServiceProvider extends ServiceProvider
{
    public function boot()
    {
        $this->app['cookie']->setDefaultPathAndDomain('/', Url::cookieBase('', [], ''));
    }

    public function register()
    {
        //
    }
}
