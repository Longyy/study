<?php
namespace Paf\EstateBLib\Member;

use Closure;
use Estate\Exceptions\ServiceException;
use Paf\EstateBLib\Foundation\Url;
use Paf\LightService\Client\Service;

/**
 * 检查用户是否已登陆
 */
class CheckLogin
{
    static $aLoginTokenTypes = [
        'hf'  => 1, //好房APP端token_type
        'hft' => 3, //好房拓APP端token_type
        'aaz' => 5, //安安租APP端token_type
    ];

    public function handle($oRequest, Closure $oNext)
    {
        Service::importConf(
            [
                'member' => [
                    'type'     => 'http',
                    'protocol' => 'jsonrpc',
                    'conf'     => [
                        'url' => (env('DOMAIN_SERVICE_MEMBER') ?: Url::serviceMember('', [], '')) . '/v2' . env('MEMBER_SERVICE_ACCESS_TOKEN'),
                    ],
                ],
            ]
        );
        $oMember    = Service::get('member');
        $oMember    = $oMember->module('External\\User');
        $sAppType   = array_get($_SERVER, 'HTTP_APP_TYPE', 'hft');
        $sToken     = $oRequest->get('token');
        if(!$sToken) {
            $sToken = $oRequest->get('sToken');
        }
        $iTokenType = array_get(self::$aLoginTokenTypes, $sAppType, env('LOGIN_TOKEN_TYPE'));
        $aRet       = $oMember->getTokenInfo($sToken, $iTokenType);

        if (isset($aRet['code']) && '0000' == $aRet['code'] && $aRet['data']) {
            $iUserID = $oRequest->get('user_id');
            if(!$iUserID) {
                $iUserID = $oRequest->get('iUserID');
            }
            if ($iUserID == $aRet['data']['iUserID']) {
                return $oNext($oRequest);
            } else {
                throw new ServiceException('请先登录', 200001);
            }

        } else {
            throw new ServiceException('请先登录', 200001);
        }

    }
}
