<?php
namespace Paf\EstateBLib\Foundation;

/**
 * 图片地址生成
 */
class Image
{
    /**
     * 默认图片尺寸匹配数组
     * @var array
     */
    public static $aDefault = [
        67  => [
            50 => [67, 50, '4_3'],
        ],
        96  => [
            72 => [96, 72, '4_3'],
        ],
        134 => [
            100 => [134, 100, '4_3'],
        ],
        160 => [
            120 => [160, 120, '4_3'],
        ],
        200 => [
            150 => [200, 150, '4_3'],
        ],
        220 => [
            165 => [220, 165, '4_3'],
            160 => [220, 165, '4_3'],
        ],
        300 => [
            225 => [300, 225, '4_3'],
        ],
        528 => [
            297 => [528, 297, '16_9'],
        ],
        640 => [
            360 => [640, 360, '16_9'],
        ],
        120 => [
            120 => [120, 120, '1_1'],
        ],
        240 => [
            240 => [240, 240, '1_1'],
        ],
    ];

    /**
     * 生成默认图片地址
     *
     * @author Sinute
     * @date   2015-12-01
     * @param  integer     $iWidth  宽度
     * @param  integer     $iHeight 高度
     * @return string               图片地址
     */
    public static function defaultUrl($iWidth, $iHeight)
    {
        if (isset(static::$aDefault[$iWidth][$iHeight])) {
            return Url::staticUrl(
                sprintf('/img/common/album/album_default_grey_%s_%s_%s.png',
                    static::$aDefault[$iWidth][$iHeight][2],
                    static::$aDefault[$iWidth][$iHeight][0],
                    static::$aDefault[$iWidth][$iHeight][1]
                )
            );
        } else {
            return Url::staticUrl('/img/common/album/album_default_grey_16_9_640_360.png');
        }
    }

    /**
     * 生成图片地址
     *
     * @author Sinute
     * @date   2015-12-01
     * @param  string     $sType      图片通道
     * @param  string     $sFileKey   图片key
     * @param  string     $sExtension 图片扩展名
     * @param  integer    $iWidth     宽度
     * @param  integer    $iHeight    高度
     * @param  string     $sOption    额外参数
     * @return string                 图片地址
     */
    public static function url($sType, $sFileKey, $sExtension, $iWidth = 0, $iHeight = 0, $sOption = '')
    {
        if (!$sFileKey || !$sExtension) {
            return static::defaultUrl($iWidth, $iHeight);
        }
        if (0 == $iWidth && 0 == $iHeight) {
            return Url::file(sprintf('/view/%s/%s.%s', $sType, $sFileKey, $sExtension));
        } else {
            if ('' == $sOption) {
                return Url::file(sprintf('/view/%s/%s/%sx%s.%s', $sType, $sFileKey, $iWidth, $iHeight, $sExtension));
            } else {
                return Url::file(sprintf('/view/%s/%s/%sx%s_%s.%s', $sType, $sFileKey, $iWidth, $iHeight, $sOption, $sExtension));
            }
        }
    }
}
