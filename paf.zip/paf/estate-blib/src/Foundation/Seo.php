<?php
namespace Paf\EstateBLib\Foundation;

/**
 * SEO配置
 */
class Seo
{
    protected static $aData;

    /**
     * 设置标题
     *
     * @author Sinute
     * @date   2015-11-26
     * @param  string     $sTitle 标题
     */
    public static function setTitle($sTitle)
    {
        static::$aData['sTitle'] = $sTitle;
    }

    /**
     * 获取标题
     *
     * @author Sinute
     * @date   2015-11-26
     * @param  string     $sTitle 默认标题
     * @return string             标题
     */
    public static function getTitle($sTitle = '')
    {
        return array_get(static::$aData, 'sTitle', $sTitle);
    }

    /**
     * 设置描述
     *
     * @author Sinute
     * @date   2015-11-26
     * @param  string     $sDesc 描述
     */
    public static function setDesc($sDesc)
    {
        static::$aData['sDesc'] = $sDesc;
    }

    /**
     * 获取描述
     *
     * @author Sinute
     * @date   2015-11-26
     * @param  string     $sDesc 默认描述
     * @return string            描述
     */
    public static function getDesc($sDesc = '')
    {
        return array_get(static::$aData, 'sDesc', $sDesc);
    }

    /**
     * 设置关键字
     *
     * @author Sinute
     * @date   2015-11-26
     * @param  string     $sKeywords 关键词
     */
    public static function setKeywords($sKeywords)
    {
        static::$aData['sKeywords'] = $sKeywords;
    }

    /**
     * 获取关键字
     *
     * @author Sinute
     * @date   2015-11-26
     * @param  string     $sKeywords 默认关键字
     * @return string                关键字
     */
    public static function getKeywords($sKeywords = '')
    {
        return array_get(static::$aData, 'sKeywords', $sKeywords);
    }
}
