<?php
namespace Paf\EstateBLib\Foundation;

/**
 * 获取url
 */
class Url
{
    public static function __callStatic($sName, $aArguments)
    {
        return call_user_func_array(['Estate\Foundation\Url', $sName], $aArguments);
    }
}
