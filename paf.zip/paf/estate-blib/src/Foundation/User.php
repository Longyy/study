<?php
namespace Paf\EstateBLib\Foundation;

/**
 * 用户信息
 */
class User
{
    protected static $aUser;

    /**
     * 载入用户数据
     *
     * @author Sinute
     * @date   2015-12-15
     * @param  array      $aUser 用户数据
     */
    public static function load(array $aUser)
    {
        static::$aUser = $aUser;
    }

    /**
     * 导出用户数据
     *
     * @author Sinute
     * @date   2015-12-15
     * @return array
     */
    public static function toArray()
    {
    	return static::$aUser ?: [];
    }

    /**
     * 获取/设置用户数据
     *
     * @author Sinute
     * @date   2015-12-15
     * @param  string     $sName      变量名
     * @param  array     $aArguments  值
     * @return mixed
     */
    public static function __callStatic($sName, $aArguments)
    {
        if (isset($aArguments[0])) {
            static::$aUser[$sName] = $aArguments[0];
        }
        return isset(static::$aUser[$sName]) ? static::$aUser[$sName] : null;
    }
}
