<?php
namespace Paf\EstateBLib\Foundation;

use Illuminate\Support\Facades\Facade;

class City extends Facade
{
    protected static function getFacadeAccessor() { return 'service.city'; }
}
