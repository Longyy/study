<?php
namespace Paf\Exception;

class ErrorLogger
{
    public static function handleException($exception)
    {
        $type = 'Unknown error';
        $msg = '';
        $log = null;

        if ($exception instanceof \ErrorException) {
            switch ($exception->getSeverity()) {
            case E_CORE_ERROR:
            case E_COMPILE_ERROR:
            case E_USER_ERROR:
                $type = 'Fatal error';
                break;
            case E_RECOVERABLE_ERROR:
                $type = 'Catchable fatal error';
                break;
            case E_WARNING:
            case E_CORE_WARNING:
            case E_COMPILE_WARNING:
            case E_USER_WARNING:
                $type = 'Warning';
                break;
            case E_NOTICE:
            case E_USER_NOTICE:
                $type = 'Notice';
                break;
            case E_STRICT:
                $type = 'Strict Standards';
                break;
            case E_DEPRECATED:
            case E_USER_DEPRECATED:
                $type = 'Deprecated';
                break;
            default:
                break;
            }

            $msg = sprintf(
                '%s in %s on line %s',
                $exception->getMessage(),
                $exception->getFile(),
                $exception->getLine()
            );
        } else {
            $type = 'Fatal error';
            $msg = 'Uncaught ' . $exception;
        }

        self::log($type, $msg);
    }

    public static function log($type, $msg)
    {
        error_log(sprintf('PHP %s: %s', $type, $msg));
    }
}
