Exception
=================

handling exception @ paf's app.

# Install
1. Add **Exception**  as a dependency to your `composer.json` file

  ```json
    "repositories": [{
      "type": "vcs",
      "url": "http://git.ipo.com/hf-dev-0/exception.git"
    }],
    "require": {
      "laravel/framework": "5.1.*",
      "paf/exception": "dev-master"
    }
  ```

2. Run `composer update`, or `composer install`

3. use `Paf\Exception\ErrorLogger::handleException($e)` to handle exception.
