## 扩展的验证方法

### 介绍

提供一些常用的表单验证方法

### 基本用法

1. uint32
	验证类型为32位无符号整型, 范围从0 ~ 4294967295, 等同于 `integer|between: 0, 4294967295` , 在验证数据库的unsigned int类型较为有效

2. int32
	验证类型为32位无符号整型, 范围从-2147493648 ~ 2147493647, 等同于 `integer|between: -2147493648, 2147493647` , 在验证数据库的signed int类型较为有效

```php
public function store(Request $oRequest)
{
    $this->validate($oRequest, [
        'iLoupanID' => 'required|uint32',
        'iInteger'  => 'required|int32',
        'sName'     => 'required|between:1,100',
    ]);
}

```

3. id_card
    验证是否为一个有效的身份证号

4. mobile
    验证是否为手机号

5. phone
    验证是否为固话号码

6. chinese
    验证是否为中文
