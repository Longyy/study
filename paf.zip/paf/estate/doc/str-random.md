## 随机字串生成

### 介绍

生成一个随机的字符串, 支持设置长度以及生成源

如果你只需要生成一个自定义长度字符串, 则可以使用框架自带的 `str_random` 方法

### 基本用法

```php
// 生成10位长度且只含有abc的随机字符串
str_quick_random(10, 'abc');

// 默认情况下生成源为'0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ'
str_quick_random(10);

// 如果只需要生成指定长度的字符串则可以使用框架自带的 str_random 方法
str_random(10);
```
