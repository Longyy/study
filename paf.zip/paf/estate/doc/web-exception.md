## 应用层异常

### 介绍

在应用层发现错误导致逻辑无法继续进行时抛出应用层异常

### 基本用法

```php
use WebException; // 引入应用层异常

throw new WebException('msg', $iCode);

```
