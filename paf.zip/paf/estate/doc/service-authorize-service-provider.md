## 服务器通信授权服务

### 介绍

服务器通信授权服务为[服务器通信授权认证中间件](authorize-validator)提供配置服务  
你需要为它提供一些参数使它能够正确运作

### 基本用法

```php
// 在app/Providers/AppServiceProvider.php中向验证服务提供连接配置

use ServiceConfig;

public function boot()
{
    // 获取新房通信配置
    $aXfService = config('services.xf');
    // 此时 $aXfService = [
    //     'key' => env('SERVICE_XF_KEY', '123456'), // 通信密钥
    //     'time_difference' => env('SERVICE_XF_TIMEDIFFERENCE', 5), // 请求时间差(秒)
    // ]
    
    // 二手房同样
    $aEsfService = config('services.esf');

    // 保存配置
    // 这边的xf和esf需要和请求的来源字段'_from'一致
    // 例如请求来源是xf则会自动匹配到$aXfService配置
    ServiceConfig::store(['xf' => $aXfService, 'esf' => $aEsfService]);

    // 设置允许访问IP白名单
    // !警告! 除非真的有必要, 否则无论如何也不要改变这个值
    $this->app('auth.service.ip')->store([
        '/^192\.168\./',
        '/^10\./',
        '/^172\.16\./',
        '/^172\.17\./',
        '/^172\.31\./',
        '/127\.0\.0\.1/',
        '/101\.95\.96\.102/',
        '/114\.80\.125\.114/',
        '/222\.73\.117\.197/'
    ]);
}
```
