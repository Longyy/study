## 服务器通信授权认证中间件

### 介绍

服务器通信授权认证中间件将会验证所有对服务层的请求

验证的条件有:
* 发起请求的时间和收到请求的时间在一个时间段范围内
* token是否合法

### 基本用法

在使用授权认证中间件之前, 你需要先为[服务器通信授权服务](service-authorize-service-provider)提供正确的配置  
然后将他注册为全局中间件

```php
// 在app/Http/Kernel.php中注册为全局中间件

protected $middleware = [
    'Estate\Http\Middleware\AuthorizeValidator'
];
```

现在服务将会对所有请求进行有效性验证, 验证失败的请求都会被拒绝
