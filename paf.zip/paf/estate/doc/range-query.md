## 自动化范围查询

### 介绍

自动从url中获取范围查询参数并验证

### 基本用法

在model中设定好 `$rangeable` 数组, 该数组中的值所对应的字段可以进行范围查询

可用的范围条件有:

  * -gt:   >
  * -lt:   <
  * -ge:   >=
  * -le:   <=
  * -eq:   =
  * -ne:   !=
  * -in:   in
  * -ni:   not in
  * -like: like

```php
// QUERY_STRING: ?iAutoID-in=10,12,3,2,1&iVersion-gt=1000
class Foo extends Model
{
	protected $rangeable = ['iAutoID', 'iVersion'];

    public static function foo()
    {
        return self::withRange()->first();
    }
}
```
