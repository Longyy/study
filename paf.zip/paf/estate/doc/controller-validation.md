## 控制器验证

### 介绍

使用方法参考官方文档  
不同于原生的validate方法, 该控制器验证会在验证通过后返回通过验证的参数数组  
你可以直接使用返回的参数数组也可以自己处理具体参数  

### 基本用法

```php
public function store(Request $oRequest)
{
    $aInputs = $this->validate($oRequest, [
        'title' => 'required|unique|max:255',
        'body' => 'required'
    ]);
}
```
