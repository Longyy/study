## 自动化字段提取

### 介绍

自动从url中获取column参数并验证

### 基本用法

1. 在model中设定好 `$columnable` 数组, 该数组中的所有值对应数据库表中的所有字段
2. 在model中使用 `self::columns()` 获取外部column参数

```php
// QUERY_STRING: ?_sColumn=iAutoID,iVersion,iPublish
class Foo extends Model
{
	protected $columnable = ['iAutoID', 'iVersion', 'sKey', 'sVer', 'iOs', 'iPackage',
        'sContent', 'iPublish', 'iStatus', 'iDeleteTime', 'iCreateTime', 'iUpdateTime'];

    public static function foo()
    {
        return self::get(static::columns());
    }
}
```
