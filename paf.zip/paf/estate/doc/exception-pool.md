## 异常池

### 介绍
有时候, 你希望在验证时一次返回尽可能的异常信息(在service层你总是应该在一次响应中返回尽可能多的错误信息)  
比如当你有3个变量需要验证时, 应当验证完3个变量后再统一抛出异常, 而不是每次请求只报告第一个错误的地方  
异常池就是为了满足这种场景而创建的

### 基本用法

```php
use ExceptionPool; // 引入异常池
use ValidateException; // 引入验证异常

// iVarA错啦!
$iVarA = 'a';
if (!is_int($iVarA)) {
    ExceptionPool::add(new ValidateException('iVarA', $iVarA, 'INVALID_TYPE', 233, 'integer'));
}

// 天了噜!iVarB也错啦!
$iVarB = 'b';
if (!is_int($iVarB)) {
    ExceptionPool::add(new ValidateException('iVarB', $iVarB, 'INVALID_TYPE', 233, 'integer'));
}

// 验证完了, 记得把异常池倒出去, 这边将会抛出一个ExceptionPool异常, 然后顶层会自动捕获并进行处理
ExceptionPool::pour();

```

> **注意: 请务必记得在合适的地方倾倒异常池, 忘记倾倒可能导致脏数据侵入**  
> **注意: 请务必记得在合适的地方倾倒异常池, 忘记倾倒可能导致脏数据侵入**  
> **注意: 请务必记得在合适的地方倾倒异常池, 忘记倾倒可能导致脏数据侵入**  

因为很重要所以说三遍
