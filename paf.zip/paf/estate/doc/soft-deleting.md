## 软删除

### 介绍

基于iStatus的软删除实现, 禁用了restore()软删除恢复方法, 其他方法使用同官方文档

### 基本用法

```php
Loupan::where('iAutoID', 1)->delete(); // 删除ID为1的楼盘, 执行后iStatus为0
```