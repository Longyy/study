## 缓存键生成方法

### 介绍

通用方法生成缓存key

### 基本用法

```php
CacheKey::groupOne($nameOne, $aParams);
CacheKey::groupTwo($nameTwo, $aParams);
```
