## 日志服务接入

### 介绍

将日志记录统一发送到日志服务

### 基本用法

在config/services.php中新增

```php
'log' => [
    'enable' => true, // 是否启用
    'url'  => 'log-service', // 日志服务地址
    'from' => 'repository-name', // 当前仓库名
    'level' => \Monolog\Logger::DEBUG, // 日志记录级别(≥)
],
```
