## 分页

### 介绍

根据总数和每页大小生成分页数据结构

### 基本用法

引入Paginator

```php
use Estate\Pagination\Paginator;
```

自动获取当前页

```php
(new Paginator([], $iTotal, $iPerPage, null, ['path' => $oRequest->url()]))
    ->appends($oRequest->all())
    ->toArray();
```

强制设定当前页

```php
(new Paginator([], $iTotal, $iPerPage, $iCurrentPage, ['path' => $oRequest->url()]))
    ->appends($oRequest->all())
    ->toArray();
```

自定义分页url风格

```php
// 生成类似 `/pg1-st2` 风格的url
// $aParams = ['st' => '1', 'pg' => '2'];

Paginator::pageUrlResolver(function ($aParams) {
    array_walk($aParams, function (&$sValue, $sKey) {
        return $sValue = "{$sKey}{$sValue}";
    });
    return join('-', $aParams);
});
(new Paginator([], $iTotal, $iPerPage, $iCurrentPage, ['path' => $oRequest->url()]))
    ->setPageName('pg')
    ->appends($aParams)
    ->toArray();
```
