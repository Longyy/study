## 基类数据模型

### 介绍

1. 继承自Illuminate\Database\Eloquent\Model, 因此可以使用任何框架原生方法  
2. 内置了基于iStatus的软删除实现  
3. 初始主键默认为iAutoID, 创建时间字段为iCreateTime, 更新时间字段为iUpdateTime, 需要修改为其他值的情况请参考官方文档中的修改方法  
4. 默认使用整形时间戳保存  
5. 软删除操作和官方文档中完全相同, 但禁用了restore()操作

### 基本用法

```php
// use Illuminate\Database\Eloquent\Model; 修改为
use Estate\Database\Eloquent\Model;

class Loupan extends Model {

    protected $connection = 'loupan_db'; // 需要使用的数据库连接

    protected $table = 't_loupan'; // 对应的表名

    // 其他属性请参考laravel官方文档
}
```