## 内部接口通用访问器

### 介绍

访问器提供一种通用的方式来访问内部接口, 无论接口提供方给出的是一个SDK还是RPC或者其他  
显而易见的好处是业务本身和接口提供方的代码完全解耦  
即使一个使用SDK的接口修改为RPC调用或者反之, 都可以在不修改任何业务代码的情况下进行替换

![通用访问器类图](http://ww1.sinaimg.cn/large/6ca13d2cgw1ervyjwdxh3j20pa0m6aco.jpg)

### 基本用法

以VerifyManageSDK为例  

#### 引入SDK文件
先将VerifyManageSDK放到合适的位置, 比如app/Services/SDK/  
然后在composer.json中新增   

```json
"autoload": {
    "files": [
        "app/Services/SDK/VerifyManageSDK.php"
    ]
}
```

执行composer dumpautoload使上面的配置生效

#### 实现调用SDK的方法

首先需要为VerifyManageSDK实现Estate\Contracts\Accessors\ServiceAccessor接口

```php
namespace App\Services\SDK;

use Estate\Contracts\Accessors\ServiceAccessor;
use EstateException;

class VerifyServiceAccessor implements ServiceAccessor
{
    
    public $oVerifySdk;

    public function __construct()
    {
        $this->oVerifySdk = new \VerifyManageSDK;

        $this->oVerifySdk->setFrom('xf-web');
        $this->oVerifySdk->setDomain(hf_url('verify-service'));
        $this->oVerifySdk->setKey(config('services.verify-service.key'));
        $this->oVerifySdk->setTrackId(app('trackId')->get());
    }

    // ServiceAccessor需要实现6个方法

    // 执行一个请求
    public function request($sName, array $aParams)
    {
        switch ($sName) {
            case 'getBaseVerifyList':
                return call_user_func_array([$this->oVerifySdk, 'getBaseVerifyList'], $aParams);
            default:
                break;
        }
    }

    public function isSuccess($mResponse)
    {
        return isset($mResponse['bSuccess']) && $mResponse['bSuccess'] === true;
    }

    public function getData($mResponse)
    {
        return $mResponse['aData'];
    }

    public function getError($mResponse)
    {
        return isset($mResponse['aErrors']) ? $mResponse['aErrors'] : '';
    }

    public function errorHandler($mError, &$mData = null)
    {
        // 处理错误, 这边可以进行一些善后工作, 然后抛出你的异常; 如果这里不抛出异常, 系统会为自动你抛出一个默认的异常

        // 第二个参数为一个引用, 当你在最后返回true时, 第二个参数的值会被作为接口的返回传出, 此时系统不会抛出异常而是以$mData作为正确返回继续执行下去
        // throw new ServiceException('msg', $iCode);
    }

    public function __clone()
    {
        $this->oVerifySdk = clone $this->oVerifySdk;
    }
```

#### 将你的访问器放入容器

```php
public function register()
{
	$this->app->singleton('service.accessor.verify-service', function($oApp)
	{
		// 创建通用访问器
		return \Estate\Support\Accessors\AccessorFactory::make(new \App\Services\SDK\VerifyServiceAccessor());
	});
}
```

#### 为你的通用访问器设定一个别名

```php
// app/Facades/Services/VerifyServiceFacade.php
namespace App\Facades\Services;

use Illuminate\Support\Facades\Facade;

class VerifyServiceFacade extends Facade
{
    protected static function getFacadeAccessor() { return 'service.accessor.verify-service'; }
}



// config/app.php
return [
	'aliases' => [
		'VerifyService'   => 'App\Facades\Services\VerifyServiceFacade',
	]
];
```

接入完成!  

现在你就可以在任何地方使用通用访问器了, 并且这边的方法是通用的无论你是SDK还是RPC还是其他  
甚至当你现在正在将一个RPC改成一个SDK时, 你也只需要修改XfServiceAccessor的实现, 而不用改变任何业务代码

```php
// 调用一个接口
VerifyService::getBaseVerifyList();

// 在这次请求时使用一些特殊配置
VerifyService::touch(function ($oXfServiceAccessor) {
    $oXfServiceAccessor->oVerifySdk->setFrom('web-xf');
    return $oXfServiceAccessor;
})->getBaseVerifyList();

// 在这次请求失败时希望用一个默认值作为结果让代码继续运行下去
VerifyService::setErrorHandler(function ($mError, &$mData) {
    $mData = [
        'aList' => []
    ];
    return true;
})->getBaseVerifyList();

// 当然也可以将上面两种情况合起来使用
VerifyService::touch(function ($oXfServiceAccessor) {
    $oXfServiceAccessor->oVerifySdk->setFrom('web-xf');
    return $oXfServiceAccessor;
})->setErrorHandler(function ($mError, &$mData) {
    $mData = [
        'aList' => []
    ];
    return true;
})->getBaseVerifyList();
```

在上面的调用中, 显而易见可能出现两个问题:
  1. touch方法中接触了$oVerifySdk, 当SDK发生变化时你不能保证SDK中依然有你在touch中访问的方法, 比如上面例子中的setFrom方法
  2. 当SDK发生变化时, 通用访问器的方法可能不再适用, 比如getBaseVerifyList变成了getBaseVerifyList2, 此时业务中所有用了getBaseVerifyList的地方都会出问题

对于问题一, 你应该尽可能的不去使用touch, 实际上正常情况下也没有必要在运行时去动态的改变一些初始化参数, touch在这边只是提供一种应急方法  
对于问题二, 你应该如例子中VerifyServiceAccessor那样设定你需要调用接口的别名, 然后就可以只修改VerifyServiceAccessor中的别名而不需要修改业务代码, 另一个好处是在这边记录了所有用到了的接口, 方便日后统计查看

别名的另一种实现

```php
class VerifyServiceAccessor implements ServiceAccessor
{
	public function request($sName, array $aParams)
	{
		return $this->$sName($aParams);
	}

	public function getBaseVerifyList($aParams)
	{
		return $this->oVerifySdk->getBaseVerifyList($aParams);
		// return $this->oVerifySdk->getBaseVerifyList2($aParams);
	}

	...
}
```

总之, 通用访问器的目的就是对接口提供方的接口请求实现和我们自身的业务逻辑进行解耦  
最后产生耦合的地方应该全部在ServiceAccessor内
