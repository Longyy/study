## 追踪ID生成服务

### 介绍

为每次请求生成一个唯一的追踪ID

### 基本用法

获取本次请求的追踪ID

```php
$sTrackId = app('request.client')->getTrackID();
```
