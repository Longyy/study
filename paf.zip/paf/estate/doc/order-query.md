## 自动化排序

### 介绍

自动从url中获取查询顺序并验证

### 基本用法

在model中设定好 `$orderable` 数组, 该数组中的值所对应的字段可以进行排序  
字段前加 `-` 进行倒序排序



```php
// QUERY_STRING: ?_sOrder=-iVersion,iAutoID
class Foo extends Model
{
	protected $orderable = ['iAutoID', 'iVersion'];

    public static function foo()
    {
        return self::withOrder()->first();
    }
}
```
