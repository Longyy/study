## url生成

### 介绍

生成url

### 基本用法

```php
// 配置config/domain.php
return [
    'static' => env('DOMAIN_STATIC'),
];

// 使用
hf_url('static', '/css//////style.css/', ['timestamp' => time()]); // http://static.anhouse.cn/css/style.css?timestamp=1435823723
```
