## 响应宏服务

### 介绍

响应宏提供了几种格式化的输出格式

### 基本用法

```php
use Loupan;
use Response;

public function index()
{
    // 使用详细格式的内部API接口返回一个楼盘的详细信息
    $oLoupan = Loupan::find(1);
    return Response::detailApi($oLoupan);

    // 使用列表的内部API接口返回一组楼盘的列表
    $oLoupans = Loupan::paginate(10);
    return Response::listApi($oLoupans);
}
```
