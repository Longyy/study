## 服务层异常

### 介绍

在服务层发现错误导致逻辑无法继续进行时抛出服务层异常

### 基本用法

```php
use ServiceException; // 引入服务层异常

throw new ServiceException('msg', $iCode);

```
