## 异常码

### 介绍

提供一种统一的方式去管理异常码

### 基本用法

在resource/lang/zh-cn/exceptions.php中, 定义一个以异常名为key的数组, 然后添加该异常对应的异常码

```php
// resource/lang/zh-cn/exceptions.php
return [
    'Estate\Exceptions\ServiceException'  => [
        'APP_EXISTS'    => ['对不起，该版本已经被添加了', '30001'],
        'APP_NOT_FOUND' => ['应用包不存在', '30002'],
    ],
];

// BalabalaController.php
use Estate\Exceptions\ServiceException;

class BalabalaController extends Controller
{
    if (isFailed()) {
        throw new ServiceException('APP_EXISTS');
    }
}

```
