## 自定义异常

### 介绍

你也可以自定义各种不同含义的异常  
只要实现 `Estate\Contracts\Exceptions\WebException` 或 `Estate\Contracts\Exceptions\ServiceException` 接口, 取决于你在应用层还是服务层  
无论哪个接口都没有声明方法, 这意味着你不需要实现任何方法, 只要简单的声明你的异常实现了这个接口  

![异常类图](http://ww4.sinaimg.cn/large/6ca13d2cgw1ervyjwxvq5j20ps0cvjsr.jpg)

### 基本用法

```php
// 以ServiceException的实现为例

use Estate\Contracts\Exceptions\ServiceException as ServiceExceptionContract;
use Exception;

class ServiceException extends Exception implements ServiceExceptionContract
{
}

```

> **注意: 无论如何必须实现 `Estate\Contracts\Exceptions\WebException` 或 `Estate\Contracts\Exceptions\ServiceException` 接口**  
> 否则该异常将会被作为系统异常捕获并报告, 你不会希望运维和测试拿着一大坨错误日志来找你
