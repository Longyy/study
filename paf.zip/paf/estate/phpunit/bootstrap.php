<?php

require(getenv('PATH_VENDOR') . '/laravel/v5.0.14/vendor/autoload.php');
require __DIR__.'/../../../autoload.php';
