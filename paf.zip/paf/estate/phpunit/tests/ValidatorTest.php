<?php

class ValidatorTest extends TestCase
{
    public function testUint32()
    {
        $oValidator = Validator::make(
            [
                'uint32'    => 4294967295,
                'uint32-gt' => 4294967296,
                'uint32-lt' => -1,
            ],
            [
                'uint32'    => 'uint32',
                'uint32-gt' => 'uint32',
                'uint32-lt' => 'uint32',
            ],
            [
                'uint32.uint32'    => 'OUT_OF_RANGE',
                'uint32-gt.uint32' => 'OUT_OF_RANGE',
                'uint32-lt.uint32' => 'OUT_OF_RANGE',
            ]
        );
        $this->assertEquals('', $oValidator->messages()->first('uint32'));
        $this->assertEquals('OUT_OF_RANGE', $oValidator->messages()->first('uint32-gt'));
        $this->assertEquals('OUT_OF_RANGE', $oValidator->messages()->first('uint32-lt'));
    }

    public function testInt32()
    {
        $oValidator = Validator::make(
            [
                'int32'    => 2147493647,
                'int32-gt' => 2147493648,
                'int32-lt' => -2147493649,
            ],
            [
                'int32'    => 'int32',
                'int32-gt' => 'int32',
                'int32-lt' => 'int32',
            ],
            [
                'int32.int32'    => 'ERROR',
                'int32-gt.int32' => 'ERROR',
                'int32-lt.int32' => 'ERROR',
            ]
        );
        $this->assertEquals('', $oValidator->messages()->first('int32'));
        $this->assertEquals('ERROR', $oValidator->messages()->first('int32-gt'));
        $this->assertEquals('ERROR', $oValidator->messages()->first('int32-lt'));
    }

    public function testIdCard()
    {
        $oValidator = Validator::make(
            [
                'idCard'       => '230103196007175511',
                'idCard15'     => '000000000000000',
                'idCard-withX' => '53010219690719072X',
                'idCard1'      => '230103999907175511',
                'idCard2'      => 'asdfasdfasdfas',
            ],
            [
                'idCard'       => 'id_card',
                'idCard15'     => 'id_card',
                'idCard-withX' => 'id_card',
                'idCard1'      => 'id_card',
                'idCard2'      => 'id_card',
            ],
            [
                'idCard.id_card'       => 'ERROR',
                'idCard15.id_card'     => 'ERROR',
                'idCard-withX.id_card' => 'ERROR',
                'idCard1.id_card'      => 'ERROR',
                'idCard2.id_card'      => 'ERROR',
            ]
        );
        $this->assertEquals('', $oValidator->messages()->first('idCard'));
        $this->assertEquals('', $oValidator->messages()->first('idCard15'));
        $this->assertEquals('', $oValidator->messages()->first('idCard-withX'));
        $this->assertEquals('ERROR', $oValidator->messages()->first('idCard1'));
        $this->assertEquals('ERROR', $oValidator->messages()->first('idCard2'));
    }

    public function testMobile()
    {
        $oValidator = Validator::make(
            [
                'mobile'  => '13800138000',
                'mobile1' => '10000000000',
                'mobile2' => 'mobile2',
            ],
            [
                'mobile'  => 'mobile',
                'mobile1' => 'mobile',
                'mobile2' => 'mobile',
            ],
            [
                'mobile.mobile'  => 'ERROR',
                'mobile1.mobile' => 'ERROR',
                'mobile2.mobile' => 'ERROR',
            ]
        );
        $this->assertEquals('', $oValidator->messages()->first('mobile'));
        $this->assertEquals('ERROR', $oValidator->messages()->first('mobile1'));
        $this->assertEquals('ERROR', $oValidator->messages()->first('mobile2'));
    }

    public function testPhone()
    {
        $oValidator = Validator::make(
            [
                'phone'  => '021-0000000',
                'phone1' => '02100000000',
                'phone2' => '1234567',
                'phone3' => '12345678',
                'phone4' => 'phone4',
            ],
            [
                'phone'  => 'phone',
                'phone1' => 'phone',
                'phone2' => 'phone',
                'phone3' => 'phone',
                'phone4' => 'phone',
            ],
            [
                'phone.phone'  => 'ERROR',
                'phone1.phone' => 'ERROR',
                'phone2.phone' => 'ERROR',
                'phone3.phone' => 'ERROR',
                'phone4.phone' => 'ERROR',
            ]
        );
        $this->assertEquals('', $oValidator->messages()->first('phone'));
        $this->assertEquals('', $oValidator->messages()->first('phone1'));
        $this->assertEquals('', $oValidator->messages()->first('phone2'));
        $this->assertEquals('', $oValidator->messages()->first('phone3'));
        $this->assertEquals('ERROR', $oValidator->messages()->first('phone4'));
    }

    public function testChinese()
    {
        $oValidator = Validator::make(
            [
                'chinese'  => '在地下城寻求邂逅是否搞错了什么',
                'chinese1' => 'ダンジョンに出会いを求めるのは間違っているだろうか',
                'chinese2' => '✨',
                'chinese3' => '。',
                'chinese4' => 'English',
            ],
            [
                'chinese'  => 'chinese',
                'chinese1' => 'chinese',
                'chinese2' => 'chinese',
                'chinese3' => 'chinese',
                'chinese4' => 'chinese',
            ],
            [
                'chinese.chinese'  => 'ERROR',
                'chinese1.chinese' => 'ERROR',
                'chinese2.chinese' => 'ERROR',
                'chinese3.chinese' => 'ERROR',
                'chinese4.chinese' => 'ERROR',
            ]
        );
        $this->assertEquals('', $oValidator->messages()->first('chinese'));
        $this->assertEquals('ERROR', $oValidator->messages()->first('chinese1'));
        $this->assertEquals('ERROR', $oValidator->messages()->first('chinese2'));
        $this->assertEquals('ERROR', $oValidator->messages()->first('chinese3'));
        $this->assertEquals('ERROR', $oValidator->messages()->first('chinese4'));
    }
}
