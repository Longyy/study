<?php

namespace Estate\Facades\Authorize;
use Illuminate\Support\Facades\Facade;

class ServiceConfig extends Facade {

    /**
     * 获取外观服务器通信密钥
     *
     * @author Sinute
     * @date   2015-04-18
     * @return string
     */
    protected static function getFacadeAccessor() { return 'auth.service.config'; }

}
