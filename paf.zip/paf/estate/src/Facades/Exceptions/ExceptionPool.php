<?php

namespace Estate\Facades\Exceptions;
use Illuminate\Support\Facades\Facade;

class ExceptionPool extends Facade {

    /**
     * 获取外观访问器
     *
     * @author Sinute
     * @date   2015-04-18
     * @return string
     */
    protected static function getFacadeAccessor() { return 'exception.pool'; }

}
