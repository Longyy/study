<?php
namespace Estate\Validation;

use Estate\Exceptions\ExceptionPool;
use Estate\Exceptions\ValidateException;
use Illuminate\Validation\Validator;

trait ValidationErrors
{
    /**
     * 服务层格式化验证错误信息
     *
     * @author Sinute
     * @date   2015-04-28
     * @param  \Illuminate\Validation\Validator $oValidator 验证类
     * @return array
     */
    protected function formatValidationExceptions(Validator $oValidator)
    {
        $aErrors        = [];
        $aData          = $oValidator->getData();
        $aErrorMessages = $oValidator->messages()->toArray();
        $aRules         = $oValidator->getRules();
        foreach ($aErrorMessages as $sName => $aMessages) {
            $aErrors[] = new ValidateException($sName, array_get($aData, $sName), join("\n", $aMessages), trans("exceptions.Estate\Exceptions\ValidateException.VALIDATE_FAILS.1"), join("|", $aRules[$sName]));
        }
        return $aErrors;
    }

    /**
     * 抛出验证异常池
     * @param  Validator $oValidator 验证类
     * @return void
     */
    protected function throwValidationExceptionPool(Validator $oValidator)
    {
        $aErrors = $this->formatValidationExceptions($oValidator);
        foreach ($aErrors as $oError) {
            ExceptionPool::getInstance()->add($oError);
        }
        ExceptionPool::getInstance()->pour();
    }
}
