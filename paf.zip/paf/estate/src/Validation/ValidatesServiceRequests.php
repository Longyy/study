<?php
namespace Estate\Validation;

use Illuminate\Contracts\Validation\Validator;
use Illuminate\Foundation\Validation\ValidatesRequests;
use Illuminate\Http\Request;

trait ValidatesServiceRequests
{
    use ValidatesRequests, ValidationErrors;

    /**
     * 验证并获取正确数据
     *
     * @author Sinute
     * @date   2015-04-28
     * @param  array   $oRequest     请求
     * @param  array   $aRules       验证规则
     * @param  array   $aMessages    错误信息
     * @param  array   $aAttributes  自定义属性
     * @return array
     */
    public function validate($mRequest, array $aRules, array $aMessages = [], array $aAttributes = [])
    {
        if ($mRequest instanceof Request) {
            $mRequest = $mRequest->all();
        } else {
            $mRequest = (array) $mRequest;
        }
        $validator = $this->getValidationFactory()->make($mRequest, $aRules, $aMessages, $aAttributes);

        if ($validator->fails()) {
            $this->throwValidationException(\Request::instance(), $validator);
        } else {
            return array_filter(array_intersect_key($mRequest, $aRules), function ($mValue) {return !is_null($mValue);});
        }
    }

    /**
     * 抛出验证错误
     *
     * @author Sinute
     * @date   2015-04-28
     * @param  \Illuminate\Http\Request                    $oRequest    请求
     * @param  \Illuminate\Contracts\Validation\Validator  $oValidator  验证类
     * @return void
     */
    protected function throwValidationException(Request $oRequest, Validator $oValidator)
    {
        $this->throwValidationExceptionPool($oValidator);
    }
}
