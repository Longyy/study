<?php

namespace Estate\Contracts\Accessors;

/**
 * 访问器
 *
 * @author Sinute
 * @date   2015-04-16
 */
interface Accessor
{
}
