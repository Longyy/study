<?php

namespace Estate\Contracts\Exceptions;

/**
 * web层异常接口
 *
 * @author Sinute
 * @date   2015-05-03
 */
interface WebException extends Exception
{
}
