<?php

namespace Estate\Contracts\Exceptions;

/**
 * service层异常接口
 *
 * @author Sinute
 * @date   2015-08-24
 */
interface MobiException extends Exception
{
}
