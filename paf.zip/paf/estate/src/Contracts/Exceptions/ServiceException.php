<?php

namespace Estate\Contracts\Exceptions;

/**
 * service层异常接口
 *
 * @author Sinute
 * @date   2015-05-03
 */
interface ServiceException extends Exception
{
}
