<?php

namespace Estate\Contracts\Exceptions;

/**
 * 异常接口
 *
 * @author Sinute
 * @date   2015-04-09
 */
interface Exception
{
}
