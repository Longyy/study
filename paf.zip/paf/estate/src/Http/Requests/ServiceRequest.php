<?php
namespace Estate\Http\Requests;

use Estate\Validation\ValidationErrors;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Validator;

class ServiceRequest extends FormRequest
{
    use ValidationErrors;

    /**
     * 处理失败验证
     *
     * @author Sinute
     * @date   2015-05-04
     * @param  \Illuminate\Validation\Validator  $oValidator 验证类
     * @return void
     */
    protected function failedValidation(Validator $oValidator)
    {
        $this->throwValidationExceptionPool($oValidator);
    }

}
