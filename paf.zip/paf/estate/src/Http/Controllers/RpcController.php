<?php
namespace Estate\Http\Controllers;

use Estate\Exceptions\ServiceException;
use Illuminate\Http\Request;
use Illuminate\Routing\Controller;
use Paf\LightService\Server\Service as LightService;
use ReflectionFunctionAbstract;
use ReflectionMethod;
use Response;

class RpcController extends Controller
{
    protected function resolveClassMethodDependencies(array $aParameters, $oInstance, $sMethod)
    {
        if (!method_exists($oInstance, $sMethod)) {
            return $aParameters;
        }

        return $this->resolveMethodDependencies(
            $aParameters, new ReflectionMethod($oInstance, $sMethod)
        );
    }

    protected function alreadyInParameters($oClass, array $aParameters)
    {
        return !is_null(array_first($aParameters, function ($sKey, $mValue) use ($oClass) {
            return is_object($mValue) && get_class($mValue) === $oClass;
        }));
    }

    protected function resolveMethodDependencies(array $aParameters, ReflectionFunctionAbstract $oReflector)
    {
        foreach ($oReflector->getParameters() as $iIndex => $oParameter) {
            // If the parameter has a type-hinted class, we will check to see if it is already in
            // the list of parameters. If it is we will just skip it as it is probably a model
            // binding and we do not want to mess with those; otherwise, we resolve it here.
            $oClass = $oParameter->getClass();

            if ($oClass && !$this->alreadyInParameters($oClass->name, $aParameters)) {
                // rebuild request with parameters
                if ($oClass->isInstance(\Request::instance())) {
                    $oRequest = app()->make($oClass->name);
                    if (isset($aParameters[$iIndex])) {
                        if (is_array($aParameters[$iIndex])) {
                            foreach ($aParameters[$iIndex] as $sKey => $mValue) {
                                $oRequest[$sKey] = $mValue;
                            }
                        } else {
                            $oRequest[count($oRequest->all())] = $aParameters[$iIndex];
                        }
                    }
                    array_splice(
                        $aParameters, $iIndex, 1, [$oRequest]
                    );
                } else {
                    array_splice(
                        $aParameters, $iIndex, 0, [app()->make($oClass->name)]
                    );
                }
            }
        }

        return $aParameters;
    }

    protected static function checkBlackList($sVersion, $sModule, $sMethod)
    {
        $sRuleKey = strtolower("{$sVersion}:{$sModule}@{$sMethod}");
        // blacklist
        $aList = config("rpc.blacklist", false);
        if ($aList !== false) {
            foreach ($aList as $sBlackVersion => $aBlackMethods) {
                foreach ($aBlackMethods as $sBlackMethod) {
                    if ($sRuleKey === strtolower("{$sBlackVersion}:{$sBlackMethod}")) {
                        // find in blacklist
                        return false;
                    }
                }
            }
        }
        return true;
    }

    protected static function checkWhiteList($sVersion, $sModule, $sMethod)
    {
        $sRuleKey = strtolower("{$sVersion}:{$sModule}@{$sMethod}");
        // whitelist
        $aList = config("rpc.whitelist", false);
        if ($aList !== false) {
            $bInWhitelist = false;
            foreach ($aList as $sWhiteVersion => $aWhiteMethods) {
                foreach ($aWhiteMethods as $sWhiteMethod) {
                    if ($sRuleKey === strtolower("{$sWhiteVersion}:{$sWhiteMethod}")) {
                        // find in whitelist
                        $bInWhitelist = true;
                        break 2;
                    }
                }
            }
            if (!$bInWhitelist) {
                return false;
            }
        }
        return true;
    }

    public function server()
    {
        \Estate\Http\Middleware\RequestResponseLogger::logRequest();
        return Response::make(
            LightService::create(
                'jsonrpc',
                function ($sModule, $sMethod, $aParams) {
                    try {
                        // 验证内网IP
                        if (!app('auth.service.ip')->check($_SERVER['REMOTE_ADDR'])) {
                            app('syslog')->info('AUTH_IP_NOT_ALLOWED', [
                                'sRemoteAddress'  => $_SERVER['REMOTE_ADDR'],
                                'aAllowedAddress' => app('auth.service.ip')->get(),
                            ]);
                            throw new \Estate\Exceptions\ServiceException("UNAUTHORIZED");
                        }

                        $sTrackID     = array_get($aParams, '0.trackId', null);
                        $sFrom        = array_get($aParams, '0.from', null);
                        $iRequestTime = array_get($aParams, '0.requestTime', null);
                        $sToken       = array_get($aParams, '0.token', null);
                        // 验证校验字段
                        $aRpcRequest = array_get($aParams, '1', []);
                        if (
                            !\Estate\Http\Middleware\AuthorizeValidator::check(
                                $aRpcRequest,
                                $sTrackID,
                                $sFrom,
                                $iRequestTime,
                                $sToken
                            )
                        ) {
                            throw new \Estate\Exceptions\ServiceException("UNAUTHORIZED");
                        }

                        app('request.client')->setClientTrackID($sTrackID);
                        app('request.client')->setFrom($sFrom);
                        app('request.client')->setRequestTime($iRequestTime);
                        app('request.client')->setToken($sToken);

                        $sVersion = str_replace('.', '_', array_get($aParams, '0.version', ''));

                        // alias
                        if ($sRoute = config("rpc.server.{$sVersion}.{$sModule}.{$sMethod}", null)) {
                            // get real module, method
                            list($sModule, $sMethod) = explode('@', $sRoute);
                        }

                        if (!self::checkBlackList($sVersion, $sModule, $sMethod) || !self::checkWhiteList($sVersion, $sModule, $sMethod)) {
                            throw new \Estate\Exceptions\ServiceException("NOT_ALLOWED_METHOD");
                        }

                        $sClass = config('rpc.namespace', 'App\\Http\\Controllers') . "\\V{$sVersion}\\{$sModule}";

                        foreach (\Request::all() as $sKey => $_) {
                            unset(\Request::instance()[$sKey]);
                        }

                        $aParameters = $this->resolveClassMethodDependencies(
                            $aRpcRequest,
                            $sClass,
                            $sMethod
                        );

                        $oResponse = call_user_func_array([new $sClass, $sMethod], $aParameters);
                        \Estate\Http\Middleware\RequestResponseLogger::logResponse($oResponse);

                        return new \Paf\LightService\Server\Response($oResponse->getData());
                    } catch (\Estate\Contracts\Exceptions\Exception $oException) {
                        // use exceptionApi to response custom exception
                        return new \Paf\LightService\Server\Response(response()->exceptionApi($oException, 200)->getData());
                    } catch (\Exception $oException) {
                        // log exception
                        app('syslog')->info((string) $oException);
                        error_log((string) $oException);
                        // throw system exception to rpc
                        throw $oException;
                    }
                }
            )->respond(\Request::getContent())
        )->header('Content-Type', 'application/json');
    }
}
