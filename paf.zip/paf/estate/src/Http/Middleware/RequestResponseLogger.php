<?php
namespace Estate\Http\Middleware;

use Closure;
use \Symfony\Component\HttpFoundation\Response;
use Illuminate\View\View;

/**
 * 请求响应日志中间件
 */
class RequestResponseLogger
{
    protected static $bEnable = true;

    public static function disable()
    {
        static::$bEnable = false;
    }

    public static function enable()
    {
        static::$bEnable = true;
    }

    /**
     * 记录请求日志
     *
     * @author Sinute
     * @date   2015-04-18
     * @param  \Symfony\Component\HttpFoundation\Request     $oRequest 请求
     * @param  Closure    $oNext    下一个调度
     * @return \Symfony\Component\HttpFoundation\Response
     */
    public function handle($oRequest, Closure $oNext)
    {
        self::logRequest();
        $oResponse = $oNext($oRequest);
        self::logResponse($oResponse);
        return $oResponse;
    }

    public static function logRequest(\Symfony\Component\HttpFoundation\Request $oRequest = null)
    {
        if (!static::$bEnable) {
            return;
        }
        if (!$oRequest) {
            $oRequest = \Request::instance();
        }
        app('syslog')->info(
            "request",
            [
                'method'    => $oRequest->method(),
                'url'       => $oRequest->url(),
                'path'      => $oRequest->path(),
                'query'     => $oRequest->query(),
                'ajax'      => $oRequest->ajax(),
                'pjax'      => $oRequest->pjax(),
                'secure'    => $oRequest->secure(),
                'ip'        => $oRequest->ip(),
                'ips'       => $oRequest->ips(),
                'userAgent' => $oRequest->header('user-agent', ''),
                'request'   => $oRequest->all(),
            ]
        );
    }

    public static function logResponse(Response $oResponse)
    {
        if (!static::$bEnable) {
            return;
        }
        if ($oResponse instanceof \Illuminate\Http\Response && $oResponse->getOriginalContent() instanceof View) {
            $aContent = $oResponse->getOriginalContent()->getData();
        } else {
            $aContent = $oResponse->getContent();
        }
        app('syslog')->info(
            "response",
            [
                'status'   => $oResponse->getStatusCode(),
                'response' => $aContent,
            ]
        );
    }
}
