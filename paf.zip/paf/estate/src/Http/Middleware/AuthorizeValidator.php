<?php

namespace Estate\Http\Middleware;

use Cache;
use Closure;
use Estate\Exceptions\ServiceException;

/**
 * 授权验证
 */
class AuthorizeValidator
{
    /**
     * 授权验证
     *
     * @author Sinute
     * @date   2015-09-06
     * @param  \Symfony\Component\HttpFoundation\Request     $oRequest 请求
     * @param  Closure    $oNext    下一个调度
     * @return \Symfony\Component\HttpFoundation\Response
     */
    public function handle($oRequest, Closure $oNext)
    {
        $sTrackID     = app('request.client')->getTrackID();
        $sFrom        = array_get($oRequest, '_from', null);
        $iRequestTime = array_get($oRequest, '_requesttime', null);
        $sToken       = array_get($oRequest, '_token', null);
        // to clear all system params
        $sMethod = $oRequest->getMethod();
        $oRequest->setMethod('POST');
        unset($oRequest['_from'], $oRequest['_requesttime'], $oRequest['_token']);
        $oRequest->setMethod('GET');
        unset($oRequest['_from'], $oRequest['_requesttime'], $oRequest['_token']);
        $oRequest->setMethod($sMethod);

        if (
            !self::check(
                $oRequest->all(),
                $sTrackID,
                $sFrom,
                $iRequestTime,
                $sToken
            )
        ) {
            throw new ServiceException("UNAUTHORIZED", 500);
        }

        app('request.client')->setFrom($sFrom);
        app('request.client')->setRequestTime($iRequestTime);
        app('request.client')->setToken($sToken);

        return $oNext($oRequest);
    }

    public static function check($aParameters, $sTrackID, $sFrom, $iRequestTime, $sToken)
    {
        // 授权验证打开
        if (app()['auth.service.config']->authEnabled()) {
            return static::checkParams($sFrom, $iRequestTime, $sTrackID, $sToken) &&
            static::checkRequestTime($sFrom, $iRequestTime) &&
            static::checkIp($sFrom) &&
            static::checkLimit($sFrom) &&
            static::checkToken($sToken, $aParameters, $sFrom, $iRequestTime);
        }
        return true;
    }

    protected static function checkParams($sFrom, $iRequestTime, $sTrackID, $sToken)
    {
        if (
            !$sFrom || // 来源
            !$iRequestTime || // 请求时间
            !$sTrackID || // 追踪ID
            !$sToken // Token
        ) {
            app('syslog')->info('AUTH_PARAMS_INCOMPLETE', compact('sTrackID', 'sFrom', 'iRequestTime', 'sToken'));
            return false;
        }
        return true;
    }

    protected static function checkRequestTime($sFrom, $iRequestTime)
    {
        // 验证请求时间
        if (abs($iRequestTime - LARAVEL_START) > app()['auth.service.config']->get("{$sFrom}.time_difference", 60)) {
            app('syslog')->info('AUTH_TIMEOUT', [
                'iRequestTime'       => $iRequestTime,
                'iReceivedTime'      => LARAVEL_START,
                'iMaxTimeDifference' => app()['auth.service.config']->get("{$sFrom}.time_difference", 60),
            ]);
            return false;
        }
        return true;
    }

    protected static function checkIp($sFrom)
    {
        // ip
        if ($mAllowedIp = app()['auth.service.config']->get("{$sFrom}.ip")) {
            $sIp = \Request::instance()->ip();
            if (is_string($mAllowedIp) && str_is($mAllowedIp, $sIp)) {
                return true;
            } elseif (is_array($mAllowedIp)) {
                foreach ($mAllowedIp as $sAllowedIp) {
                    if (str_is($sAllowedIp, $sIp)) {
                        return true;
                    }
                }
            }
            app('syslog')->info('AUTH_IP_NOT_ALLOWED', [
                'aAllowedIps' => is_array($mAllowedIp) ? $mAllowedIp : [$mAllowedIp],
                'sRequestIp'  => $sIp,
            ]);
            return false;
        }
        return true;
    }

    protected static function checkLimit($sFrom)
    {
        // 频率
        if ($sLimit = app()['auth.service.config']->get("{$sFrom}.limit")) {
            $aLimit = explode('/', $sLimit);
            $aUnit  = [
                'min'    => 1,
                'minute' => 1,
                'hour'   => 60,
                'day'    => 60 * 24,
                'week'   => 60 * 24 * 7,
                'month'  => 60 * 24 * 30,
            ];
            $iLimit = array_get($aLimit, 0, 0);
            $iCycle = array_get($aUnit, array_get($aLimit, 1), false);
            $iTimes = null;
            if ($iLimit > 0 && $iCycle > 0) {
                $sCacheKey = "AUTHORIZE:LIMIT:{$sFrom}";
                if (!Cache::has($sCacheKey)) {
                    Cache::put($sCacheKey, 1, $iCycle);
                    return true;
                } elseif (($iTimes = Cache::increment($sCacheKey)) <= $iLimit) {
                    return true;
                }
            }
            app('syslog')->info('OUT_OF_RATE_LIMIT', compact('iTimes', 'iLimit', 'iCycle'));
            return false;
        }
        return true;
    }

    protected static function checkToken($sToken, $aParameters, $sFrom, $iRequestTime)
    {
        if (!($sKey = app()['auth.service.config']->get("{$sFrom}.key"))) {
            app('syslog')->info('AUTH_KEY_NOT_FOUND', compact('sFrom'));
            return false;
        }
        // 验证token
        if (!app()['auth.service.token']->check($sToken, $aParameters, $iRequestTime, $sKey)) {
            $sCorrectToken = app()['auth.service.token']->generate($aParameters, $iRequestTime, $sKey);
            app('syslog')->info('AUTH_TOKEN_ERROR', compact('aParameters', 'sFrom', 'sKey', 'iRequestTime', 'sToken', 'sCorrectToken'));
            return false;
        }
        return true;
    }
}
