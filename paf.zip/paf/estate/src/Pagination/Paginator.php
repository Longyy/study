<?php
namespace Estate\Pagination;

use ArrayAccess;
use Closure;
use Countable;
use Illuminate\Contracts\Pagination\Paginator as PaginatorContract;
use Illuminate\Contracts\Pagination\Presenter;
use Illuminate\Contracts\Support\Arrayable;
use Illuminate\Contracts\Support\Jsonable;
use Illuminate\Pagination\AbstractPaginator;
use Illuminate\Support\Collection;
use IteratorAggregate;

class Paginator extends AbstractPaginator implements Arrayable, ArrayAccess, Countable, IteratorAggregate, Jsonable, PaginatorContract
{
    protected $firstPageUrl;
    protected $lastPageUrl;
    protected $prevPageUrl;
    protected $nextPageUrl;
    protected $pagesUrl;
    protected $displayNum;

    /**
     * The page url resolver callback.
     *
     * @var \Closure
     */
    protected static $pageUrlResolver;

    /**
     * The total number of items before slicing.
     *
     * @var int
     */
    protected $total;

    /**
     * The last available page.
     *
     * @var int
     */
    protected $lastPage;

    /**
     * Create a new paginator instance.
     *
     * @param  mixed  $items
     * @param  int  $total
     * @param  int  $perPage
     * @param  int|null  $currentPage
     * @param  array  $options (path, query, fragment, pageName)
     * @return void
     */
    public function __construct($items, $total, $perPage, $currentPage = null, array $options = [])
    {
        foreach ($options as $key => $value) {
            $this->{$key} = $value;
        }

        $this->total       = $total;
        $this->perPage     = $perPage;
        $this->lastPage    = (int) ceil($total / $perPage);
        $this->currentPage = $this->setCurrentPage($currentPage, $this->lastPage);
        $this->path        = $this->path != '/' ? rtrim($this->path, '/') : $this->path;
        $this->items       = $items instanceof Collection ? $items : Collection::make($items);
    }

    /**
     * Get a URL for a given page number.
     *
     * @param  int  $page
     * @return string
     */
    public function url($page)
    {
        if ($page <= 0) {
            $page = 1;
        }

        if (isset($this->pagesUrl[$page])) {
            return $this->pagesUrl[$page];
        }

        // If we have any extra query string key / value pairs that need to be added
        // onto the URL, we will put them in query string form and then attach it
        // to the URL. This allows for extra information like sortings storage.
        $parameters = [$this->pageName => $page];

        if (count($this->query) > 0) {
            $parameters = array_merge($this->query, $parameters);
        }

        return $this->resolvePageUrl($parameters);
    }

    public static function pageUrlResolver(Closure $resolver)
    {
        static::$pageUrlResolver = $resolver;
    }

    /**
     * Resolve the page url or return the default value.
     *
     * @param  int  $default
     * @return int
     */
    protected function resolvePageUrl($parameters = [])
    {
        if (isset(static::$pageUrlResolver)) {
            return call_user_func(static::$pageUrlResolver, $parameters);
        }

        return $this->path . '?'
        . http_build_query($parameters, null, '&')
        . $this->buildFragment();
    }

    /**
     * Get the current page for the request.
     *
     * @param  int  $currentPage
     * @param  int  $lastPage
     * @return int
     */
    protected function setCurrentPage($currentPage, $lastPage)
    {
        $currentPage = $currentPage ?: static::resolveCurrentPage();

        // The page number will get validated and adjusted if it either less than one
        // or greater than the last page available based on the count of the given
        // items array. If it's greater than the last, we'll give back the last.
        if (is_numeric($currentPage) && $currentPage > $lastPage) {
            return $lastPage > 0 ? $lastPage : 1;
        }

        return $this->isValidPageNumber($currentPage) ? (int) $currentPage : 1;
    }

    /**
     * Get the URL for the next page.
     *
     * @return string
     */
    public function nextPageUrl()
    {
        if ($this->lastPage() > $this->currentPage()) {
            if ($this->nextPageUrl) {
                return $this->nextPageUrl;
            } else {
                return $this->url($this->currentPage() + 1);
            }
        }
    }

    /**
     * Get the URL for the next page.
     *
     * @return string
     */
    public function previousPageUrl()
    {
        if ($this->currentPage() > 1) {
            if ($this->prevPageUrl) {
                return $this->prevPageUrl;
            } else {
                return $this->url($this->currentPage() - 1);
            }
        }
    }

    /**
     * Determine if there are more items in the data source.
     *
     * @return bool
     */
    public function hasMorePages()
    {
        return $this->currentPage() < $this->lastPage();
    }

    /**
     * Get the total number of items being paginated.
     *
     * @return int
     */
    public function total()
    {
        return $this->total;
    }

    /**
     * Get the last page.
     *
     * @return int
     */
    public function lastPage()
    {
        return $this->lastPage;
    }

    /**
     * Convert the object to its JSON representation.
     *
     * @param  int  $options
     * @return string
     */
    public function toJson($options = 0)
    {
        return json_encode($this->toArray(), $options);
    }

    /**
     * Render the paginator using the given presenter.
     *
     * @param  \Illuminate\Contracts\Pagination\Presenter|null  $presenter
     * @return string
     */
    public function render(Presenter $presenter = null)
    {
        // Paginator doesn't render html currently
        return '';
    }

    /**
     * Get the instance as an array.
     *
     * @return array
     */
    public function toArray()
    {
        return [
            'sFirstPageUrl' => $this->firstPageUrl(),
            'sLastPageUrl'  => $this->lastPageUrl(),
            'sPrevPageUrl'  => $this->previousPageUrl(),
            'sNextPageUrl'  => $this->nextPageUrl(),
            'aPagesUrl'     => $this->pagesUrl(),
            'iTotalNum'     => $this->total(),
            'iTotalPage'    => $this->lastPage(),
            'iCurrentPage'  => $this->currentPage(),
            'iPerPage'      => $this->perPage(),
        ];
    }

    /**
     * get first page url
     *
     * @author Sinute
     * @date   2015-09-15
     * @return string
     */
    public function firstPageUrl()
    {
        if ($this->currentPage() != 1) {
            if ($this->firstPageUrl) {
                return $this->firstPageUrl;
            } else {
                return $this->url(1);
            }
        }
    }

    /**
     * get last page url
     *
     * @author Sinute
     * @date   2015-09-15
     * @return string
     */
    public function lastPageUrl()
    {
        if ($this->currentPage() != $this->lastPage()) {
            if ($this->lastPageUrl) {
                return $this->lastPageUrl;
            } else {
                return $this->url($this->lastPage());
            }
        }
    }

    /**
     * get pages url
     *
     * @author Sinute
     * @date   2015-09-15
     * @return string
     */
    public function pagesUrl()
    {
        $displayNum = $this->displayNum ?: 10;

        if (!($displayNum & 1)) {
            $displayFront = $displayNum - floor($displayNum / 2);
        } else {
            $displayFront = $displayNum - floor(($displayNum + 1) / 2);
        }
        $displayBack = $displayNum - 1 - $displayFront;

        // 前页面数不足后页面补足
        if ($this->currentPage() - $displayFront < 1) {
            $displayFront = $this->currentPage() - 1;
            $displayBack  = $displayNum - 1 - $displayFront;
        } elseif ($this->currentPage() + $displayBack > $this->lastPage()) {
            // 后页面数不足前页面补足
            $displayBack  = $this->lastPage() - $this->currentPage();
            $displayFront = $displayNum - 1 - $displayBack;
        }
        $startPage = max($this->currentPage() - $displayFront, 1);
        $endPage   = min($this->currentPage() + $displayBack, $this->lastPage());

        $pages = [];
        for ($page = $startPage; $page <= $endPage; ++$page) {
            $pages[$page] = $this->url($page);
        }

        $pages[$this->currentPage()] = null;
        return $pages;
    }
}
