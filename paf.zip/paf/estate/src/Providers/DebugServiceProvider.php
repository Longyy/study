<?php

namespace Estate\Providers;

use Estate\Console\Commands\Debug\CreateToken;
use Estate\Console\Commands\Debug\Ping;
use Illuminate\Http\Request;
use Illuminate\Routing\Router;
use Illuminate\Support\ServiceProvider;
use Response;

class DebugServiceProvider extends ServiceProvider
{

    /**
     * Define your route model bindings, pattern filters, etc.
     *
     * @param  \Illuminate\Routing\Router  $oRouter
     * @return void
     */
    public function boot(Router $oRouter, Request $oRequest)
    {
        if (app()->environment('dev', 'qa', 'anhouse')) {
            // key check
            $oRouter->any('_debug/key', function (Request $oRequest) {
                return Response::json(static::checkKey($oRequest->input('sFrom'), $oRequest->input('sKey')));
            });
        }
    }

    protected static function checkKey($sFrom, $sKey)
    {
        $sServerKey = '';
        if (!$sKey || !($sServerKey = config("services.paf.{$sFrom}.key")) || ($sKey !== $sServerKey)) {
            return [false, "请求方 ({$sKey}) 不匹配提供方 ({$sServerKey})"];
        }
        return [true, ''];
    }

    public function register()
    {
        if (app()->environment('dev', 'qa', 'anhouse')) {
            // key check
            $this->app->singleton('command.debug.ping', function () {
                return new Ping;
            });
            $this->app->singleton('command.debug.create-token', function () {
                return new CreateToken;
            });
            $this->commands([
                'command.debug.ping',
                'command.debug.create-token',
            ]);
        }
    }

}
