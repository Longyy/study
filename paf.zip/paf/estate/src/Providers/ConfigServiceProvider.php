<?php
namespace Estate\Providers;

use Illuminate\Support\ServiceProvider;

/**
 * 自动配置载入
 */
class ConfigServiceProvider extends ServiceProvider
{
    public function register()
    {
    }
}
