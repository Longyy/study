<?php

namespace Estate\Providers;

use Illuminate\Support\AggregateServiceProvider;

class CommonServiceProvider extends AggregateServiceProvider {

    /**
     * Indicates if loading of the provider is deferred.
     *
     * @var bool
     */
    // protected $defer = true;

    /**
     * The provider class names.
     *
     * @var array
     */
    protected $providers = [
        'Estate\Providers\ExceptionServiceProvider',
        'Estate\Providers\RequestClientServiceProvider',
        'Estate\Providers\ResponseMacroServiceProvider',
        'Estate\Providers\LogServiceProvider',
        'Paf\LogService\Providers\LogServiceProvider',
        'Estate\Providers\ServiceAuthorizeServiceProvider',
        'Estate\Providers\ValidatorServiceProvider',
        'Estate\Providers\DebugServiceProvider',
        'Estate\Providers\ConfigServiceProvider',
    ];

}