<?php

namespace Estate\Providers;

use Illuminate\Support\ServiceProvider;
use Validator;

class ValidatorServiceProvider extends ServiceProvider
{

    /**
     * 扩展验证规则
     *
     * @author Sinute
     * @date   2015-06-26
     * @return void
     */
    public function boot()
    {
        Validator::resolver(function ($oTranslator, $aData, $aRules, $aMessages, $aAttributes) {
            return new \Estate\Validation\Validator($oTranslator, $aData, $aRules, $aMessages, $aAttributes);
        });
    }

    public function register()
    {
        //
    }

}
