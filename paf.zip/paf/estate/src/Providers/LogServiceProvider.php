<?php
namespace Estate\Providers;

use Estate\Services\ConfigureLogging\ConfigureLogging;
use Illuminate\Support\ServiceProvider;
use Paf\LogService\Formatters\LogServiceFormatter;

class LogServiceProvider extends ServiceProvider
{

    /**
     * 格式化日志
     *
     * @author Sinute
     * @date   2015-04-18
     * @return void
     */
    public function boot()
    {
        // 重新配置日志处理器
        ConfigureLogging::configureHandlers($this->app, $this->app['log']);

        LogServiceFormatter::setTrackIDResolver(function () {
            return app('request.client')->getTrackID();
        });

        // 数据库查询日志
        \Event::listen('illuminate.query', function ($sQuery, $aBindings, $fTime, $sConnection) {
            app('syslog')->debug("[{$sConnection} {$fTime}] {$sQuery}", $aBindings);
        });
    }

    public function register()
    {
    }

}
