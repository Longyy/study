<?php

namespace Estate\Providers;

use Request;
use Illuminate\Support\ServiceProvider;

class RequestClientServiceProvider extends ServiceProvider {

    /**
     * Perform post-registration booting of services.
     *
     * @return void
     */
    public function boot()
    {
        //
    }

    public function register()
    {
        // 注册追踪ID服务
        $this->app->singleton('request.client', function($oApp)
        {
            return new \Estate\Services\Request\Client;
        });

        // @deprecated
        $this->app->singleton('trackId', function($oApp)
        {
            return new \Estate\Services\Request\TrackID;
        });
    }

}
