<?php

namespace Estate\Providers;

use Estate\Services\Responses\AjaxResponse;
use Estate\Services\Responses\ApiResponse;
use Estate\Services\Responses\MobiResponse;
use Exception;
use Illuminate\Support\ServiceProvider;
use Response;

class ResponseMacroServiceProvider extends ServiceProvider
{

    /**
     * 绑定响应宏
     *
     * @author Sinute
     * @date   2015-04-16
     * @return void
     */
    public function boot()
    {
        // 详细内部接口返回宏
        Response::macro('detailApi', function ($mContent = [], $iStatus = 200, array $aHeaders = [], $iOptions = 0) {
            return response()->json(ApiResponse::detailApi($mContent), $iStatus, $aHeaders, $iOptions);
        });

        // 列表内部接口返回宏
        Response::macro('listApi', function ($mContent = [], $iStatus = 200, array $aHeaders = [], $iOptions = 0) {
            return response()->json(ApiResponse::listApi($mContent), $iStatus, $aHeaders, $iOptions);
        });

        // 异常内部接口返回宏
        Response::macro('exceptionApi', function (Exception $mContent, $iStatus = 200, array $aHeaders = [], $iOptions = 0) {
            return response()->json(ApiResponse::exceptionApi($mContent), $iStatus, $aHeaders, $iOptions);
        });

        // ajax接口返回宏
        Response::macro('ajax', function ($mContent = [], $iAjaxStatus = 0, $iStatus = 200, array $aHeaders = [], $iOptions = 0) {
            return response()->json(AjaxResponse::ajax($mContent, $iAjaxStatus), $iStatus, $aHeaders, $iOptions);
        });

        // 异常ajax接口返回宏
        Response::macro('exceptionAjax', function (Exception $mContent, $iAjaxStatus = 0, $iStatus = 200, array $aHeaders = [], $iOptions = 0) {
            return response()->json(AjaxResponse::exceptionAjax($mContent, $iAjaxStatus), $iStatus, $aHeaders, $iOptions);
        });

        // mobi接口返回宏
        Response::macro('mobi', function ($mContent = [], $iStatus = 200, array $aHeaders = [], $iOptions = 0) {
            return response()->json(MobiResponse::mobi($mContent), $iStatus, $aHeaders, $iOptions);
        });

        // 异常mobi接口返回宏
        Response::macro('exceptionMobi', function (Exception $mContent, $iStatus = 200, array $aHeaders = [], $iOptions = 0) {
            return response()->json(MobiResponse::exceptionMobi($mContent), $iStatus, $aHeaders, $iOptions);
        });
    }

    public function register()
    {
        //
    }

}
