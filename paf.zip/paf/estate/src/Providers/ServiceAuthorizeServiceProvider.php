<?php

namespace Estate\Providers;

use Illuminate\Support\ServiceProvider;

class ServiceAuthorizeServiceProvider extends ServiceProvider
{

    /**
     * Perform post-registration booting of services.
     *
     * @return void
     */
    public function boot()
    {
    }

    public function register()
    {
        // 注册通信密钥服务
        $this->app->singleton('auth.service.config', function ($oApp) {
            return new \Estate\Services\Authorize\ServiceConfig;
        });

        // 注册通信令牌服务
        $this->app->singleton('auth.service.token', function ($oApp) {
            return new \Estate\Services\Authorize\ServiceToken;
        });

        // 注册通信IP服务
        $this->app->singleton('auth.service.ip', function ($oApp) {
            return new \Estate\Services\Authorize\ServiceIp;
        });

        // 注册通信的密钥验证服务
        $this->app->singleton('auth.service.signature', function ($oApp) {
            return new \Estate\Services\Authorize\ServiceSignature;
        });
    }

}
