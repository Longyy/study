<?php

namespace Estate\Providers;

use Illuminate\Support\ServiceProvider;

class ExceptionServiceProvider extends ServiceProvider {

    /**
     * Perform post-registration booting of services.
     *
     * @return void
     */
    public function boot()
    {
    }

    public function register()
    {
        // 注册异常池单例
        $this->app->singleton('exception.pool', function($oApp)
        {
            return \Estate\Exceptions\ExceptionPool::getInstance();
        });
    }

}
