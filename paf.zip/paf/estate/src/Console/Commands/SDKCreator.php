<?php
namespace Estate\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Console\GeneratorCommand;
use ReflectionClass;
use Symfony\Component\Console\Input\InputArgument;
use Symfony\Component\Console\Input\InputOption;

// @deprecated
class SDKCreator extends GeneratorCommand
{

    /**
     * 命令名
     * @var string
     */
    protected $name = 'make:sdk';

    /**
     * 命令描述
     * @var string
     */
    protected $description = 'Create a new SDK';

    /**
     * 生成类别
     * @var string
     */
    protected $type = 'SDK';

    /**
     * 命令执行
     *
     * @author Sinute
     * @date   2015-04-28
     * @return void
     */
    public function fire()
    {
        parent::fire();
    }

    /**
     * 生成SDK类
     *
     * @author Sinute
     * @date   2015-04-28
     * @param  string     $name 类名
     * @return string           类内容
     */
    protected function buildClass($name)
    {
        $stub = $this->files->get($this->getStub());

        return $this->replaceVersion($stub, $this->argument('version'))
                    ->replaceMethods($stub)
                    ->replaceDate($stub)
                    ->replaceClass($stub, $name);
    }

    /**
     * 替换版本占位符
     *
     * @author Sinute
     * @date   2015-04-28
     * @param  string     &$stub   模版内容
     * @param  string     $version 版本号
     * @return \Estate\Console\Commands\SDKCreator
     */
    protected function replaceVersion(&$stub, $version)
    {
        $stub = str_replace(
            '{{version}}', $version, $stub
        );

        return $this;
    }

    /**
     * 替换方法占位符
     *
     * @author Sinute
     * @date   2015-04-28
     * @param  string     &$stub 模版内容
     * @return \Estate\Console\Commands\SDKCreator
     */
    protected function replaceMethods(&$stub)
    {
        $methodsStub    = '';
        $SDKServiceName = str_replace('\\\\', '\\', $this->getDefaultNamespace($this->getAppNamespace()) . '\\' . $this->argument('name'));
        $SDK            = new $SDKServiceName;
        $reflectClass   = new ReflectionClass($SDKServiceName);
        $methods        = $reflectClass->getMethods();
        foreach ($methods as $method) {
            // 非public接口不生成
            if (!$this->option('all') && !$method->isPublic()) {
                continue;
            }
            $fakeParamValue = [];
            $params         = $method->getParameters();
            array_walk($params, function (&$param) use (&$fakeParamValue) {
                $paramString = '';
                if ($param->isOptional()) {
                    $defaultValue = $param->getDefaultValue();
                    // 类型限定的情况
                    if ($param->isArray()) {
                        $paramString = 'array ';
                    }
                    $paramString .= "\${$param->getName()} = " . $this->sPrintValue($defaultValue);
                } else {
                    if ($param->isArray()) {
                        $fakeParamValue[] = [];
                        $paramString = "array \${$param->getName()}";
                    } else {
                        $fakeParamValue[] = '';
                        $paramString = "\${$param->getName()}";
                    }
                }
                $param = $paramString;
            });
            $params        = join(', ', $params);
            $callback      = $method->getClosure($SDK);
            $requestInfo   = call_user_func_array($callback, $fakeParamValue);
            $requestMethod = $requestInfo[0];
            $requestPath   = $requestInfo[1];
            $requestParams = array_get($requestInfo, 2, ['']);
            if (is_array($requestParams)) {
                array_walk($requestParams, function (&$requestParam) {
                    $requestParam = "'{$requestParam}'";
                });
                $requestParams = 'compact(' . join(', ', $requestParams) . ')';
            } else {
                $requestParams = "\${$requestParams}";
            }
            $methodsStub .= "    \n    {$method->getDocComment()}\n    public function {$method->getName()}({$params})\n    {\n        return \$this->request('{$requestMethod}', \"{$requestPath}\", {$requestParams});\n    }\n";
        }

        $stub = str_replace(
            '{{methods}}', $methodsStub, $stub
        );

        return $this;
    }

    /**
     * 替换日期占位符
     *
     * @author Sinute
     * @date   2015-04-28
     * @param  string     &$stub 模版内容
     * @return \Estate\Console\Commands\SDKCreator
     */
    protected function replaceDate(&$stub)
    {
        $stub = str_replace(
            '{{date}}', date('Y-m-d'), $stub
        );

        return $this;
    }

    /**
     * 替换类名占位符
     *
     * @author Sinute
     * @date   2015-04-28
     * @param  string     $stub 模版内容
     * @param  string     $name 类名
     * @return string           模版内容
     */
    protected function replaceClass($stub, $name)
    {
        $class = str_replace($this->getNamespace($name) . '\\', '', $name) . 'SDK';

        return str_replace('{{class}}', $class, $stub);
    }

    /**
     * 获取SDK生成路径
     *
     * @author Sinute
     * @date   2015-04-28
     * @param  string     $name 类名
     * @return string           SDK生成路径
     */
    protected function getPath($name)
    {
        $name = str_replace($this->getAppNamespace(), '', $name);

        return $this->laravel['path'] . '/' . str_replace('\\', '/', $name) . 'SDK.php';
    }

    /**
     * 获取模版内容
     *
     * @author Sinute
     * @date   2015-04-28
     * @return string
     */
    protected function getStub()
    {
        return __DIR__ . '/stubs/sdk.stub';
    }

    /**
     * 获取SDK目录的命名空间
     *
     * @author Sinute
     * @date   2015-04-28
     * @param  string     $rootNamespace 根命名空间
     * @return string
     */
    protected function getDefaultNamespace($rootNamespace)
    {
        return $rootNamespace . '\Services\SDK\V' . str_replace('.', '_', $this->argument('version'));
    }

    /**
     * 获取可选参数
     *
     * @author Sinute
     * @date   2015-04-28
     * @return array
     */
    protected function getOptions()
    {
        return [
            ['all', 'a', InputOption::VALUE_NONE, 'Indicates that private/protected methods should be generated.'],
        ];
    }

    /**
     * 获取必填参数
     *
     * @author Sinute
     * @date   2015-04-28
     * @return array
     */
    protected function getArguments()
    {
        return [
            ['name', InputArgument::REQUIRED, 'The name of the SDK'],
            ['version', InputArgument::REQUIRED, 'The version of the SDK'],
        ];
    }

    /**
     * 格式化输出变量结构
     *
     * @author Sinute
     * @date   2015-05-06
     * @param  mixed     $mValue 变量
     * @return string            格式化的变量结构
     */
    protected function sPrintValue($mValue)
    {
        switch (gettype($mValue)) {
            case 'boolean':
                return $mValue ? 'true' : 'false';
            case 'integer':
            case 'double':
                return $mValue;
            case 'string':
                return "'{$mValue}'";
            case 'array':
                $aValues = [];
                if (array_values(range(0, count($mValue) - 1)) == array_keys($mValue)) {
                    foreach ($mValue as $sKey => $mVal) {
                        $aValues[] = $this->sPrintValue($mVal);
                    }
                } else {
                    foreach ($mValue as $sKey => $mVal) {
                        $aValues[] = $this->sPrintValue($sKey) . ' => ' . $this->sPrintValue($mVal);
                    }
                }
                return '[' . join($aValues, ', ') . ']';
            case 'NULL':
                return 'null';
            default:
                return 'null';
        }
    }

}
