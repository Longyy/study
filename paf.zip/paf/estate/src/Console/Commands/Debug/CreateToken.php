<?php
namespace Estate\Console\Commands\Debug;

use Illuminate\Console\Command;
use Illuminate\Support\Debug\Dumper;
use Symfony\Component\Console\Input\InputArgument;

class CreateToken extends Command
{

    /**
     * 命令名
     * @var string
     */
    protected $name = 'debug:create-token';

    /**
     * 命令描述
     * @var string
     */
    protected $description = 'Dump the process how token generated';

    protected $messages = [
        '岭上开花',
        '海底捞月',
        '一气贯通',
        '风花雪月',
        '国士无双',
        '四暗单骑',
        '九莲宝灯',
        '幺九全带',
        '石上三年',
        '九种九牌',
        '四风连打',
    ];

    /**
     * 命令执行
     *
     * @author Sinute
     * @date   2015-11-04
     * @return void
     */
    public function fire()
    {
        $sQuery = $this->input->getArgument('query');
        $sKey   = $this->input->getArgument('key');
        $iTime  = $this->input->getArgument('time');

        $aParams = json_decode($sQuery, true);
        if ($aParams === null) {
            $this->error($this->messages[rand(0, 100) % count($this->messages)]);
            return;
        }

        $this->dumpJsonEncode($aParams, $sKey, $iTime);
        $this->dumpSerialize($aParams, $sKey, $iTime);
    }

    protected function getArguments()
    {
        return [
            ['query', InputArgument::REQUIRED, '参数(json格式)'],
            ['key', InputArgument::REQUIRED, '密钥'],
            ['time', InputArgument::REQUIRED, '请求时间'],
        ];
    }

    protected function dumpJsonEncode($aParams, $sKey, $iTime)
    {
        $this->error("\n0. \$request: (Using json_encode)");
        (new Dumper)->dump($aParams);

        $this->error("\n1. unset(\$request['_from'], \$request['_requesttime'], \$request['_token'])");
        unset($aParams['_from'], $aParams['_requesttime'], $aParams['_token']);
        (new Dumper)->dump($aParams);

        $this->error("\n2. \$str = json_encode(\$request, JSON_NUMERIC_CHECK)");
        $sStr = json_encode($aParams, JSON_NUMERIC_CHECK);
        (new Dumper)->dump($sStr);

        $this->error("\n3. \$sha1 = sha1(\$str)");
        $sSha1 = sha1($sStr);
        (new Dumper)->dump($sSha1);

        $this->error("\n4. \$string = \$sha1 . \$key . \$requestTime");
        $sString = $sSha1 . $sKey . $iTime;
        (new Dumper)->dump($sString);

        $this->error("\n5. \$token = md5(\$string)");
        $sToken = md5($sString);
        (new Dumper)->dump($sToken);
    }

    protected function dumpSerialize($aParams, $sKey, $iTime)
    {
        $this->question("\n0. \$request: (Using serialize)");
        (new Dumper)->dump($aParams);

        $this->question("\n1. unset(\$request['_from'], \$request['_requesttime'], \$request['_token'])");
        unset($aParams['_from'], $aParams['_requesttime'], $aParams['_token']);
        (new Dumper)->dump($aParams);

        $this->question("\n2. \$str = serialize(\$request)");
        $sStr = \Estate\Services\Authorize\ServiceToken::serialize($aParams);
        (new Dumper)->dump($sStr);

        $this->question("\n3. \$sha1 = sha1(\$str)");
        $sSha1 = sha1($sStr);
        (new Dumper)->dump($sSha1);

        $this->question("\n4. \$string = \$sha1 . \$key . \$requestTime");
        $sString = $sSha1 . $sKey . $iTime;
        (new Dumper)->dump($sString);

        $this->question("\n5. \$token = md5(\$string)");
        $sToken = md5($sString);
        (new Dumper)->dump($sToken);
    }
}
