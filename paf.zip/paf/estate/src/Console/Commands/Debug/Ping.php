<?php
namespace Estate\Console\Commands\Debug;

use Illuminate\Console\Command;
use Symfony\Component\Console\Input\InputOption;

class Ping extends Command
{

    /**
     * 命令名
     * @var string
     */
    protected $name = 'debug:ping';

    /**
     * 命令描述
     * @var string
     */
    protected $description = 'Access test';

    /**
     * 命令执行
     *
     * @author Sinute
     * @date   2015-11-04
     * @return void
     */
    public function fire()
    {
        if ($sAppendEnv = $this->input->getOption('append')) {
            \Dotenv::load(app('path.base'), $sAppendEnv);
            (new \Illuminate\Foundation\Bootstrap\LoadConfiguration)->bootstrap(app());
        }

        foreach (config('rpc.client') as $sTo => $aConfig) {
            $sFrom = config('rpc.from');
            if (ends_with(array_get($aConfig, 'conf.url'), '/rpc')) {
                $sUrl = substr(array_get($aConfig, 'conf.url'), 0, -4);
                $sKey = config("services.paf.{$sTo}.key");
                $this->ping($sTo, $sUrl, $sFrom, $sKey);
            } else {
                $sUrl = array_get($aConfig, 'conf.url');
                $this->skip($sTo, parse_url(starts_with($sUrl, ['http://', 'https://']) ? $sUrl : "http://{$sUrl}", PHP_URL_HOST), '别人家的仓库');
            }
        }
        $this->info('完成');
    }

    protected function ping($sTo, $sUrl, $sFrom, $sKey)
    {
        $oCurl = curl_init();

        curl_setopt_array($oCurl, [
            CURLOPT_URL            => $sUrl . '/_debug/key?' . http_build_query(compact('sFrom', 'sKey')),
            CURLOPT_RETURNTRANSFER => true,
            CURLOPT_TIMEOUT        => 5,
            CURLOPT_IPRESOLVE      => CURL_IPRESOLVE_V4,
        ]);

        $sResponse = curl_exec($oCurl);
        $sError    = curl_error($oCurl);
        $iCode     = curl_getinfo($oCurl, CURLINFO_HTTP_CODE);

        curl_close($oCurl);
        $aResponse = json_decode($sResponse, true);

        if ($sError) {
            $this->fail($sTo, $sUrl, $sError);
        } elseif ($iCode == 404) {
            $this->fail($sTo, $sUrl, '需要升级版本');
        } elseif ($iCode == 500) {
            $this->fail($sTo, $sUrl, '提供方500啦');
        } elseif (isset($aResponse[0])) {
            if ($aResponse[0]) {
                $this->pass($sTo, $sUrl);
            } else {
                $this->fail($sTo, $sUrl, $aResponse[1]);
            }
        } else {
            $this->fail($sTo, $sUrl, $sResponse);
        }
    }

    protected function skip($sTo, $sUrl, $sReason)
    {
        $this->line("<info>{$sTo}: {$sUrl}</info>");
        $this->line("    <comment>[跳过] 原因: {$sReason}</comment>");
    }

    protected function fail($sTo, $sUrl, $sReason)
    {
        $this->line("<info>{$sTo}: {$sUrl}</info>");
        $this->line("    <error>[失败] 原因: {$sReason}</error>");
    }

    protected function pass($sTo, $sUrl)
    {
        $this->line("<info>{$sTo}: {$sUrl}</info>");
        $this->line("    <info>[通过]</info>");
    }

    protected function getOptions()
    {
        return [
            ['append', null, InputOption::VALUE_OPTIONAL, '使用追加的环境配置(通常仅在开发环境下追加.env.example用以补充.env的配置)', false],
        ];
    }
}
