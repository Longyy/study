<?php

namespace Estate\Services\Request;

// @deprecated
class TrackID
{
    // @deprecated
    public function get()
    {
        return app('request.client')->getTrackID();
    }

    // @deprecated
    public function set($sTrackID)
    {
        return app('request.client')->setClientTrackID($sTrackID);
    }
}
