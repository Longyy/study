<?php
namespace Estate\Services\Authorize;

use Estate\Exceptions\ServiceException;
use Log;
use App\Http\Requests\Request;
use Paf\Signature\Signature;

/**
 * 服务器签名算法类
 *
 * Class Signature
 *
 * @package Ananzu\Auth
 */
class ServiceSignature
{

    const APP_SECRET = '7bae14bab42629ee01e323db934d6a060b60b634';
    const EXPIRE_TIME = 3600;//签名的过期时间

    /**
     * 验签
     * @param $oRequest
     * @return bool
     * @throws ServiceException
     */
    public static function verifySign($oRequest)
    {
        //如果没有开启验证,直接验签成功
        if (env("SIGNATURE_INVALID") === false) {
            return true;
        }
        $allowed = ['signFuncID', 'time', 'apiSequence', 'apiKey', 'signature'];

        if (!isset($_REQUEST['time']) || !isset($_REQUEST['signature']) || !isset($_REQUEST['signFuncID'])) {
            Log::debug(__FUNCTION__ . "接口签名失败,没有传入要签名的数据", $_REQUEST);

            throw new ServiceException("TOKEN_ERROR");
        }

        if ('POST' === $oRequest->getMethod()) {
            $data = $_POST;
        } else {
            $data = $_GET;
        }
        // 过滤系统参数
        foreach ($allowed as $sKey) {
            if (isset($data[$sKey])) {
                unset($data[$sKey]);
            }
        }
        $aParams = [
            'signFuncID' => $_REQUEST['signFuncID'],
            'time' => $_REQUEST['time'],
            'apiSequence' => md5($_SERVER['DOCUMENT_URI']),
            'apiKey' => self::APP_SECRET
        ];
        if (time() - (int)$aParams["time"] > self::EXPIRE_TIME) {
            Log::debug(__FUNCTION__ . "请求的数据已过期");
            throw new ServiceException("TOKEN_ERROR");
        }
        $signature = Signature::generate($aParams['signFuncID'], $aParams['time'], $aParams['apiKey'], $aParams['apiSequence'], $data);
        Log::debug(__FUNCTION__ . "签名信息", [$aParams, $data]);
        return 0 === strcmp($signature, $_REQUEST['signature']);
    }
}