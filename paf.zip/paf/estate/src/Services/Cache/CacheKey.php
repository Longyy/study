<?php
namespace Estate\Services\Cache;

class CacheKey
{
    public static function __callStatic($sName, array $aParams)
    {
        $aParams = array_dot($aParams);
        ksort($aParams);
        $sKey = "{$sName}:" . md5(json_encode($aParams));
        return strlen($sKey) > 255 ? md5($sKey) : $sKey;
    }
}
