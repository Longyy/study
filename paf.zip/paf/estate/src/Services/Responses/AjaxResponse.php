<?php

namespace Estate\Services\Responses;

use Estate\Contracts\Exceptions\Exception as ExceptionContract;
use Exception;
use Illuminate\Contracts\Support\Arrayable;

/**
 * 响应
 */
class AjaxResponse
{
    /**
     * AJAX异常返回
     *
     * @author Sinute
     * @date   2015-04-18
     * @param  \Exception  $oException 异常
     * @param  integer     $iStatus  状态
     * @return array
     */
    public static function exceptionAjax(Exception $oException, $iStatus = 0)
    {
        $sError = '';
        if ($oException instanceof ExceptionContract) {
            $sError = $oException->getMessage();
        }

        app('syslog')->info(
            "response",
            [
                'status'   => $oException->getCode(),
                'response' => $oException->getMessage(),
            ]
        );

        return [
            'hasError' => true,
            'success'  => false,
            'error'    => $sError,
            'status'   => $iStatus,
        ];
    }

    /**
     * AJAX返回
     *
     * @author Sinute
     * @date   2015-04-18
     * @param  mixed     $mContent 返回内容
     * @param  integer   $iStatus  状态
     * @return array
     */
    public static function ajax($mContent, $iStatus = 0)
    {
        if ($mContent instanceof Arrayable) {
            $mContent = $mContent->toArray();
        }

        $aResult = [
            'hasError' => false,
            'success'  => true,
            'error'    => '',
            'status'   => $iStatus,
        ];

        return $aResult + $mContent;
    }
}
