<?php

namespace Estate\Services\Responses;

use Estate\Contracts\Exceptions\Exception as ExceptionContract;
use Exception;
use stdClass;

/**
 * 响应
 */
class MobiResponse
{
    /**
     * mobi异常返回
     *
     * @author Sinute
     * @date   2015-08-05
     * @param  \Exception  $oException 异常
     * @return array
     */
    public static function exceptionMobi(Exception $oException)
    {
        $sError = '';
        if ($oException instanceof ExceptionContract) {
            $sError = $oException->getMessage();
        }

        app('syslog')->info(
            "response",
            [
                'status'   => $oException->getCode(),
                'response' => $oException->getMessage(),
            ]
        );

        return [
            'code' => $oException->getCode(),
            'msg'  => $sError,
            'data' => new stdClass,
        ];
    }

    /**
     * mobi返回
     *
     * @author Sinute
     * @date   2015-08-05
     * @param  mixed     $mContent 返回内容
     * @param  integer   $iStatus  状态
     * @return array
     */
    public static function mobi($mContent)
    {
        if ($mContent instanceof Arrayable) {
            $mContent = $mContent->toArray();
        }

        return [
            'code' => 0,
            'msg'  => 'ok',
            'data' => jo($mContent),
        ];
    }
}
