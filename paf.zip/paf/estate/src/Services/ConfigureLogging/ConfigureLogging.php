<?php
namespace Estate\Services\ConfigureLogging;

use Illuminate\Contracts\Foundation\Application;
use Illuminate\Log\Writer;
use Monolog\Logger as Monolog;

class ConfigureLogging
{
    /**
     * 配置日志处理器
     *
     * @author Sinute
     * @date   2015-05-20
     * @param  \Illuminate\Contracts\Foundation\application     $oApp
     * @param  \Illuminate\Log\Writer                           $oLog
     * @return void
     */
    public static function configureHandlers(Application $oApp, Writer $oLog)
    {
        static::clearHandlers();

        $method = "configure" . ucfirst($oApp['config']['app.log']) . "Handler";
        self::{$method}($oApp, $oLog);

        $oHandler = $oLog->getMonolog()->popHandler();
        $oHandler->pushProcessor(function ($aRecord) {
            $sTrackId           = app('request.client')->getTrackID();
            $aRecord['message'] = "{$sTrackId} {$aRecord['message']}";
            return $aRecord;
        });

        $oLog->getMonolog()->pushHandler($oHandler);

        // 分离系统日志
        $oApp->instance('syslog', new Writer(new Monolog($oApp->environment())));
        $oApp['syslog']->getMonolog()->pushHandler($oHandler);
    }

    /**
     * 清除所有日志处理器
     *
     * @author Sinute
     * @date   2015-09-22
     * @return void
     */
    public static function clearHandlers()
    {
        $iHandlersCount = count(app('log')->getMonolog()->getHandlers());
        while ($iHandlersCount) {
            app('log')->getMonolog()->popHandler();
            $iHandlersCount--;
        }
    }

    /**
     * single模式的日志处理器
     *
     * @author Sinute
     * @date   2015-05-20
     * @param  \Illuminate\Contracts\Foundation\Application     $oApp
     * @param  \Illuminate\Log\Writer                           $oLog
     * @return void
     */
    protected static function configureSingleHandler(Application $oApp, Writer $oLog)
    {
        $oLog->useFiles($oApp->make('config')->get('app.log_path', $oApp->storagePath() . '/logs/laravel.log'));
    }

    /**
     * daily模式的日志处理器
     *
     * @author Sinute
     * @date   2015-05-20
     * @param  \Illuminate\Contracts\Foundation\Application  $oApp
     * @param  \Illuminate\Log\Writer                        $oLog
     * @return void
     */
    protected static function configureDailyHandler(Application $oApp, Writer $oLog)
    {
        $oLog->useDailyFiles(
            $oApp->make('config')->get('app.log_path', $oApp->storagePath() . '/logs/laravel.log'),
            $oApp->make('config')->get('app.log_max_files', 0)
        );
    }

    /**
     * syslog模式的日志处理器
     *
     * @author Sinute
     * @date   2015-05-20
     * @param  \Illuminate\Contracts\Foundation\Application  $oApp
     * @param  \Illuminate\Log\Writer                        $oLog
     * @return void
     */
    protected static function configureSyslogHandler(Application $oApp, Writer $oLog)
    {
        $oLog->useSyslog('laravel');
    }

    /**
     * errorlog模式的日志处理器
     *
     * @author Sinute
     * @date   2015-05-20
     * @param  \Illuminate\Contracts\Foundation\Application  $oApp
     * @param  \Illuminate\Log\Writer                        $oLog
     * @return void
     */
    protected static function configureErrorlogHandler(Application $oApp, Writer $oLog)
    {
        $oLog->useErrorLog();
    }
}
