<?php

namespace Estate\Exceptions;

use Estate\Contracts\Exceptions\MobiException as MobiExceptionContract;
use Estate\Exceptions\Translator\Translator;
use Exception;

class MobiException extends Exception implements MobiExceptionContract
{
    use Translator;

    /**
     * 构造函数
     *
     * @author Sinute
     * @date   2015-05-20
     * @param  string     $sMsg  错误信息
     * @param  integer    $iCode 错误码
     */
    public function __construct($sMsg = '', $iCode = 0)
    {
        list($sMsg, $iCode) = $this->trans($sMsg, $iCode);
        parent::__construct($sMsg, $iCode);
    }
}
