<?php
namespace Estate\Support;

class Msg
{
    protected static $sSeparator = '#';

    public static function separator($sSeparator = null)
    {
        if (null === $sSeparator) {
            return static::$sSeparator;
        } else {
            static::$sSeparator = $sSeparator;
        }
    }

    public static function join()
    {
        return join(static::separator(), func_get_args());
    }
}
