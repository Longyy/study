<?php

namespace Estate\Support\Accessors;

use Closure;
use Exception;
use RuntimeException;
use Estate\Contracts\Accessors\ServiceAccessor;

/**
* 通用服务访问器
*/
class CommonServiceAccessor
{
    /**
     * 服务访问器
     * @var \Estate\Contracts\Accessors\ServiceAccessor
     */
    protected $oServiceAccessor;

    /**
     * 错误处理器
     * @var \Closure
     */
    protected $oErrorHandler;

    /**
     * 构造函数
     *
     * @author Sinute
     * @date   2015-04-17
     * @param  \Estate\Contracts\Accessors\ServiceAccessor $oServiceAccessor
     */
    public function __construct(ServiceAccessor $oServiceAccessor)
    {
        $this->oServiceAccessor = $oServiceAccessor;
        $this->oErrorHandler    = function($mError, &$mData) use($oServiceAccessor) {
            return $oServiceAccessor->errorHandler($mError, $mData);
        };
    }

    /**
     * 访问内部服务访问器
     *
     * @author Sinute
     * @date   2015-04-17
     * @param  Closure    $oCallback 访问回调
     * @return \Estate\Support\Accessors\CommonServiceAccessor
     */
    public function touch(Closure $oCallback)
    {
        $oCommonServiceAccessorClone = clone $this;
        $oCommonServiceAccessorClone->oServiceAccessor = $oCallback(clone $this->oServiceAccessor);
        return $oCommonServiceAccessorClone;
    }

    /**
     * 设置错误处理
     *
     * @author Sinute
     * @date   2015-04-18
     * @param  \Closure    $mCallback
     * @return \Estate\Support\Accessors\CommonServiceAccessor
     */
    public function setErrorHandler($mCallback)
    {
        if (!is_callable($mCallback)) {
            throw new RuntimeException('ILLEGAL ERROR HANDLER');
        }
        $oCommonServiceAccessorClone = clone $this;
        $oCommonServiceAccessorClone->oErrorHandler = $mCallback;
        return $oCommonServiceAccessorClone;
    }

    /**
     * 获取错误处理
     *
     * @author Sinute
     * @date   2015-04-18
     * @return \Closure
     */
    protected function getErrorHandler()
    {
        return $this->oErrorHandler;
    }

    /**
     * 内部请求
     *
     * @author Sinute
     * @date   2015-04-17
     * @param  string     $sName   请求名
     * @param  array      $aParams 参数
     * @return mixed              请求的返回内容
     */
    protected function request($sName, array $aParams)
    {
        try {
            // 在进行到用户的错误处理程序之前给我挺住
            $mResponse = $this->oServiceAccessor->request($sName, $aParams);
        } catch (Exception $oException) {
            $mResponse = $oException->getMessage();
        }
        if (!$this->oServiceAccessor->isSuccess($mResponse)) {
            $mData = [];
            $mError = $this->oServiceAccessor->getError($mResponse);
            $mErrorHandler = $this->getErrorHandler();
            $bPass = false;
            if ($mErrorHandler instanceof Closure) {
                $bPass = $mErrorHandler->__invoke($mError, $mData);
            } else {
                $bPass = $mErrorHandler($mError, $mData);
            }
            if (!$bPass) {
                throw new RuntimeException(get_class($this->oServiceAccessor) . "::$sName() Failed");
            }
        }else{
            $mData = $this->oServiceAccessor->getData($mResponse);
        }
        return $mData;
    }

    /**
     * 魔术方法调用
     *
     * @author Sinute
     * @date   2015-04-17
     * @param  string     $sName   方法名
     * @param  array      $aParams 参数
     * @return mixed              请求的返回内容
     */
    public function __call($sName, array $aParams)
    {
        return $this->request($sName, $aParams);
    }

    /**
     * 深复制
     * @return void
     */
    public function __clone()
    {
        $this->oServiceAccessor = clone $this->oServiceAccessor;
        $this->oErrorHandler    = clone $this->oErrorHandler;
    }

}
