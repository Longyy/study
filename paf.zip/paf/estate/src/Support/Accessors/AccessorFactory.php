<?php

namespace Estate\Support\Accessors;

use Estate\Contracts\Accessors\Accessor;
use Estate\Contracts\Accessors\ServiceAccessor;

/**
* 通用访问器工厂类
*/
class AccessorFactory
{
    /**
     * 生产访问器
     *
     * @author Sinute
     * @date   2015-04-17
     * @param  \Estate\Contracts\Accessors\Accessor   $oAccessor 访问器
     * @return mixed                                            通用访问器
     */
    public static function make(Accessor $oAccessor)
    {
        if ($oAccessor instanceof ServiceAccessor) return new CommonServiceAccessor($oAccessor);
        return null;
    }
}
