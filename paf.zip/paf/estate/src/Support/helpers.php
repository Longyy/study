<?php

/*
 * APP 3.2.2新增
 */
if(!function_exists('arr_quick_modify')){
    /*
     * 用于遍历修改数组元素
     * @author nangua
     * @date 2016-05-04
     * @param string $item 数组被遍历的元素
     * @param string $key 数组键名
     * @param array $userData 用户自定义数组
     */
    function arr_quick_modify(&$item,$key,$userData){
        if(in_array($key,$userData)){
            $item = 1;
        }
    }
}

if (!function_exists('str_quick_random')) {
    /**
     * 生成随机字符串
     *
     * @author Sinute
     * @date   2015-06-17
     * @param  integer    $iLength 字符串长度
     * @param  string     $sPool   字符池
     * @return string              随机字符串
     */
    function str_quick_random($iLength, $sPool = null)
    {
        $iLength = (int) $iLength;
        if (empty($sPool)) {
            $sPool = '0123456789abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ';
        }

        return substr(str_shuffle(str_repeat($sPool, $iLength)), 0, $iLength);
    }
}

if (!function_exists('hf_url')) {
    /**
     * 生成好房url
     *
     * @author Sinute
     * @date   2015-06-17
     * @param  string     $sDomain 域名
     * @param  string     $sUri   路径
     * @param  array      $aParams url参数
     * @param  boolean    $mScheme 调用方案
     * @return string              url
     */
    function hf_url($sDomain, $sUri = '', $aParams = [], $mScheme = false)
    {
        if (substr($sDomain, -3) == 'Url') {
            $sDomain = substr($sDomain, 0, -3);
        }
        return Estate\Foundation\Url::{$sDomain . 'Url'}($sUri, $aParams, $mScheme);
    }
}

if (!function_exists('str_length_trunc')) {
    /**
     * 字符串按长度截断
     *
     * @author Sinute
     * @date   2015-06-17
     * @param  string     $sStr    字符串
     * @param  integer    $iLength 长度
     * @param  string     $sSuffix 后缀
     * @return string              截断后的字符串
     */
    function str_length_trunc($sStr, $iLength, $sSuffix = '...')
    {
        $sRunes = preg_split('/(?<!^)(?!$)/u', $sStr);
        if (count($sRunes) > $iLength) {
            return join(array_slice($sRunes, 0, $iLength)) . $sSuffix;
        } else {
            return $sStr;
        }
    }
}

if (!function_exists('str_width_trunc')) {
    /**
     * 字符串按宽度截断
     *
     * @author Sinute
     * @date   2015-06-17
     * @param  string     $sStr    字符串
     * @param  integer    $iWidth  宽度
     * @param  string     $sSuffix 后缀
     * @return string              截断后的字符串
     */
    function str_width_trunc($sStr, $iWidth, $sSuffix = '...')
    {
        $sRunes  = preg_split('/(?<!^)(?!$)/u', $sStr);
        $iWidthT = 0;
        $iCount  = 0;
        foreach ($sRunes as $sRune) {
            if (($iWidthT += (strlen($sRune) === 1 ? 1 : 2)) <= $iWidth) {
                $iCount++;
            } else {
                break;
            }

        }
        if (count($sRunes) > $iCount) {
            return join(array_slice($sRunes, 0, $iCount)) . $sSuffix;
        } else {
            return $sStr;
        }
    }
}

if (!function_exists('array_assoc')) {
    /**
     * 将索引数组变为关联数组
     *
     * @author Sinute
     * @date   2015-07-21
     * @param  array      $aArray    数组
     * @param  mixed     $oCallback  字符串时为生成索引的key, Closure时结果为生成的key
     * @return array
     */
    function array_assoc(array $aArray, $oCallback)
    {
        if ($oCallback instanceof Closure) {
            $aAssocArray = [];
            foreach ($aArray as $mValue) {
                $aAssocArray[$oCallback($mValue)] = $mValue;
            }
            return $aAssocArray;
        } else {
            return array_combine(array_fetch($aArray, $oCallback), $aArray);
        }
    }
}

if (!function_exists('jo')) {
    /**
     * json object
     *
     * @author Sinute
     * @date   2015-08-27
     * @param  array      $aArray    数组
     * @return array|stdClass
     */
    function jo(array $aArray)
    {
        if (count($aArray) == 0) {
            return new stdClass;
        } else {
            return $aArray;
        }
    }
}

if (!function_exists('hf_assets')) {
    /**
     * 生成静态资源地址
     *
     * @author Sinute
     * @date   2015-10-14
     * @param  string     $sDomain 域名
     * @param  string     $sPath   路径
     * @param  string     $sVersion   版本号
     * @param  array      $aParams url参数
     * @param  boolean    $mScheme 调用方案
     * @return string              url
     */
    function hf_assets($sDomain, $sPath, $sVersion = '', $aParams = [], $mScheme = false)
    {
        $sVersion = config("view.versions.{$sVersion}", $sVersion);
        if (!$sVersion) {
            // 如果没有版本号则退化为hf_url
            return hf_url($sDomain, $sPath, $aParams, $mScheme);
        }
        return hf_url($sDomain, preg_replace('~(\w+/)(.*)~', "\$1/{$sVersion}/\$2", $sPath), $aParams, $mScheme);
    }
}

if (!function_exists('toUTF8')) {
    /**
     * 转换utf8
     *
     * @author Sinute
     * @date   2015-10-14
     * @param  string     $sString 字符串
     * @param  boolean    $aEncodingList 编码
     * @return string|bool              失败时返回false
     */
    function toUTF8($sString, array $aEncodingList = ['ASCII', 'UTF-8', 'GBK'])
    {
        if (!($sEncoding = mb_detect_encoding($sString, $aEncodingList))) {
            return false;
        }
        return iconv($sEncoding, 'UTF-8//IGNORE', $sString);
    }
}
