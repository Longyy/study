<?php
namespace Estate\Support;

class PerformanceRecorder
{
    protected static $aTrace = [];

    public static function start($sMark = '')
    {
        if (config('app.debug')) {
            array_push(self::$aTrace, self::getTrace($sMark, 2));
        }
    }

    public static function stop($sMark = '')
    {
        if (config('app.debug')) {
            self::log(array_pop(self::$aTrace), self::getTrace($sMark, 2));
        }
    }

    protected static function getTrace($sMark = '', $iLimit = 1)
    {
        $aTraces = debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS, $iLimit);
        $aTrace  = end($aTraces);
        return [
            'file'   => $aTrace['file'],
            'line'   => $aTrace['line'],
            'memory' => memory_get_usage(true),
            'time'   => microtime(true),
            'mark'   => $sMark,
        ];
    }

    protected static function log($aTraceStart, $aTraceEnd)
    {
        $sStartMark = $aTraceStart['mark'] ?: "{$aTraceStart['file']}:L{$aTraceStart['line']}";
        $sEndMark   = $aTraceEnd['mark'] ?: "{$aTraceEnd['file']}:L{$aTraceEnd['line']}";
        app('syslog')->debug("{$sStartMark} - {$sEndMark}", [
            'start_time'   => $aTraceStart['time'],
            'end_time'     => $aTraceEnd['time'],
            'time_usage'   => $aTraceEnd['time'] - $aTraceStart['time'],
            'start_memory' => $aTraceStart['memory'],
            'end_memory'   => $aTraceEnd['memory'],
            'memory_usage' => $aTraceEnd['memory'] - $aTraceStart['memory'],
        ]);
    }
}
