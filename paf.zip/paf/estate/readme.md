## 系统扩展代码
为系统提供底层功能扩展

## 文档

### 异常

* [验证异常](validate-exception)
* [异常池](exception-pool)
* [应用层异常](web-exception)
* [服务层异常](service-exception)
* [自定义异常](custom-exception)
* [异常码](exception-code)

### 表单验证

* [控制器验证](controller-validation)
* [表单请求验证](form-request-validation)
* [扩展的验证方法](extended-validation)

### 数据库

* [基类数据模型](model)
* [软删除](soft-deleting)
* [自动化字段提取](columns-query)
* [自动化范围查询](range-query)
* [自动化排序](order-query)

### 中间件

* [服务器通信授权认证中间件](authorize-validator)
* [输入输出日志记录中间件](request-response-logger)

### 服务

* [响应宏服务](response-macro-service-provider)
* [服务器通信授权服务](service-authorize-service-provider)
* [追踪ID生成服务](track-id-service-provider)

### 通用访问器

* [内部接口通用访问器](common-service-accessor)

### 缓存

* [缓存键生成方法](cache-key)

### 日志

* [日志服务接入](log-service)

### 辅助方法

* [字符串截断](str-trunc)
* [随机字串生成](str-random)
* [url生成](hf-url)

### 分页

* [分页](paginator)

## TODO @ 3.0

1. 统一
  * trackId _trackid
  * requestTime _requesttime
  * 日志记录位置
2. service层取消路由直接调用rpcController
