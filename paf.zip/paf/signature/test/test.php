<?php
assert_options(ASSERT_BAIL, 1);
require dirname(__DIR__) . '/vendor/autoload.php';

// http://api.jeffwang.dev.ipo.com/user/user/isRegisted.html?sMobilePhone=13817716221&time=1399447438&apiKey=797z3it2mdh44weikz4x513irjq22pu9y292k246&apiSequence=66a3011ad952476e2743376d1803da9c&signFuncID=100&signature=db63657186f3ce74b0f29890509d692f
//
//http://api.jeffwang.dev.ipo.com/manage/api/example.html?a=3&ab=1&ac=hello&time=1399447438&apiKey=797z3it2mdh44weikz4x513irjq22pu9y292k246&apiSequence=66a3011ad952476e2743376d1803da9c&signFuncID=100&signature=964774d2570da311eb8e76b1c25e1a78
//
// data={"_from":"ios","cityid":"1","iUserID":"150","key":"business","sToken":"26ef71a8390a3b291d52b8e4b349fc32"}&time=1464665879&apiSequence=1444338da827dc0d4a8b3f4ef33ebe7e&signFuncID=1007bae14bab42629ee01e323db934d6a060b60b634
//
// signature = 20ec6d73d63ce0ac3c1f0c7bee51a35b
$sign = \Paf\Signature\Signature::generate100(
    1464665879,
    '7bae14bab42629ee01e323db934d6a060b60b634',
    '1444338da827dc0d4a8b3f4ef33ebe7e',
    ['_from' => 'ios', 'cityid' => '1', 'iUserID' => '150', 'key' => 'business', 'sToken' => '26ef71a8390a3b291d52b8e4b349fc32']
);

if ($sign === '20ec6d73d63ce0ac3c1f0c7bee51a35b') {
    echo "1. pass!\n";
} else {
    echo "1. failed!\n";
}

// data={"_from":"ios","be_reported_id":"","be_reported_imid":"","comment":"坎坎坷坷坎坎坷坷坎坎坷坷看看看看看看看看看uuuu通","house_id":"292029","iUserID":"150","reason_type":"3","report_id":"150","sToken":"26ef71a8390a3b291d52b8e4b349fc32"}&time=1464672810&apiSequence=dffe436bb8edfe63c7c213f5b97eb1cc&signFuncID=1007bae14bab42629ee01e323db934d6a060b60b634
//
// signature = a9f267f4fa8c409884338d239e4f97cf
//
// http://api.ananzu.st3.anhouse.com.cn/v3/report/add
//
//
$emoji = substr(file_get_contents(__DIR__ . '/emoji.txt'), 0, -1);
$sign = \Paf\Signature\Signature::generate100(
    1464672810,
    '7bae14bab42629ee01e323db934d6a060b60b634',
    'dffe436bb8edfe63c7c213f5b97eb1cc',
    [
        '_from'            => 'ios',
        'be_reported_id'   => '',
        'be_reported_imid' => '',
        'comment'          => "${emoji}坎坎坷坷坎坎坷坷坎坎坷坷看看看看看看看看看uuuu通",
        'house_id'         => '292029',
        'iUserID'          => '150',
        'reason_type'      => '3',
        'report_id'        => '150',
        'sToken'           => '26ef71a8390a3b291d52b8e4b349fc32'
    ]
);

if ($sign === 'a9f267f4fa8c409884338d239e4f97cf') {
    echo "2. pass!\n";
} else {
    echo "2. failed!\n";
}

\Paf\Signature\Signature::generate(
    2,
    1464672810,
    '7bae14bab42629ee01e323db934d6a060b60b634',
    'dffe436bb8edfe63c7c213f5b97eb1cc',
    [
        '_from'            => 'ios',
        'be_reported_id'   => '',
        'be_reported_imid' => '',
        'comment'          => "${emoji}坎坎坷坷坎坎坷坷坎坎坷坷看看看看看看看看看uuuu通",
        'house_id'         => '292029',
        'iUserID'          => '150',
        'reason_type'      => '3',
        'report_id'        => '150',
        'sToken'           => '26ef71a8390a3b291d52b8e4b349fc32'
    ]
);
