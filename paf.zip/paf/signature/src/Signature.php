<?php
/**
 * Signature algorithm for security of paf's web site
 *
 * @author yuanbaoju719
 */

namespace Paf\Signature;

class Signature
{
    /**
     * generate signature according by algorithm 100
     * android与ios不完全相同，当args为空的时候，android的data字段等于{}，
     * ios的data字段为空
     *
     * @param $ts unix timestamp
     * @param $secret  secret key
     * @param $api_seq equal to md5(path)
     * @param $args    arguments from client
     *
     * @return string
     * @author yourname
     */
    public static function generate100($ts, $secret, $api_seq, $args)
    {
        $args_str = '';

        if (is_array($args) && !empty($args)) {
            ksort($args);
            $pieces = [];

            foreach ($args as $k => $v) {
                $pieces[] = sprintf('"%s":"%s"', $k, $v);
            }

            $args_str = sprintf('{%s}', implode(',', $pieces));
        }

        $digest = sprintf(
            "data=%s&time=%d&apiSequence=%s&signFuncID=%s%s",
            $args_str,
            $ts,
            $api_seq,
            100,
            $secret
        );
        $ret = md5($digest);
        return $ret;
    }

    /**
     * generate signature according by algorithm 101
     * android与ios不完全相同，当args为空的时候，android的data字段等于{}，
     * ios的data字段为空
     *
     * @param $ts unix timestamp
     * @param $secret  secret key
     * @param $api_seq equal to md5(path)
     * @param $args    arguments from client
     *
     * @return string
     * @author yourname
     */
    public static function generate101($ts, $secret, $api_seq, $args)
    {
        $args_str = '';

        if (is_array($args)) {
            ksort($args);
            $args_str = json_encode((object)$args, JSON_UNESCAPED_UNICODE);
        }

        $digest = sprintf(
            "data=%s&time=%d&apiSequence=%s&signFuncID=%s%s",
            $args_str,
            $ts,
            $api_seq,
            101,
            $secret
        );

        $ret = md5($digest);
        return $ret;
    }

    public static function generate($sign_fn, $ts, $secret, $api_seq, $args)
    {
        switch ($sign_fn) {
            case 100:
                return self::generate100($ts, $secret, $api_seq, $args);
            case 101:
                return self::generate101($ts, $secret, $api_seq, $args);
            default:
                throw new \InvalidArgumentException(sprintf('invalid argument $sign_fn(%d)', $sign_fn));
        }
    }
}
